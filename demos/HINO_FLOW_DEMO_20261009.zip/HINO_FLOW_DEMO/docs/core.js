/* Pure demo state: no vehicle control, user identity, or external services. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.FlowCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = 2;
  const reasons = ['卸貨排程等待', '必要冷鏈作業', 'PTO 動力輸出', '臨時路況', '需要再確認'];
  function initial() {
    return { version: VERSION, role: 'driver', driving: false, signal: true,
      refrigeration: false, pto: false, sequence: 1, followupLoaded: false,
      events: [{ id: 'seed-wait', kind: 'idle', title: '卸貨點 A 等待時間增加',
        detail: '本週平均 44.6 分鐘／趟，歷史中位數 18.6 分鐘／趟。',
        origin: '合成車次回顧', time: '09/21 · 行程後', reviewed: false }],
      actions: [], audit: [], gate: { eco: null, safety: null, signatures: {} } };
  }
  function restore(raw) {
    try {
      const s = JSON.parse(raw);
      if (!s || s.version !== VERSION || !Array.isArray(s.events) || !Array.isArray(s.actions) || !Array.isArray(s.audit)) return initial();
      const clean = initial();
      clean.role = s.role === 'manager' ? 'manager' : 'driver';
      clean.sequence = Number.isInteger(s.sequence) && s.sequence > 0 ? s.sequence : 1;
      clean.events = s.events.filter(e => e && typeof e.id === 'string' && typeof e.kind === 'string' && typeof e.title === 'string').slice(-80);
      clean.actions = s.actions.filter(a => a && typeof a.id === 'string' && typeof a.title === 'string' && ['待確認', '進行中', '已完成', '必要作業'].includes(a.status)).slice(-80);
      clean.audit = s.audit.filter(a => a && typeof a.text === 'string' && typeof a.time === 'string' && typeof a.actionId === 'string').slice(-100);
      clean.followupLoaded = s.followupLoaded === true;
      // Voice consent and moving state never survive reload.
      return clean;
    } catch (_) { return initial(); }
  }
  function receive(s, kind, now) {
    if (!['ldws', 'acceleration', 'idle'].includes(kind)) throw Error('未知示範事件');
    if (!s.driving) return { allowed: false, text: '先開始模擬行程，才能注入事件。', record: false };
    if (!s.signal) return { allowed: false, text: '訊號中斷；停止評估與播報。', record: false };
    if (!Number.isFinite(now) || now < 0) throw Error('事件時間無效');
    const labels = { ldws: ['車道偏離警示', '模擬原車 LDWS 事件；App 未進行鏡頭辨識。'],
      acceleration: ['連續急加速事件', '注入已符合條件的合成事件，非真實加速度偵測。'],
      idle: ['停車等待事件', '模擬引擎運轉、車速 0，怠速已累積 3 分鐘。'] };
    const prior = s.gate.signatures[kind];
    if (kind !== 'ldws' && prior != null && now - prior < 3000) return { allowed: false, text: '同類教練事件短時間重複，已合併。', record: false };
    s.gate.signatures[kind] = now;
    const event = { id: 'ev-' + s.sequence++, kind, title: labels[kind][0], detail: labels[kind][1],
      origin: kind === 'ldws' ? '原車事件模擬' : '節能事件模擬', time: '本次行程 · 模擬', reviewed: false };
    s.events.push(event);
    if (s.events.length > 80) s.events.shift();
    if (kind === 'idle' && (s.refrigeration || s.pto)) {
      event.suppressed = true;
      return { event, allowed: false, record: true, text: '必要作業已排除怠速提醒，停車後仍可補充原因。' };
    }
    if (kind === 'ldws') {
      s.gate.safety = now;
      return { event, allowed: true, record: true, priority: 'safety',
        text: '車道偏離，請留意路況。', explanation: '模擬原車警示播放一次；App 不追加同事件提醒。' };
    }
    if (s.gate.safety != null && now - s.gate.safety < 10000) return { event, allowed: false, record: true, text: '原車警示優先，暫緩節能提醒。' };
    if (s.gate.eco != null && now - s.gate.eco < 60000) return { event, allowed: false, record: true, text: '節能提醒冷卻 60 秒，事件留待行程後回顧。' };
    // Count delivered notifications, including text-only mode, to avoid catch-up audio.
    s.gate.eco = now;
    return { event, allowed: true, record: true, priority: 'eco', text: kind === 'idle'
      ? '停車等待較久，請於作業結束後確認原因。' : '請留意平順加速，並以現場路況為準。' };
  }
  function feedback(s, eventId, reason, note, timestamp) {
    if (s.driving) throw Error('請結束模擬行程後再補充原因。');
    if (!reasons.includes(reason)) throw Error('請選擇作業原因。');
    const e = s.events.find(x => x.id === eventId);
    if (!e) throw Error('找不到這筆事件。');
    const text = String(note || '').trim();
    if (text.length > 300) throw Error('補充說明請限制在 300 字內。');
    const existing = s.actions.find(a => a.eventId === eventId);
    if (existing) throw Error('此事件已送出說明，可在行動頁查看。');
    e.reviewed = true; e.reason = reason; e.note = text;
    const route = reason === '卸貨排程等待' ? '調度組' : reason.includes('冷鏈') || reason.includes('PTO') ? '營運主管' : '車隊教練';
    const a = { id: 'act-' + eventId, eventId, title: reason === '卸貨排程等待' ? '協調卸貨點 A 的預約時段' : '覆核：' + reason,
      reason, note: text, suggestedOwner: route, owner: '', due: '', classification: '待查',
      status: '待確認', intervention: '', reviewNote: '', comparable: eventId === 'seed-wait', createdAt: timestamp };
    s.actions.push(a); s.audit.push({ actionId: a.id, time: timestamp, text: '駕駛已補充「' + reason + '」，等待主管覆核。' });
    return a;
  }
  function assign(s, id, input, timestamp) {
    if (s.role !== 'manager') throw Error('請切換至經理體驗。此為角色模擬，非登入權限。');
    const a = s.actions.find(x => x.id === id);
    if (!a) throw Error('找不到行動。');
    if (!['待查', '可改善', '必要作業'].includes(input.classification)) throw Error('請選擇判斷。');
    if (!['調度組', '保養組', '營運主管', '車隊教練'].includes(input.owner)) throw Error('請選擇負責角色。');
    if (!validDate(input.due)) throw Error('請選擇有效的追蹤日期。');
    if (!String(input.note || '').trim()) throw Error('請留下主管覆核原因。');
    if (String(input.note).length > 300) throw Error('覆核原因請限制在 300 字內。');
    Object.assign(a, { owner: input.owner, due: input.due, classification: input.classification, reviewNote: input.note.trim(),
      status: input.classification === '必要作業' ? '必要作業' : '進行中', intervention: '' });
    s.audit.push({ actionId: id, time: timestamp, text: input.classification + ' · ' + input.owner + '負責，' + input.due + ' 追蹤。' });
    return a;
  }
  function validDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const d = new Date(value + 'T00:00:00Z');
    return !Number.isNaN(d.valueOf()) && d.toISOString().slice(0, 10) === value;
  }
  function complete(s, id, intervention, timestamp) {
    const a = s.actions.find(x => x.id === id);
    if (s.role !== 'manager' || !a || a.status !== '進行中') throw Error('請由經理先完成覆核與指派。');
    if (!validDate(intervention)) throw Error('請填寫有效的示範介入日期。');
    const recordedDay = String(timestamp).slice(0, 10);
    if (!validDate(recordedDay) || intervention > recordedDay) throw Error('介入日期不可晚於紀錄當日。');
    a.status = '已完成'; a.intervention = intervention;
    s.audit.push({ actionId: id, time: timestamp, text: '已記錄示範介入 ' + intervention + '；等待可比較後期資料。' });
    return a;
  }
  function review(a, dataset, loaded) {
    const result = { before: null, after: null, beforeN: 0, afterN: 0, change: null, message: '請先記錄介入日期。' };
    if (!a || !a.comparable) return { ...result, message: '此事件尚無相符的比較資料；不套用其他事件的改善數字。' };
    if (!a.intervention) return result;
    const at = new Date(a.intervention + 'T00:00:00Z').getTime();
    const day = 86400000;
    const rows = loaded ? dataset.before.concat(dataset.after) : dataset.before;
    const before = rows.filter(r => { const t = Date.parse(r.date); return t >= at - 7 * day && t < at; });
    const after = rows.filter(r => { const t = Date.parse(r.date); return t >= at && t <= at + 6 * day; });
    const avg = items => items.length ? items.reduce((n, x) => n + x.idle, 0) / items.length : null;
    result.before = avg(before); result.after = avg(after); result.beforeN = before.length; result.afterN = after.length;
    const max = rows.length ? Math.max(...rows.map(r => Date.parse(r.date))) : 0;
    if (before.length < 3 || after.length < 3 || max < at + 6 * day) return { ...result, message: '後期尚未完整或樣本不足，暫不顯示改善比例。' };
    result.change = result.before > 0 ? (result.after - result.before) / result.before * 100 : null;
    result.message = '合成資料的前後差異，未控制載重與路況；不是實測節油或因果效果。';
    return result;
  }
  return { VERSION, reasons, initial, restore, receive, feedback, assign, complete, review, validDate };
});
