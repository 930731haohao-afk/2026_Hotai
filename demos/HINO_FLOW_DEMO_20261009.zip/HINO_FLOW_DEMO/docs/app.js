/* Presentation-only mobile demo. All data is synthetic, saved in this browser. */
(() => {
  'use strict';
  const C = window.FlowCore, D = window.FlowSeed, KEY = 'hino-flow-mobile-v2';
  const $ = id => document.getElementById(id);
  const esc = x => String(x == null ? '' : x).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const fmt = (x, n = 1) => x == null ? '—' : Number(x).toFixed(n);
  let s, storageAvailable = true;
  try { s = C.restore(localStorage.getItem(KEY)); } catch (_) { s = C.initial(); storageAvailable = false; }
  let view = 'today', voice = false, seconds = 0, speed = 0, toastTimer, drivingMessage = null, speechToken = 0;
  const svg = (paths) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + paths + '</svg>';
  const icons = {
    home: svg('<path d="m3 10 9-7 9 7v10H3zM9 20v-7h6v7"/>'),
    drive: svg('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/><path d="M3 10h6m6 0h6m-9 5v6"/>'),
    review: svg('<path d="M6 3h12v18H6zM9 7h6m-6 4h6m-6 4h3"/>'),
    action: svg('<path d="M7 4h10v3H7zM7 5H4v16h16V5h-3m-9 9 3 3 5-7"/>'),
    arrow: svg('<path d="m9 5 7 7-7 7"/>'),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    check: svg('<circle cx="12" cy="12" r="9"/><path d="m7 12 3 3 7-7"/>'),
    truck: svg('<path d="M2 6h12v11H2zM14 10h5l3 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>'),
    lane: svg('<path d="M5 3 3 21m16-18 2 18M12 3v4m0 4v3m0 4v3m-4-9 5-4 3 4"/>')
  };
  const icon = name => icons[name] || icons.action;
  const stamp = () => {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Taipei', year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).map(p=>[p.type,p.value]));
    return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}:${parts.second}+08:00`;
  };
  const day = () => stamp().slice(0,10);
  function save() { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (_) { storageAvailable = false; toast('瀏覽器無法保存；這次互動會在關閉後消失。'); } }
  function toast(text) { $('toast').textContent = text; $('toast').classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.remove('visible'), 3500); }
  function monitor(text) { $('monitor-text').textContent = text; }
  function cancelSpeech() { speechToken++; if ('speechSynthesis' in window) speechSynthesis.cancel(); }
  function speak(result) {
    if (!voice || !result.allowed) return;
    if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) { $('voice-status').textContent = '此瀏覽器無語音支援，仍保留文字提醒。'; return; }
    // OEM audio below is a presenter-triggered simulation. App cooldown never gates it.
    if (result.priority === 'eco' && speechSynthesis.speaking) return;
    cancelSpeech();
    const token = speechToken;
    const u = new SpeechSynthesisUtterance(result.text);
    const voices = speechSynthesis.getVoices();
    u.voice = voices.find(v => /^zh[-_]TW$/i.test(v.lang)) || voices.find(v => /^zh/i.test(v.lang)) || null;
    u.lang = u.voice ? u.voice.lang : 'zh-TW'; u.rate = .94; u.volume = .8;
    $('voice-status').textContent = '準備播放示範語音…';
    u.onstart = () => { if(token === speechToken) $('voice-status').textContent = result.priority === 'safety' ? '正在播放原車警示模擬音（非真車）' : '正在播放節能短句'; };
    u.onend = () => { if(token === speechToken) $('voice-status').textContent = '播報完畢 · 不補播冷卻期間的事件'; };
    u.onerror = () => { if(token === speechToken) $('voice-status').textContent = '語音未能播放；可繼續用文字預覽。'; };
    try { speechSynthesis.speak(u); } catch (_) { $('voice-status').textContent = '語音啟動失敗，已保留文字。'; }
  }
  const pending = () => s.events.filter(e => !e.reviewed).length;
  const actionable = () => s.actions.filter(a => ['待確認','進行中'].includes(a.status)).length;
  function pageHeader(kicker, title, sub) { return `<div class="eyebrow">${esc(kicker)}</div><div class="row"><h1>${title}</h1><span class="role-tag">${s.role === 'manager' ? '經理體驗' : '駕駛體驗'}</span></div><p class="sub">${sub}</p>`; }
  function today() {
    if (s.role === 'manager') return pageHeader('FLEET WORKSPACE', '今天，先處理重要的。', '北區示範車隊 · 8 台虛構車輛') +
      `<div class="hero-card"><div class="eyebrow">THIS WEEK'S FOCUS</div><h2>卸貨等待變長，<br>先找營運原因。</h2><p>同路線 A 的平均怠速升至 ${fmt(D.current)} 分鐘／趟。<br>等待未必是駕駛能獨自改變的事。</p><button class="primary" data-action="nav" data-view="actions">查看 ${actionable()} 件待跟進行動 →</button></div><div class="two-stat"><div class="stat-card"><span class="label">等待主管覆核</span><span class="number">${s.actions.filter(a=>a.status==='待確認').length}<small>件</small></span></div><div class="stat-card"><span class="label">已確認必要作業</span><span class="number">${s.actions.filter(a=>a.status==='必要作業').length}<small>件</small></span></div></div><div class="section-title"><h2>同條件看趨勢</h2><span class="tiny">分鐘／趟</span></div>${trend()}<div class="notice">只比較同車型、路線與卸貨點；尚未依載重校正，不作駕駛排名。</div><button class="link-row" data-action="nav" data-view="review">查看數據與駕駛說明 ${icon('arrow')}</button>`;
    return pageHeader('YOUR DAY, IN FOCUS', '早安，今天也平順出發。', '示範駕駛 · DEMO-01') +
      `<div class="hero-card"><div class="row"><span class="eyebrow">今日示範行程</span>${icon('truck')}</div><h2>北區配送 A</h2><div class="route-strip">示範物流站<span></span>卸貨點 A<span></span>返回場站</div><p>路上只保留必要的短句，<br>其他事情，停車後再說。</p><button class="primary" data-action="start">${s.driving?'返回模擬行程':'開始模擬行程'} →</button></div><div class="two-stat"><div class="stat-card"><span class="label">停車後待回覆</span><span class="number">${pending()}<small>件</small></span><span class="tiny">讓數據多一點脈絡</span></div><div class="stat-card"><span class="label">有人正在跟進</span><span class="number">${s.actions.filter(a=>a.status==='進行中').length}<small>件</small></span><span class="tiny">調度、保養一起處理</span></div></div><div class="section-title"><h2>留給停車後的事</h2><button class="text-button" data-action="nav" data-view="review">查看全部 →</button></div><div class="card"><div class="row"><span class="badge amber">作業原因待確認</span><span class="tiny">示範路線 A</span></div><h3>卸貨等待，發生了什麼？</h3><p>同組每趟平均 ${fmt(D.current)} 分鐘，比歷史中位數 ${fmt(D.baseline)} 分鐘高。是排程、冷鏈，還是臨時路況？</p><button class="link-row" data-action="feedback" data-id="seed-wait">${s.events.find(e=>e.id==='seed-wait')?.reviewed?'查看已送出的說明':'補充我的作業原因'} ${icon('arrow')}</button></div>`;
  }
  function trend() { return `<div class="card"><div class="row"><span class="tiny">同車型 · 路線 A · 卸貨點 A</span><span class="badge">合成資料</span></div><div class="mini-chart">${D.weekly.map(w=>`<div class="mini-bar"><strong>${fmt(w.idle)}</strong><span style="height:${Math.round(w.idle/50*60)}px"></span><small>${w.label}</small></div>`).join('')}</div><p class="tiny" style="margin-top:12px;margin-bottom:0">每週 ${D.beforeN} 趟，呈現均值；行動門檻另對照歷史中位數。</p></div>`; }
  function drive() {
    const ready = !s.driving;
    const msg = drivingMessage || { title: ready?'準備好再出發':'目前保持平順', text: ready?'手動開始後，由外側控制台注入情境。':'行車中不需操作。結束行程後再回覆原因。', tone:'' };
    return pageHeader('ON THE ROAD', ready?'行車助理':'專注路況，其餘交給提醒。', '所有速度與事件皆為模擬，未連接車輛') +
      `<div class="row"><span class="drive-status ${!s.signal?'off':''}">${!s.signal?'模擬訊號中斷':s.driving?'模擬訊號接收中':'等待開始'}</span><span class="tiny" id="trip-timer">${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}</span></div><div class="speed-gauge"><div class="gauge-ring"></div><span class="speed-number" id="speed-value">${!s.signal?'—':Math.round(speed)}</span><span class="speed-unit">${!s.signal?'SIGNAL LOST':'KM / H · 模擬'}</span></div><div class="drive-message ${esc(msg.tone)}" id="drive-message"><strong>${esc(msg.title)}</strong><p>${esc(msg.text)}</p></div><div class="fact-grid"><div><span>提醒政策</span><strong>原車警示優先</strong></div><div><span>作業脈絡</span><strong>${s.refrigeration?'必要冷鏈／PTO':'一般配送'}</strong></div></div><button class="${ready?'primary':'secondary'}" data-action="${ready?'start':'end'}">${ready?'開始模擬行程':'結束模擬行程，查看回顧'}</button><p class="tiny">車道偏離由原車 ADAS 偵測。這裡只模擬收到事件；本 App 不操作方向盤、油門或煞車。</p>`;
  }
  function review() {
    if (s.driving) return pageHeader('AFTER THE TRIP','這些事情，停車後再說。','模擬行程仍在進行') + `<div class="empty">${icon('drive')}<h3>行程中保留專注</h3><p>先結束模擬行程，<br>再查看證據與填寫原因。</p></div><button class="primary" data-action="nav" data-view="drive">返回行車畫面</button>`;
    return pageHeader('A LITTLE CONTEXT HELPS',s.role==='manager'?'先聽原因，再看分數。':'這趟行程，你最清楚。','數據提出線索，作業原因由人補充。') +
      `<div class="two-stat" style="margin-top:0"><div class="stat-card"><span class="label">尚待補充</span><span class="number">${pending()}<small>件</small></span></div><div class="stat-card"><span class="label">已回覆說明</span><span class="number">${s.events.filter(e=>e.reviewed).length}<small>件</small></span></div></div>${s.events.slice().reverse().map(e=>`<article class="card"><div class="row"><span class="badge ${e.reviewed?'green':e.suppressed?'':'amber'}">${e.reviewed?'已補充':e.suppressed?'必要作業提醒已略過':'待確認脈絡'}</span><span class="tiny">${esc(e.origin)}</span></div><h3>${esc(e.title)}</h3><p>${esc(e.detail)}</p>${e.reviewed?`<div class="notice">駕駛說明：${esc(e.reason)}${e.note?'<br>'+esc(e.note):''}</div><button class="text-button" data-action="nav" data-view="actions">查看對應行動 →</button>`:`<button class="secondary" data-action="feedback" data-id="${esc(e.id)}">補充原因</button>`}<div class="card-foot" style="margin-top:12px"><span>${esc(e.time)}</span><span>非駕駛績效認定</span></div></article>`).join('')}<div class="notice">本原型可記錄營運脈絡。成熟競品也已有回覆與教練流程；實際優勢仍需以場域測試驗證。</div>`;
  }
  function actions() {
    const content = !s.actions.length ? `<div class="empty">${icon('action')}<h3>每個行動，都從理解開始。</h3><p>先在「回顧」補充卸貨等待原因，<br>再切換經理體驗，安排負責人。</p></div><button class="primary" data-action="nav" data-view="review">先補充一筆原因 →</button>` : s.actions.slice().reverse().map(a=>`<article class="card"><div class="row"><span class="badge ${a.status==='必要作業'||a.status==='已完成'?'green':a.status==='待確認'?'amber':'red'}">${esc(a.status)}</span><span class="tiny">${a.comparable?'卸貨點 A':'行程事件'}</span></div><h3>${esc(a.title)}</h3><p>駕駛回覆：${esc(a.reason)}${a.note?'<br>'+esc(a.note):''}</p><div class="action-meta"><span>${a.owner?esc(a.owner):'建議交給 '+esc(a.suggestedOwner)}</span><span>${a.due?esc(a.due)+' 追蹤':'待設定追蹤日期'}</span></div><div class="progress-track"><span class="done"></span><span class="${a.status!=='待確認'?'done':''}"></span><span class="${a.status==='已完成'||a.status==='必要作業'?'done':''}"></span></div><div class="row tiny"><span>駕駛說明</span><span>主管覆核</span><span>執行回看</span></div><div class="divider"></div>${s.role==='manager'?`<button class="${a.status==='待確認'?'primary':'secondary'}" data-action="assign" data-id="${esc(a.id)}">${a.status==='待確認'?'覆核並指派':'更新處理與追蹤'}</button>`:`<button class="secondary" data-action="switch-role">切換經理，體驗指派</button>`}<button class="text-button" data-action="followup" data-id="${esc(a.id)}" style="margin-top:12px">查看證據與追蹤結果 →</button></article>`).join('');
    return pageHeader('TURN INSIGHTS INTO ACTION','讓改善，有人接手。',`${actionable()} 件待處理 · 指派僅儲存在此瀏覽器`) + content;
  }
  function render(resetScroll=true) {
    $('screen').innerHTML = ({today,drive,review,actions}[view] || today)();
    if(resetScroll) $('screen').scrollTop = 0;
    document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon));
    document.querySelectorAll('.bottom-nav button').forEach(el=>{ el.classList.toggle('active',el.dataset.view===view); el.setAttribute('aria-current',el.dataset.view===view?'page':'false'); });
    document.querySelectorAll('[data-action="role"]').forEach(el=>{el.classList.toggle('selected',el.dataset.value===s.role);el.setAttribute('aria-pressed',String(el.dataset.value===s.role));});
    $('avatar').textContent = s.role==='manager'?'經':'駕';
    $('review-badge').textContent = pending() || '';
    $('action-badge').textContent = actionable() || '';
    $('cold-toggle').checked = s.refrigeration;
    $('signal-toggle').innerHTML = `<span>⌁</span>${s.signal?'模擬斷線':'恢復訊號'}`;
  }
  function openSheet(title, content) {
    $('sheet-host').innerHTML=`<div class="sheet-backdrop"><section class="sheet" role="dialog" aria-modal="true" aria-labelledby="sheet-title"><div class="sheet-handle"></div><div class="row"><h2 id="sheet-title">${esc(title)}</h2><button class="close-button" data-action="close-sheet" aria-label="關閉">×</button></div>${content}</section></div>`;
    $('sheet-host').querySelector('.close-button').focus();
  }
  function closeSheet() {$('sheet-host').innerHTML='';}
  function feedbackSheet(id) {
    if(s.driving){toast('請先結束模擬行程，再回覆原因。');return;}
    const e=s.events.find(x=>x.id===id);
    if(!e){toast('這筆事件已不存在。');return;}
    if(e.reviewed){view='actions';render();return;}
    openSheet('把作業原因補進來',`<p class="sub">${esc(e.title)}<br>回覆會交給經理覆核，不直接扣分。</p><form id="feedback-form" data-id="${esc(id)}"><span class="form-label">最接近這次情況的原因</span><div class="reason-options">${C.reasons.map(r=>`<label><input type="radio" name="reason" value="${esc(r)}" required>${esc(r)}</label>`).join('')}</div><label class="form-label" for="feedback-note">補充說明（選填）</label><textarea class="field" id="feedback-note" name="note" maxlength="300" placeholder="例如：卸貨窗口臨時延後，請調度協助確認。"></textarea><div class="form-error" id="form-error"></div><button class="primary" type="submit">送出說明，交給主管覆核</button><p class="tiny">本機流程演練，不會通知真實人員。</p></form>`);
  }
  function assignSheet(id) {
    const a=s.actions.find(x=>x.id===id); if(!a)return;
    if(s.role!=='manager'){toast('請先切換經理體驗。');return;}
    const options=(values, selected)=>values.map(x=>`<option ${x===selected?'selected':''}>${esc(x)}</option>`).join('');
    openSheet('覆核與責任指派',`<p class="sub">${esc(a.title)}<br>駕駛說明：${esc(a.reason)}</p><form id="assign-form" data-id="${esc(id)}"><label class="form-label" for="classification">主管判斷</label><select class="field" name="classification" id="classification">${options(['待查','可改善','必要作業'],a.classification)}</select><label class="form-label" for="owner">負責角色</label><select class="field" name="owner" id="owner">${options(['調度組','保養組','營運主管','車隊教練'],a.owner||a.suggestedOwner)}</select><label class="form-label" for="due">下次追蹤日</label><input class="field" type="date" name="due" id="due" value="${esc(a.due||'2026-09-29')}" required><label class="form-label" for="review-note">覆核原因</label><textarea class="field" name="note" id="review-note" maxlength="300" required placeholder="核對後的原因、預計採取的措施">${esc(a.reviewNote)}</textarea><div class="form-error" id="form-error"></div><button class="primary" type="submit">儲存判斷與指派</button></form>${a.status==='進行中'?`<div class="divider"></div><form id="complete-form" data-id="${esc(id)}"><label class="form-label" for="intervention">已執行的示範介入日</label><input class="field" name="intervention" id="intervention" type="date" max="${day()}" value="2026-09-22" required><button class="secondary" type="submit" style="margin-top:12px">記錄執行完成</button><p class="tiny">這是合成演練；真實使用時須填實際執行日。</p></form>`:''}`);
  }
  function followupSheet(id) {
    const a=s.actions.find(x=>x.id===id);if(!a)return;
    const r=C.review(a,D,s.followupLoaded);
    openSheet('同條件，回看是否改變',`<p class="sub">${esc(a.title)}<br>${a.comparable?'同車型／路線 A／卸貨點 A':'目前缺少可比較同組資料'}</p><span class="badge red">所有比較數據均為合成</span><div class="comparison"><div><small>介入前 7 天</small><strong>${fmt(r.before)}</strong><small>分鐘／趟 · n=${r.beforeN}</small></div><div><small>介入後 7 天</small><strong>${fmt(r.after)}</strong><small>分鐘／趟 · n=${r.afterN}</small></div></div>${r.change!=null?`<div class="notice"><strong>情境差異 ${r.change.toFixed(1)}%</strong><br>這不是實測節油成績。</div>`:''}<p class="compare-note">${esc(r.message)}</p>${a.comparable&&a.intervention&&!s.followupLoaded?`<button class="secondary" data-action="load-followup" data-id="${esc(id)}">載入合成後週情境</button><p class="tiny">加入 9/22–9/28 的 21 筆假設資料。<br>只演示流程，不表示真實改善已發生。</p>`:''}<div class="divider"></div><h3 class="small">處理紀錄</h3>${s.audit.filter(x=>x.actionId===id).slice().reverse().map(x=>`<div class="audit-entry"><time>${esc(x.time.slice(0,16).replace('T',' '))} 台北時間</time>${esc(x.text)}</div>`).join('')}<p class="tiny">尚未建立未介入對照組、信賴區間或載重校正。</p>`);
  }
  function navigate(next){closeSheet();view=next;render();}
  function start(){closeSheet();if(!s.driving){s.driving=true;s.signal=true;seconds=0;speed=38;drivingMessage=null;save();}view='drive';render();monitor('模擬行程已開始。用左側情境控制，觀察提醒優先順序。');}
  function end(){s.driving=false;speed=0;cancelSpeech();save();view='review';drivingMessage=null;render();monitor('行程已結束。現在可以補充事件原因，交給主管覆核。');}
  document.addEventListener('click',ev=>{
    const b=ev.target.closest('[data-action]');if(!b)return;
    const action=b.dataset.action;
    if(action==='nav')navigate(b.dataset.view);
    else if(action==='role'||action==='switch-role') {s.role=action==='role'?b.dataset.value:s.role==='driver'?'manager':'driver';if(s.driving)end();save();view=s.role==='manager'?'actions':'today';render();monitor(s.role==='manager'?'經理體驗：先看駕駛說明，再覆核原因與指派。':'駕駛體驗：行程結束後，補充現場作業原因。');}
    else if(action==='start')start();
    else if(action==='end')end();
    else if(action==='inject'){
      const result=C.receive(s,b.dataset.kind,Date.now());
      if(result.record){view='drive';if(b.dataset.kind==='idle')speed=0;else speed= b.dataset.kind==='acceleration'?54:48;}
      drivingMessage={title:result.priority==='safety'?'原車 LDWS 事件（模擬）':result.allowed?'一則節能提醒':result.record?'先保留事件，不追加語音':'暫無法評估',text:result.text,tone:result.priority==='safety'?'alert':result.allowed?'':'caution'};
      save();render(false);monitor(result.explanation||result.text);if(result.allowed)speak(result);else toast(result.text);
    } else if(action==='signal'){
      s.signal=!s.signal;cancelSpeech();drivingMessage=s.signal?null:{title:'訊號暫停，暫不判斷',text:'未收到可信訊號；App 不補算未收到的事件。原車 ADAS 仍獨立運作。',tone:'caution'};
      render(false);monitor(s.signal?'示範訊號已恢復，等待下一筆新事件。':'已模擬訊號中斷，停止 App 教練播報。');
    } else if(action==='feedback')feedbackSheet(b.dataset.id);
    else if(action==='assign')assignSheet(b.dataset.id);
    else if(action==='followup')followupSheet(b.dataset.id);
    else if(action==='load-followup'){s.followupLoaded=true;save();followupSheet(b.dataset.id);monitor('已載入明確標示的合成後期資料。前後變化不等於介入因果效果。');}
    else if(action==='close-sheet')closeSheet();
    else if(action==='reset')openSheet('重新開始這段演練？','<p class="sub">只清除這個手機原型的合成操作紀錄；桌面工作台資料保持原狀。</p><button class="primary" data-action="confirm-reset">重設手機演練</button><button class="secondary" data-action="close-sheet" style="margin-top:9px">保留紀錄</button>');
    else if(action==='confirm-reset'){cancelSpeech();s=C.initial();voice=false;$('voice-toggle').checked=false;$('voice-status').textContent='固定短句・不使用麥克風';save();closeSheet();view='today';drivingMessage=null;render();monitor('演練已重設，所有資料皆為合成。');toast('已重設手機演練。');}
  });
  document.addEventListener('submit',ev=>{
    const form=ev.target;if(!['feedback-form','assign-form','complete-form'].includes(form.id))return;ev.preventDefault();
    const input=Object.fromEntries(new FormData(form));
    try {
      if(form.id==='feedback-form'){C.feedback(s,form.dataset.id,input.reason,input.note,stamp());monitor('駕駛說明已送入待覆核清單。切換經理體驗可接續處理。');}
      else if(form.id==='assign-form'){C.assign(s,form.dataset.id,input,stamp());monitor('主管覆核已儲存，負責角色與追蹤日期清楚保留。');}
      else {C.complete(s,form.dataset.id,input.intervention,stamp());monitor('已記錄示範介入日期，可回看同組前後資料。');}
      save();closeSheet();view='actions';render();toast('已儲存在此瀏覽器；沒有傳送給任何人。');
    }catch(error){const box=$('form-error');if(box){box.textContent=error.message;box.style.display='block';}else toast(error.message);}
  });
  $('cold-toggle').addEventListener('change',ev=>{s.refrigeration=ev.target.checked;s.pto=ev.target.checked;render(false);monitor(s.refrigeration?'已設定合成必要作業訊號。停車怠速事件保留，但不追加節能語音。':'已切回一般作業情境。');});
  $('voice-toggle').addEventListener('change',ev=>{voice=ev.target.checked;if(!voice)cancelSpeech();$('voice-status').textContent=voice?'已允許下一筆示範語音，不補播舊事件。':'已靜音並取消語音。';});
  document.addEventListener('keydown',ev=>{if(ev.key==='Escape')closeSheet();if(ev.key==='Tab'&&$('sheet-host').children.length){const nodes=Array.from($('sheet-host').querySelectorAll('button,input,select,textarea,a[href]')).filter(x=>!x.disabled);const first=nodes[0],last=nodes[nodes.length-1];if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelSpeech();if(s.driving){s.driving=false;speed=0;save();drivingMessage={title:'模擬已暫停',text:'離開頁面後暫停；回來請手動重新開始。',tone:'caution'};render(false);}}});
  window.addEventListener('pagehide',cancelSpeech);
  setInterval(()=>{if(!s.driving)return;seconds++;if($('trip-timer'))$('trip-timer').textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');},1000);
  if(!storageAvailable)monitor('瀏覽器儲存不可用；可試操作，但重新載入會重設。');
  render();
})();


