"""Loopback-only server for the public synthetic phone demo directory."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, unquote

PUBLIC = Path(__file__).resolve().parent / 'mobile'
ALLOWED = {'index.html','style.css','core.js','app.js','seed.js','market.html','proposal.md','proposal.pdf'}

class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        name = unquote(urlsplit(self.path).path).lstrip('/') or 'index.html'
        if name not in ALLOWED:
            self.send_error(404)
            return
        self.path = '/' + name
        super().do_GET()

    def do_HEAD(self):
        name = unquote(urlsplit(self.path).path).lstrip('/') or 'index.html'
        if name not in ALLOWED:
            self.send_error(404)
            return
        self.path = '/' + name
        super().do_HEAD()

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        super().end_headers()

if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', 8504), partial(Handler, directory=str(PUBLIC)))
    print('HINO FLOW phone demo: http://127.0.0.1:8504', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
