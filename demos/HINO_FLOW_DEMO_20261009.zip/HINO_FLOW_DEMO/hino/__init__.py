"""HINO fleet operations prototype: local, evidence-backed and synthetic by default."""
