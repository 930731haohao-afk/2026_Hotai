"""Deterministic trip validation and descriptive, history-only action candidates.

Inputs are per-trip totals, never cumulative meter readings. No function estimates
causal savings or instructs a driver to control a vehicle.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import re
from collections import Counter
from datetime import date, datetime, timedelta
from typing import Any

import pandas as pd

REQUIRED = ("trip_id", "vehicle_id", "date", "vehicle_type", "route", "distance_km", "idle_minutes")
OPTIONAL = ("fuel_liters", "site", "operation", "load_tons")
COLUMNS = REQUIRED + OPTIONAL
MIN_TRIPS = 3
MAX_BYTES = 20 * 1024 * 1024
MAX_ROWS = 100_000


def _day(value: date | str | pd.Timestamp) -> pd.Timestamp:
    """Accept date-only values; timestamps/timezones must be normalized upstream."""
    if isinstance(value, str):
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise ValueError("日期須為 YYYY-MM-DD，不接受時間、時區或有歧義的格式")
        try:
            return pd.Timestamp(date.fromisoformat(value)).as_unit("ns")
        except (ValueError, OverflowError) as exc:
            raise ValueError("日期不存在或超出支援範圍") from exc
    if isinstance(value, datetime):
        if value.tzinfo is not None or value.time() != datetime.min.time():
            raise ValueError("日期須為不含時間與時區的日期")
        return pd.Timestamp(value.date()).as_unit("ns")
    if isinstance(value, date):
        return pd.Timestamp(value).as_unit("ns")
    raise ValueError("日期須為 YYYY-MM-DD")


def _number(raw: str, column: str, *, optional: bool = False) -> float | None:
    if not raw:
        if optional:
            return None
        raise ValueError(f"{column} 缺值")
    try:
        value = float(raw)
    except (ValueError, OverflowError) as exc:
        raise ValueError(f"{column} 不是數字") from exc
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"{column} 須為有限的非負數")
    if value > 1e12:
        raise ValueError(f"{column} 數值超出逐趟資料上限，請確認單位與累計值")
    return value


def parse_csv(data: bytes) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Validate UTF-8 CSV; reject invalid rows and never double-count trip IDs.

    Exact repeats retain the first copy; conflicting repeats discard every copy.
    `duplicates` counts repeat occurrences beyond the first ID occurrence.
    `rows = accepted + rejected`; errors include at most the first 12 row issues.
    """
    if not isinstance(data, bytes) or not data:
        raise ValueError("CSV 是空檔案")
    if len(data) > MAX_BYTES:
        raise ValueError("CSV 超過 20 MB，請先縮小至逐趟彙整資料")
    try:
        source = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("請將 CSV 另存為 UTF-8 編碼後再匯入") from exc
    if "\x00" in source:
        raise ValueError("CSV 含無效字元，請確認檔案格式")
    reader = csv.reader(io.StringIO(source, newline=""), strict=True)
    try:
        header = [item.strip() for item in next(reader)]
    except (StopIteration, csv.Error) as exc:
        raise ValueError("無法讀取 CSV 標題列") from exc
    if len(set(header)) != len(header):
        raise ValueError("CSV 欄位名稱重複，請先修正")
    missing = [column for column in REQUIRED if column not in header]
    if missing:
        raise ValueError("缺少必要欄位：" + "、".join(missing))
    quality: dict[str, Any] = {
        "rows": 0, "accepted": 0, "rejected": 0, "duplicates": 0,
        "missing_fuel": 0, "missing_load": 0, "warnings": [], "errors": [],
        "start_date": None, "end_date": None, "conflict_ids": [], "identical_duplicates": 0,
    }
    candidates: list[tuple[int, dict[str, Any]]] = []
    ids: Counter[str] = Counter()
    issues: list[str] = []
    try:
        for row in reader:
            if not row or not any(cell.strip() for cell in row):
                continue
            quality["rows"] += 1
            if quality["rows"] > MAX_ROWS:
                raise ValueError("CSV 超過 100,000 筆，請先依日期或車隊切分")
            line_number = reader.line_num
            if len(row) != len(header):
                issues.append(f"第 {line_number} 列：欄位數量不一致，已排除")
                continue
            raw = {key: value.strip() for key, value in zip(header, row)}
            if raw.get("trip_id"):
                ids[raw["trip_id"]] += 1
            try:
                for column in ("trip_id", "vehicle_id", "date", "vehicle_type", "route"):
                    if not raw[column]:
                        raise ValueError(f"{column} 缺值")
                record: dict[str, Any] = {column: raw.get(column, "") for column in COLUMNS}
                record["date"] = _day(raw["date"])
                for column in ("distance_km", "idle_minutes"):
                    record[column] = _number(raw[column], column)
                for column in ("fuel_liters", "load_tons"):
                    record[column] = _number(raw.get(column, ""), column, optional=True)
                record["site"] = raw.get("site", "") or "未提供"
                record["operation"] = raw.get("operation", "") or "未提供"
                candidates.append((line_number, record))
            except (ValueError, OverflowError) as exc:
                issues.append(f"第 {line_number} 列：{exc}，已排除")
    except csv.Error as exc:
        raise ValueError(f"CSV 引號或換行格式損壞（約第 {reader.line_num} 列），請修正後再匯入") from exc
    quality["duplicates"] = sum(count - 1 for count in ids.values() if count > 1)
    first: dict[str, dict[str, Any]] = {}
    conflicts: set[str] = set()
    for _, record in candidates:
        trip_id = record["trip_id"]
        if trip_id in first and first[trip_id] != record:
            conflicts.add(trip_id)
        else:
            first.setdefault(trip_id, record)
    records = [record for trip_id, record in first.items() if trip_id not in conflicts]
    valid_id_counts = Counter(record["trip_id"] for _, record in candidates)
    quality["identical_duplicates"] = sum(count - 1 for trip_id, count in valid_id_counts.items() if trip_id not in conflicts)
    if quality["duplicates"]:
        quality["warnings"].append(
            f"發現 {quality['duplicates']} 筆重複 ID；完全相同的記錄只保留一筆，內容衝突的 ID 全部排除。"
        )
    if conflicts:
        quality["conflict_ids"] = sorted(conflicts)
        issues.append(f"{len(conflicts)} 個 trip_id 內容衝突，該 ID 的所有有效列已排除")
    quality["accepted"] = len(records)
    quality["rejected"] = quality["rows"] - len(records)
    quality["errors"] = issues[:12]
    if len(issues) > 12:
        quality["errors"].append(f"另有 {len(issues) - 12} 項資料問題，請先修正來源 CSV")
    if not records:
        raise ValueError("沒有可分析的有效資料。" + "；".join(quality["errors"][:3]))
    frame = pd.DataFrame(records, columns=COLUMNS)
    frame["date"] = pd.to_datetime(frame["date"])
    for column in ("distance_km", "idle_minutes", "fuel_liters", "load_tons"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce").astype(float)
    frame = frame.sort_values(["date", "trip_id"], kind="stable").reset_index(drop=True)
    quality["missing_fuel"] = int(frame["fuel_liters"].isna().sum())
    quality["missing_load"] = int(frame["load_tons"].isna().sum())
    quality["start_date"] = frame["date"].min().date().isoformat()
    quality["end_date"] = frame["date"].max().date().isoformat()
    if quality["missing_fuel"]:
        quality["warnings"].append(f"{quality['missing_fuel']} 筆缺少燃油量；含缺值的群組不顯示整組油耗，也不生成油耗比較行動。")
    if quality["missing_load"]:
        quality["warnings"].append(f"{quality['missing_load']} 筆缺少載重，無法排除載重差異。")
    quality["unreliable_fuel"] = int(((frame["distance_km"] > 0) & (frame["fuel_liters"] == 0)).sum())
    if quality["unreliable_fuel"]:
        quality["warnings"].append(f"{quality['unreliable_fuel']} 筆有行駛里程但燃油量為 0；請查核量測，含此情形的群組暫停油耗統計。")
    zero_distance = int((frame["distance_km"] == 0).sum())
    if zero_distance:
        quality["warnings"].append(f"{zero_distance} 筆里程為 0；保留怠速與燃油總量，不計算該趟每百公里油耗。")
    if (frame["site"] == "未提供").any():
        quality["warnings"].append("部分資料缺少作業地點，怠速群組只能依已知車型與路線比較。")
    quality["warnings"].append("欄位須為逐趟里程與耗油增量；本工具無法自動證明儀表、燃油量測及累計值已正確校準。")
    return frame, quality


def _fuel(frame: pd.DataFrame) -> tuple[float | None, float | None]:
    if frame.empty or frame["fuel_liters"].isna().any():
        return None, None
    if ((frame["distance_km"] > 0) & (frame["fuel_liters"] == 0)).any():
        return None, None
    total = float(frame["fuel_liters"].sum())
    distance = float(frame["distance_km"].sum())
    rate = total * 100 / distance if distance > 0 else None
    return round(total, 2), round(rate, 2) if rate is not None and math.isfinite(rate) else None


def _iso(value: pd.Timestamp) -> str:
    return value.date().isoformat()


def _subset(frame: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    return frame.loc[(frame["date"] >= start) & (frame["date"] <= end)]


def _match(frame: pd.DataFrame, scope: dict[str, str]) -> pd.DataFrame:
    result = frame
    for key, value in scope.items():
        if key not in {"vehicle_id", "vehicle_type", "route", "site"}:
            raise ValueError("未知的比較群組欄位")
        result = result.loc[result[key] == value]
    return result


def _candidate(kind: str, current: pd.DataFrame, baseline: pd.DataFrame,
               scope: dict[str, str], start: pd.Timestamp, end: pd.Timestamp,
               history_start: pd.Timestamp) -> dict[str, Any] | None:
    if len(current) < MIN_TRIPS or len(baseline) < MIN_TRIPS:
        return None
    if kind == "idle":
        current_value = float(current["idle_minutes"].mean())
        baseline_value = float(baseline["idle_minutes"].median())
        if current_value < baseline_value + 8 or current_value < baseline_value * 1.35:
            return None
        unit = "分鐘／趟"
    else:
        # Zero-distance trips have undefined per-trip fuel rates. Exclude the
        # entire scope from ranking, rather than silently selecting good rows.
        combined = pd.concat([current, baseline])
        if combined["fuel_liters"].isna().any() or (combined["distance_km"] <= 0).any() or (combined["fuel_liters"] <= 0).any():
            return None
        current_value = float(current["fuel_liters"].sum() * 100 / current["distance_km"].sum())
        baseline_value = float((baseline["fuel_liters"] * 100 / baseline["distance_km"]).median())
        if not math.isfinite(current_value) or not math.isfinite(baseline_value):
            return None
        if current_value < baseline_value + 2 or current_value < baseline_value * 1.15:
            return None
        unit = "L／100 km"
    caveats = ["觀察性比較；尚未排除載重、天候、路況與作業內容差異，不能推論成因或已節省的燃油。"]
    combined = pd.concat([current, baseline])
    if combined["load_tons"].isna().any():
        caveats.append("部分載重缺值；不作駕駛績效排名。")
    else:
        caveats.append("已取得載重，但本版尚未依載重分層或調整。")
    if kind == "idle" and scope.get("site") == "未提供":
        caveats.append("地點缺值，可能混合不同作業地點，須先補齊。")
    if combined["operation"].astype(str).str.contains("冷|PTO|動力", case=False, regex=True).any():
        caveats.append("含冷鏈或動力作業，可能屬必要怠速；請由管理者確認作業需求。")
    elif (combined["operation"] == "未提供").any():
        caveats.append("缺少部分作業狀態，須確認冷鏈與動力輸出需求。")
    confidence = "中" if min(len(current), len(baseline)) >= 7 and not combined["load_tons"].isna().any() else "低"
    digest = hashlib.sha256(json.dumps([kind, scope, _iso(start), _iso(end)], sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]
    delta = current_value - baseline_value
    vehicle_ids = sorted(current["vehicle_id"].unique().tolist())
    if kind == "idle":
        title = f"{scope['site']}的怠速時間上升，先確認作業脈絡"
        description = f"同車型、路線與地點，本週平均 {current_value:.1f} 分鐘／趟；此前歷史中位數 {baseline_value:.1f} 分鐘／趟。"
        suggestion = "請調度確認等待裝卸、預約時段及必要作業，管理者再標記可避免、必要或待查。"
        priority = delta * len(current)
    else:
        title = f"{scope['vehicle_id']}同路線油耗上升，安排資料與車況查核"
        description = f"同車、同車型與路線，本週加權油耗 {current_value:.1f} L／100 km；此前逐趟油耗中位數 {baseline_value:.1f}。"
        suggestion = "請保養與調度核對燃油記錄、載重、路況與保養狀態，再決定需要的處置。"
        priority = delta * len(current) * 4
    result: dict[str, Any] = {
        "id": f"{kind}-{digest}", "kind": kind, "title": title, "description": description,
        "vehicle_ids": vehicle_ids, "route": scope["route"], "site": scope.get("site", "跨地點"),
        "vehicle_type": scope["vehicle_type"], "scope": scope,
        "current_value": round(current_value, 2), "baseline_value": round(baseline_value, 2),
        "unit": unit, "current_n": len(current), "baseline_n": len(baseline),
        "confidence": confidence, "label": "待查", "caveats": caveats,
        "priority": round(priority, 2), "suggestion": suggestion,
        "current_start": _iso(start), "current_end": _iso(end),
        "baseline_start": _iso(history_start), "baseline_end": _iso(start - timedelta(days=1)),
        "evidence": [
            f"本週 {_iso(start)} 至 {_iso(end)}：{len(current)} 趟。",
            f"歷史 {_iso(history_start)} 至 {_iso(start - timedelta(days=1))}：{len(baseline)} 趟；只使用分析週之前的資料。",
            f"比較群組：{'／'.join(scope.values())}。",
            f"本週值 {current_value:.2f}、歷史中位數 {baseline_value:.2f} {unit}；增加 {delta:.2f} {unit}。",
        ],
    }
    if kind == "idle":
        result["excess_idle_minutes"] = round(priority, 2)
        result["caveats"].append("超出基線的分鐘數是待查量，尚未證明可避免。")
    return result


def analyze(df: pd.DataFrame, week_end: str | date | None = None) -> dict[str, Any]:
    if df.empty:
        raise ValueError("沒有可分析資料")
    end = _day(week_end) if week_end is not None else df["date"].max().normalize()
    start = end - timedelta(days=6)
    previous_start = start - timedelta(days=7)
    previous_end = start - timedelta(days=1)
    history_start = start - timedelta(days=21)
    current = _subset(df, start, end)
    previous = _subset(df, previous_start, previous_end)
    historical = _subset(df, history_start, previous_end)
    fuel_liters, fuel_rate = _fuel(current)
    _, previous_fuel_rate = _fuel(previous)
    summary = {
        "vehicles": int(current["vehicle_id"].nunique()), "trips": len(current),
        "distance_km": round(float(current["distance_km"].sum()), 2),
        "fuel_liters": fuel_liters, "fuel_per_100km": fuel_rate,
        "idle_minutes": round(float(current["idle_minutes"].sum()), 2),
        "previous_idle_minutes": round(float(previous["idle_minutes"].sum()), 2),
        "previous_fuel_per_100km": previous_fuel_rate,
        "previous_trips": len(previous),
    }
    daily = []
    for day in pd.date_range(start, end):
        group = current.loc[current["date"] == day]
        daily.append({"date": _iso(day), "idle_minutes": round(float(group["idle_minutes"].sum()), 2) if len(group) else None,
                      "fuel_per_100km": _fuel(group)[1], "trips": len(group)})
    actions = []
    for kind, keys in [("idle", ["vehicle_type", "route", "site"]), ("fuel", ["vehicle_id", "vehicle_type", "route"])]:
        for values, group in current.groupby(keys, dropna=False, sort=True):
            scope = dict(zip(keys, values))
            baseline = _match(historical, scope)
            action = _candidate(kind, group, baseline, scope, start, end, history_start)
            if action:
                actions.append(action)
    actions.sort(key=lambda action: (-action["priority"], action["id"]))
    return {"summary": summary, "daily": daily, "actions": actions,
            "current_start": _iso(start), "current_end": _iso(end),
            "baseline_start": _iso(previous_start), "baseline_end": _iso(previous_end),
            "history_start": _iso(history_start), "history_end": _iso(previous_end)}


def week_review(df: pd.DataFrame, action: dict[str, Any], intervention_date: date | str) -> dict[str, Any]:
    """Descriptive before/after review; intervention date is the first after day.

    Differences require >=3 trips in each window and a fully elapsed 7-day after
    window in the supplied dataset. Sparse coverage is always disclosed.
    """
    intervention = _day(intervention_date)
    scope = action.get("scope")
    if not isinstance(scope, dict) or not scope:
        raise ValueError("行動缺少可驗證的比較群組")
    group = _match(df, scope)
    before_start, before_end = intervention - timedelta(days=7), intervention - timedelta(days=1)
    after_start, after_end = intervention, intervention + timedelta(days=6)

    def metrics(start: pd.Timestamp, end: pd.Timestamp) -> dict[str, Any]:
        part = _subset(group, start, end)
        return {"start": _iso(start), "end": _iso(end), "trips": len(part),
                "days_with_data": int(part["date"].nunique()),
                "idle_minutes_per_trip": round(float(part["idle_minutes"].mean()), 2) if len(part) else None,
                "fuel_per_100km": _fuel(part)[1],
                "distance_km": round(float(part["distance_km"].sum()), 2)}

    before, after = metrics(before_start, before_end), metrics(after_start, after_end)
    complete = not df.empty and df["date"].max() >= after_end
    sufficient = before["trips"] >= MIN_TRIPS and after["trips"] >= MIN_TRIPS
    comparable = bool(complete and sufficient)
    differences: dict[str, float | None] = {"idle_minutes_per_trip": None, "fuel_per_100km": None}
    if comparable:
        for key in differences:
            if before[key] is not None and after[key] is not None:
                differences[key] = round(after[key] - before[key], 2)
    caveats = ["僅為同組執行前後描述；未建立未介入控制組，無法將變化歸因於行動。",
               "工作日覆蓋、載重、天候、路況與作業內容可能改變；未估計統計信賴區間。"]
    if not complete:
        caveats.append("資料尚未涵蓋完整後 7 天；暫不顯示前後差值。")
    if not sufficient:
        caveats.append("前後各需至少 3 趟資料；目前樣本不足，暫不顯示前後差值。")
    if before["days_with_data"] < 7 or after["days_with_data"] < 7:
        caveats.append("部分日期沒有相同群組的資料；可能是未營運或缺漏，請確認。")
    return {"before": before, "after": after, "differences": differences,
            "complete": bool(complete), "sufficient": bool(sufficient), "comparable": comparable,
            "controls_available": False, "caveats": caveats, "scope": scope,
            "intervention_date": _iso(intervention)}
