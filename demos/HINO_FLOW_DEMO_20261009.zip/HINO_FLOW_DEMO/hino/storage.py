"""Local, dataset-scoped action feedback and an append-only SQLite audit log.

This store intentionally has no user/tenant model: it belongs to one local
workstation. Dataset hashes separate imported files; they are not access controls.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
from typing import Iterator


CLASSIFICATIONS = ("待查", "可避免", "必要")
STATUSES = ("待處理", "進行中", "已完成")
_STATE_FIELDS = (
    "classification", "reason", "assignee", "due_date", "status",
    "intervention_date", "updated_at",
)


def dataset_id(data: bytes) -> str:
    """Identify the exact imported bytes, independently of the filename."""
    if not isinstance(data, bytes):
        raise TypeError("data 必須是 bytes。")
    return hashlib.sha256(data).hexdigest()


def _text(value: str, name: str, maximum: int, required: bool = False) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{name} 必須是文字。")
    value = value.strip()
    if required and not value:
        raise ValueError(f"{name} 不可空白。")
    if len(value) > maximum:
        raise ValueError(f"{name} 不可超過 {maximum} 個字元。")
    if "\x00" in value:
        raise ValueError(f"{name} 不可含空字元。")
    return value


def _date(value: str, name: str) -> str:
    value = _text(value, name, 10)
    if value:
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise ValueError(f"{name} 請使用 YYYY-MM-DD。")
        try:
            date.fromisoformat(value)
        except ValueError as exc:
            raise ValueError(f"{name} 不是有效日期。") from exc
    return value


def _json(value: object) -> str:
    try:
        result = json.dumps(value, ensure_ascii=False, sort_keys=True,
                            separators=(",", ":"), allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("行動證據必須可轉為 JSON，且不可含 NaN 或無限值。") from exc
    if len(result.encode("utf-8")) > 262_144:
        raise ValueError("單筆行動證據不可超過 256 KB。")
    return result


class Store:
    """Persist feedback with one transaction for each state and audit change."""

    def __init__(self, db_path: str | Path):
        if str(db_path) == ":memory:":
            raise ValueError("請提供本機資料庫檔案路徑，以保留行動與稽核紀錄。")
        self.db_path = Path(db_path).expanduser().resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connection() as connection:
            connection.execute("PRAGMA journal_mode=WAL")
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS actions (
                    dataset_id TEXT NOT NULL,
                    action_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    classification TEXT NOT NULL CHECK (
                        classification IN ('待查', '可避免', '必要')),
                    reason TEXT NOT NULL,
                    assignee TEXT NOT NULL,
                    due_date TEXT NOT NULL,
                    status TEXT NOT NULL CHECK (
                        status IN ('待處理', '進行中', '已完成')),
                    intervention_date TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (dataset_id, action_id)
                );
                CREATE TABLE IF NOT EXISTS action_history (
                    audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    dataset_id TEXT NOT NULL,
                    action_id TEXT NOT NULL,
                    changed_at TEXT NOT NULL,
                    before_json TEXT,
                    after_json TEXT NOT NULL,
                    FOREIGN KEY (dataset_id, action_id)
                        REFERENCES actions (dataset_id, action_id)
                );
                CREATE INDEX IF NOT EXISTS history_dataset_action
                    ON action_history (dataset_id, action_id, audit_id DESC);
            """)

    @contextmanager
    def _connection(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(str(self.db_path), timeout=10,
                                     isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=10000")
        try:
            yield connection
        finally:
            connection.close()

    @staticmethod
    def _snapshot(row: sqlite3.Row) -> dict:
        return {"action": json.loads(row["payload_json"]),
                **{field: row[field] for field in _STATE_FIELDS}}

    def get_states(self, dataset_id: str) -> dict[str, dict]:
        dataset_id = _text(dataset_id, "資料集 ID", 128, required=True)
        with self._connection() as connection:
            rows = connection.execute(
                "SELECT * FROM actions WHERE dataset_id = ?", (dataset_id,)
            ).fetchall()
        return {row["action_id"]: {field: row[field] for field in _STATE_FIELDS}
                for row in rows}

    def save_action(
        self, dataset_id: str, action: dict, classification: str,
        reason: str, assignee: str, due_date: str, status: str,
        intervention_date: str = "",
    ) -> None:
        """Save feedback; retain the evidence captured on the first save.

        An assignment needs a follow-up date. Completing an avoidable action
        requires its actual intervention date so analysis does not invent one.
        Re-saving identical state is a no-op, rather than a misleading new event.
        """
        dataset_id = _text(dataset_id, "資料集 ID", 128, required=True)
        if not isinstance(action, dict):
            raise ValueError("action 必須是字典。")
        action_id = _text(action.get("id", action.get("action_id", "")),
                          "行動 ID", 200, required=True)
        if "id" in action and "action_id" in action:
            if action["id"] != action["action_id"]:
                raise ValueError("id 與 action_id 必須一致。")
        payload_json = _json(action)
        if classification not in CLASSIFICATIONS:
            raise ValueError("分類必須是待查、可避免或必要。")
        if status not in STATUSES:
            raise ValueError("狀態必須是待處理、進行中或已完成。")
        reason = _text(reason, "判定原因", 2000)
        assignee = _text(assignee, "負責人", 120)
        due_date = _date(due_date, "追蹤日期")
        intervention_date = _date(intervention_date, "介入日期")
        if classification in ("可避免", "必要") and not reason:
            raise ValueError("標記可避免或必要時，請填寫判定原因。")
        if assignee and not due_date:
            raise ValueError("指派負責人時，請設定追蹤日期。")
        if status == "已完成" and classification == "可避免" and not intervention_date:
            raise ValueError("完成可避免行動時，請填寫實際介入日期。")
        state = dict(classification=classification, reason=reason,
                     assignee=assignee, due_date=due_date, status=status,
                     intervention_date=intervention_date)
        with self._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                row = connection.execute(
                    "SELECT * FROM actions WHERE dataset_id = ? AND action_id = ?",
                    (dataset_id, action_id),
                ).fetchone()
                before = self._snapshot(row) if row is not None else None
                if row is not None:
                    if all(row[field] == value for field, value in state.items()):
                        connection.commit()
                        return
                    payload_json = row["payload_json"]
                now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
                after = {"action": json.loads(payload_json), **state, "updated_at": now}
                connection.execute("""
                    INSERT INTO actions (
                        dataset_id, action_id, payload_json, classification,
                        reason, assignee, due_date, status, intervention_date,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(dataset_id, action_id) DO UPDATE SET
                        classification = excluded.classification,
                        reason = excluded.reason,
                        assignee = excluded.assignee,
                        due_date = excluded.due_date,
                        status = excluded.status,
                        intervention_date = excluded.intervention_date,
                        updated_at = excluded.updated_at
                """, (dataset_id, action_id, payload_json, classification, reason,
                      assignee, due_date, status, intervention_date, now, now))
                connection.execute("""
                    INSERT INTO action_history (
                        dataset_id, action_id, changed_at, before_json, after_json
                    ) VALUES (?, ?, ?, ?, ?)
                """, (dataset_id, action_id, now,
                      _json(before) if before is not None else None, _json(after)))
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def list_actions(self, dataset_id: str) -> list[dict]:
        dataset_id = _text(dataset_id, "資料集 ID", 128, required=True)
        with self._connection() as connection:
            rows = connection.execute("""
                SELECT * FROM actions WHERE dataset_id = ?
                ORDER BY updated_at DESC, action_id
            """, (dataset_id,)).fetchall()
        return [{**json.loads(row["payload_json"]),
                 "action_id": row["action_id"], "dataset_id": row["dataset_id"],
                 **{field: row[field] for field in _STATE_FIELDS}}
                for row in rows]

    def history(self, dataset_id: str, action_id: str | None = None) -> list[dict]:
        dataset_id = _text(dataset_id, "資料集 ID", 128, required=True)
        query = "SELECT * FROM action_history WHERE dataset_id = ?"
        parameters = [dataset_id]
        if action_id is not None:
            parameters.append(_text(action_id, "行動 ID", 200, required=True))
            query += " AND action_id = ?"
        query += " ORDER BY audit_id DESC"
        with self._connection() as connection:
            rows = connection.execute(query, parameters).fetchall()
        return [{"audit_id": row["audit_id"], "dataset_id": row["dataset_id"],
                 "action_id": row["action_id"], "changed_at": row["changed_at"],
                 "before": json.loads(row["before_json"]) if row["before_json"] else None,
                 "after": json.loads(row["after_json"])} for row in rows]
