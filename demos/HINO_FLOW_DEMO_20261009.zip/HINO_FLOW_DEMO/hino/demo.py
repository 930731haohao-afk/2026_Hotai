"""Entirely synthetic, deterministic demonstration data with three anomalies."""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path
import random

import pandas as pd


def generate_demo() -> pd.DataFrame:
    rng = random.Random(20260922)
    rows = []
    first_day = date(2026, 8, 25)
    for day_index in range(28):
        day = first_day + timedelta(days=day_index)
        for vehicle_index in range(8):
            vehicle_id = f"DEMO-{vehicle_index + 1:02d}"
            if vehicle_index < 3:
                vehicle_type, route, site, operation, rate = "中型常溫車", "示範路線 A", "示範卸貨點 A", "一般配送", 19.5
            elif vehicle_index < 5:
                vehicle_type, route, site, operation, rate = "中型冷藏車", "示範路線 B", "示範冷鏈點 B", "冷鏈溫控", 24.0
            else:
                vehicle_type, route, site, operation, rate = "大型貨車", "示範路線 C", "示範物流點 C", "一般配送", 28.0
            distance = round(rng.uniform(75, 125), 1)
            idle = rng.uniform(14, 22) if vehicle_index < 3 else rng.uniform(26, 34) if vehicle_index < 5 else rng.uniform(12, 20)
            # Anomalies start only in the last week. Labels are deliberately not
            # provided to the model; a manager must supply operational context.
            if day_index >= 21 and vehicle_index < 3:
                idle += 27
                operation = "等待裝卸"
            if day_index >= 21 and 3 <= vehicle_index < 5:
                idle += 51
            trip_rate = rate + rng.uniform(-1.0, 1.0)
            if day_index >= 21 and vehicle_index == 7:
                trip_rate += 9.0
            rows.append({
                "trip_id": f"SYN-{day.strftime('%Y%m%d')}-{vehicle_index + 1:02d}",
                "vehicle_id": vehicle_id, "date": day.isoformat(), "vehicle_type": vehicle_type,
                "route": route, "distance_km": distance, "idle_minutes": round(idle, 1),
                "fuel_liters": round(distance * trip_rate / 100, 2), "site": site,
                "operation": operation, "load_tons": round(rng.uniform(2, 5) if vehicle_index < 5 else rng.uniform(7, 10), 1),
            })
    return pd.DataFrame(rows)


def get_demo_csv() -> bytes:
    return generate_demo().to_csv(index=False).encode("utf-8-sig")


if __name__ == "__main__":
    destination = Path(__file__).resolve().parent.parent / "data" / "demo_trips.csv"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(get_demo_csv())
    print(f"Wrote {destination}")
