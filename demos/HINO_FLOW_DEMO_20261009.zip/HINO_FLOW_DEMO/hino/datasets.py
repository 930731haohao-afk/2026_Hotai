"""Bounded local CSV versions and safe spreadsheet exports.

Only generated names are used for files. The visible upload filename is metadata,
never a path. A new dataset gets an isolated action workspace; appended journeys
retain that workspace so subsequent outcomes can be reviewed.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import uuid
from typing import Any

import pandas as pd

from .analytics import COLUMNS, MAX_ROWS, parse_csv


MAX_BYTES = 20 * 1024 * 1024
MAX_METADATA_BYTES = 1024 * 1024
_VERSION_NAME = re.compile(r"^[0-9a-f]{32}\.csv$")
_DIGEST = re.compile(r"^[0-9a-f]{64}$")
ACTION_COLUMNS = (
    "id", "title", "classification", "reason", "assignee", "due_date",
    "status", "intervention_date",
)


def _spreadsheet_value(value: Any) -> Any:
    """Prefix potential formulas while preserving actual numeric cell types."""
    if isinstance(value, str):
        stripped = value.lstrip()
        leading_space = value[:len(value) - len(stripped)]
        if any(char in leading_space for char in "\t\n\r") or stripped.startswith(("=", "+", "-", "@")):
            return "'" + value
    return value


def safe_csv(df: pd.DataFrame) -> bytes:
    """UTF-8 BOM CSV suitable for Excel; user-controlled strings cannot execute."""
    clean = df.copy(deep=True)
    for column in clean.columns:
        clean[column] = clean[column].map(_spreadsheet_value)
    clean.columns = [_spreadsheet_value(str(column)) for column in clean.columns]
    return clean.to_csv(index=False, lineterminator="\n").encode("utf-8-sig")


def export_action_csv(actions: list[dict]) -> bytes:
    """Export only the human-facing action fields, without internal storage data."""
    rows = [
        {**{key: action.get(key, "") for key in ACTION_COLUMNS},
         "id": action.get("id", action.get("action_id", ""))}
        for action in actions
    ]
    return safe_csv(pd.DataFrame(rows, columns=ACTION_COLUMNS))


def _upload_name(filename: str) -> str:
    name = str(filename).replace("\\", "/").rsplit("/", 1)[-1]
    name = "".join(char for char in name if ord(char) >= 32 and ord(char) != 127)
    return name[:240] or "uploaded.csv"


def _digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _bounded(data: bytes) -> None:
    if not isinstance(data, bytes):
        raise ValueError("CSV 必須為 bytes 格式。")
    if not data:
        raise ValueError("CSV 檔案沒有內容。")
    if len(data) > MAX_BYTES:
        raise ValueError("CSV 檔案不可超過 20 MB。")


def _normalized_csv(frame: pd.DataFrame) -> bytes:
    """Persist accepted source columns, without Excel escaping altering IDs."""
    clean = frame.loc[:, list(COLUMNS)].copy()
    clean["date"] = clean["date"].dt.strftime("%Y-%m-%d")
    return clean.to_csv(index=False, lineterminator="\n").encode("utf-8-sig")


def _record_key(record: dict) -> tuple:
    return tuple(None if pd.isna(record[column]) else record[column] for column in COLUMNS)


class DatasetLibrary:
    """One current pointer plus immutable, generated local CSV versions."""

    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._pointer = self.root / "current.json"

    def current(self) -> dict | None:
        if not self._pointer.exists():
            return None
        try:
            if self._pointer.resolve().parent != self.root:
                raise ValueError("資料集索引路徑不合法。")
            if self._pointer.stat().st_size > MAX_METADATA_BYTES:
                raise ValueError("資料集索引過大。")
            metadata = json.loads(self._pointer.read_text(encoding="utf-8"))
            if not isinstance(metadata, dict):
                raise ValueError("資料集索引格式錯誤。")
            version_file = metadata.get("version_file", "")
            if not isinstance(version_file, str) or not _VERSION_NAME.fullmatch(version_file):
                raise ValueError("資料集檔名不合法。")
            for field in ("workspace_id", "version_id"):
                if not isinstance(metadata.get(field), str) or not _DIGEST.fullmatch(metadata[field]):
                    raise ValueError("資料集識別碼不合法。")
            source_path = self.root / version_file
            if source_path.resolve().parent != self.root:
                raise ValueError("資料集路徑不合法。")
            if source_path.stat().st_size > MAX_BYTES:
                raise ValueError("已儲存資料超過 20 MB。")
            data = source_path.read_bytes()
            _bounded(data)
            if _digest(data) != metadata["version_id"]:
                raise ValueError("資料集內容與索引不符，請重新匯入。")
            return {**metadata, "data": data}
        except (OSError, json.JSONDecodeError) as error:
            raise ValueError("無法讀取本機資料集，請重新匯入 CSV。") from error

    def import_new(self, data: bytes, filename: str) -> dict:
        """Validate before writing, retaining original input quality/fingerprint."""
        _bounded(data)
        frame, quality = parse_csv(data)
        if frame.empty:
            raise ValueError("CSV 沒有有效資料，未變更目前資料集。")
        return self._save(_normalized_csv(frame), {
            "workspace_id": _digest(data),
            "filename": _upload_name(filename),
            "source_sha256": _digest(data),
            "quality": quality,
            "row_count": len(frame),
            "operation": "import",
            "added_rows": len(frame),
            "skipped_duplicates": int(quality.get("identical_duplicates", 0)),
        })

    def append(self, data: bytes, filename: str) -> dict:
        """Append accepted trips, rejecting ID conflicts before any disk change."""
        _bounded(data)
        previous = self.current()
        if previous is None:
            raise ValueError("請先建立資料集，再追加新趟次。")
        incoming, quality = parse_csv(data)
        if incoming.empty:
            raise ValueError("CSV 沒有有效資料，未變更目前資料集。")
        if quality.get("conflict_ids"):
            raise ValueError("追加檔案內有內容衝突的 trip_id，請先修正；目前資料未變更。")
        existing, _ = parse_csv(previous["data"])
        by_id = {
            record["trip_id"]: _record_key(record)
            for record in existing.to_dict(orient="records")
        }
        additions: list[dict] = []
        skipped = int(quality.get("identical_duplicates", 0))
        for record in incoming.to_dict(orient="records"):
            trip_id = record["trip_id"]
            key = _record_key(record)
            if trip_id in by_id:
                if by_id[trip_id] != key:
                    raise ValueError(f"trip_id「{trip_id[:80]}」與已儲存內容衝突；目前資料未變更。")
                skipped += 1
            else:
                by_id[trip_id] = key
                additions.append(record)
        if len(existing) + len(additions) > MAX_ROWS:
            raise ValueError("合併後超過 100,000 筆，請另建資料集；目前資料未變更。")
        merged = existing if not additions else pd.concat([
            existing, pd.DataFrame(additions, columns=COLUMNS),
        ], ignore_index=True)
        merged = merged.sort_values(["date", "trip_id"], kind="stable").reset_index(drop=True)
        return self._save(_normalized_csv(merged), {
            "workspace_id": previous["workspace_id"],
            "filename": _upload_name(filename),
            "source_sha256": _digest(data),
            "quality": quality,
            "row_count": len(merged),
            "operation": "append",
            "previous_version_id": previous["version_id"],
            "added_rows": len(additions),
            "skipped_duplicates": skipped,
        })

    def _save(self, data: bytes, metadata: dict) -> dict:
        _bounded(data)
        version_file = f"{uuid.uuid4().hex}.csv"
        destination = self.root / version_file
        pointer_temp = self.root / f".{uuid.uuid4().hex}.tmp"
        saved = {
            **metadata,
            "version_file": version_file,
            "version_id": _digest(data),
            "imported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        metadata_bytes = (json.dumps(saved, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
        if len(metadata_bytes) > MAX_METADATA_BYTES:
            raise ValueError("資料品質報告過大，請先修正來源 CSV 的衝突資料；目前資料未變更。")
        committed = False
        created = False
        try:
            with destination.open("xb") as stream:
                created = True
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            with pointer_temp.open("xb") as stream:
                stream.write(metadata_bytes)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(pointer_temp, self._pointer)
            committed = True
        finally:
            if pointer_temp.exists():
                pointer_temp.unlink()
            if created and not committed and destination.exists():
                destination.unlink()
        return {**saved, "data": data}
