"""Export synthetic evidence for the mobile prototype; no runtime/API data."""
import json
import sys
from pathlib import Path
from datetime import date, timedelta

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
from hino.demo import generate_demo
from hino.analytics import parse_csv, analyze

frame, _ = parse_csv(generate_demo().to_csv(index=False).encode('utf-8'))
analysis = analyze(frame)
route = frame[frame.route == '示範路線 A']
last = route[route.date >= '2026-09-15']
before = [{'date': r.date.date().isoformat(), 'idle': r.idle_minutes, 'vehicle': r.vehicle_id}
          for r in last.itertuples()]
after = [{'date': (date(2026, 9, 22) + timedelta(days=d)).isoformat(),
          'idle': round(30.5 + (d % 3) * .7 + v * .4, 1), 'vehicle': f'DEMO-{v+1:02d}'}
         for d in range(7) for v in range(3)]
weekly = []
for week in range(4):
    start = date(2026, 8, 25) + timedelta(days=7*week)
    end = start + timedelta(days=6)
    section = route[(route.date >= str(start)) & (route.date <= str(end))]
    weekly.append({'label': f'{start.month}/{start.day}', 'idle': round(section.idle_minutes.mean(), 1), 'n': len(section)})
seed = {'source': '固定種子的合成車次；後期另為假設情境，不是實際成效',
        'summary': analysis['summary'], 'weekly': weekly, 'before': before, 'after': after,
        'route': '示範路線 A', 'site': '示範卸貨點 A', 'baseline': 18.6,
        'current': round(last.idle_minutes.mean(), 2), 'beforeN': len(last)}
destination = BASE / 'mobile' / 'seed.js'
destination.write_text('window.FlowSeed = ' + json.dumps(seed, ensure_ascii=False, separators=(',', ':')) + ';\n', encoding='utf-8')
print(f'Exported {len(before)} baseline-window trips and {len(after)} explicitly synthetic follow-up trips.')
