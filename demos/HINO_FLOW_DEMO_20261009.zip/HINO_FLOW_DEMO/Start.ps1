param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$pythonPath = Join-Path $projectRoot '.venv\Scripts\python.exe'
$appPath = Join-Path $projectRoot 'app.py'
$runtimePath = Join-Path $projectRoot 'runtime'
if (-not (Test-Path -LiteralPath $pythonPath)) {
    throw 'Python environment not found. Follow README.md to install requirements first.'
}
New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
$pidPath = Join-Path $runtimePath 'server.pid'
$existingServer = $null
if (Test-Path -LiteralPath $pidPath) {
    $serverProcessId = 0
    if ([int]::TryParse((Get-Content -LiteralPath $pidPath -Raw).Trim(), [ref]$serverProcessId)) {
        $candidate = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction SilentlyContinue
        if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($appPath) -and $candidate.CommandLine.Contains('streamlit')) {
            $existingServer = $candidate
        }
    }
}
if (-not $existingServer) {
    $listener = Get-NetTCPConnection -LocalPort 8501 -State Listen -ErrorAction SilentlyContinue
    if ($listener) { throw 'Port 8501 is in use by another app. Close it before starting this MVP.' }
    $serverArguments = @('-m', 'streamlit', 'run', ('"' + $appPath + '"'), '--server.address=127.0.0.1', '--server.port=8501', '--server.headless=true')
    $server = Start-Process -FilePath $pythonPath -ArgumentList $serverArguments -WorkingDirectory $projectRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtimePath 'server.out.log') -RedirectStandardError (Join-Path $runtimePath 'server.err.log') -PassThru
    Set-Content -LiteralPath $pidPath -Value $server.Id -Encoding ascii
}
$ready = $false
for ($attempt = 0; $attempt -lt 40; $attempt++) {
    try {
        $response = Invoke-WebRequest -Uri 'http://127.0.0.1:8501/_stcore/health' -UseBasicParsing -TimeoutSec 2
        if ($response.StatusCode -eq 200) { $ready = $true; break }
    } catch { Start-Sleep -Milliseconds 500 }
}
if (-not $ready) { throw 'The app did not start. See runtime/server.err.log.' }
Write-Output 'HINO MVP ready: http://127.0.0.1:8501'
if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:8501' }
