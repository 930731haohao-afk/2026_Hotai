import csv
import io
import unittest

import pandas as pd

from hino.analytics import analyze, parse_csv, week_review
from hino.demo import generate_demo, get_demo_csv


def encode(rows):
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().encode("utf-8")


class ParseTests(unittest.TestCase):
    def setUp(self):
        self.rows = generate_demo().head(5).to_dict("records")

    def test_demo_roundtrip_dates_and_counts(self):
        frame, quality = parse_csv(get_demo_csv())
        self.assertEqual((quality["rows"], quality["accepted"], quality["rejected"]), (224, 224, 0))
        self.assertEqual(frame["vehicle_id"].nunique(), 8)
        self.assertEqual(frame["date"].nunique(), 28)
        self.assertEqual(quality["end_date"], "2026-09-21")
        self.assertTrue(pd.api.types.is_datetime64_any_dtype(frame["date"]))

    def test_bad_and_ambiguous_dates_rejected_with_row_evidence(self):
        for invalid in ["09/01/2026", "2026-09-01T03:00:00Z", "2026-02-30", "2026-9-1", "9999-01-01"]:
            with self.subTest(invalid=invalid):
                rows = [dict(row) for row in self.rows]
                rows[0]["date"] = invalid
                _, quality = parse_csv(encode(rows))
                self.assertEqual(quality["rejected"], 1)
                self.assertIn("第 2 列", quality["errors"][0])

    def test_negative_nonfinite_and_non_numeric_are_excluded(self):
        for field in ["distance_km", "idle_minutes", "fuel_liters", "load_tons"]:
            for invalid in ["-1", "inf", "nan", "bad", "1e300"]:
                with self.subTest(field=field, invalid=invalid):
                    rows = [dict(row) for row in self.rows]
                    rows[0][field] = invalid
                    frame, quality = parse_csv(encode(rows))
                    self.assertEqual(len(frame), 4)
                    self.assertEqual(quality["rejected"], 1)

    def test_duplicates_exact_keep_one_conflicting_reject_all(self):
        frame, quality = parse_csv(encode(self.rows + [self.rows[0]]))
        self.assertEqual(len(frame), 5)
        self.assertEqual(quality["duplicates"], 1)
        self.assertEqual(quality["identical_duplicates"], 1)
        conflicting = dict(self.rows[0], idle_minutes=999)
        frame, quality = parse_csv(encode(self.rows + [conflicting]))
        self.assertEqual(len(frame), 4)
        self.assertEqual(quality["rejected"], 2)
        self.assertEqual(quality["identical_duplicates"], 0)
        self.assertEqual(quality["conflict_ids"], [self.rows[0]["trip_id"]])

    def test_missing_optional_fuel_allowed_and_no_aggregate_claim(self):
        for row in self.rows:
            row.pop("fuel_liters")
            row.pop("load_tons")
        frame, quality = parse_csv(encode(self.rows))
        self.assertEqual(quality["missing_fuel"], 5)
        self.assertEqual(quality["missing_load"], 5)
        report = analyze(frame)
        self.assertIsNone(report["summary"]["fuel_liters"])
        self.assertIsNone(report["summary"]["fuel_per_100km"])

    def test_invalid_headers_and_empty_files_fail_clearly(self):
        for data in [b"", b"trip_id,date\na,2026-09-21\n", b"trip_id,trip_id\na,b\n", b"\xff"]:
            with self.subTest(data=data):
                with self.assertRaises(ValueError):
                    parse_csv(data)

    def test_malformed_row_counted_as_rejected(self):
        data = encode(self.rows) + b"incomplete,row\n"
        _, quality = parse_csv(data)
        self.assertEqual(quality["rows"], 6)
        self.assertEqual(quality["rejected"], 1)


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.frame, self.quality = parse_csv(get_demo_csv())

    def test_three_synthetic_candidates_with_context_and_history(self):
        report = analyze(self.frame)
        self.assertEqual(report["current_start"], "2026-09-15")
        self.assertEqual(report["current_end"], "2026-09-21")
        self.assertEqual(report["summary"]["trips"], 56)
        self.assertEqual(len(report["actions"]), 3)
        cold = next(a for a in report["actions"] if a["site"] == "示範冷鏈點 B")
        self.assertEqual(cold["label"], "待查")
        self.assertTrue(any("必要怠速" in value for value in cold["caveats"]))
        for action in report["actions"]:
            self.assertLess(action["baseline_end"], action["current_start"])
            self.assertGreaterEqual(action["current_n"], 3)
            self.assertGreaterEqual(action["baseline_n"], 3)
            self.assertIn("vehicle_type", action["scope"])
            self.assertIn("route", action["scope"])

    def test_missing_fuel_suppresses_entire_affected_group(self):
        selected = self.frame["vehicle_id"] == "DEMO-08"
        self.frame.loc[self.frame.loc[selected].index[-1], "fuel_liters"] = float("nan")
        report = analyze(self.frame)
        self.assertIsNone(report["summary"]["fuel_liters"])
        self.assertFalse(any(a["kind"] == "fuel" for a in report["actions"]))
        self.assertEqual(sum(a["kind"] == "idle" for a in report["actions"]), 2)

    def test_history_never_uses_future_rows(self):
        historical_end = "2026-09-14"
        first = analyze(self.frame, historical_end)
        cutoff = self.frame["date"] <= pd.Timestamp(historical_end)
        second = analyze(self.frame.loc[cutoff], historical_end)
        self.assertEqual(first, second)
        self.assertEqual(first["actions"], [])
        # Even extreme future corruption must not change an earlier report.
        self.frame.loc[~cutoff, "idle_minutes"] = 10_000
        self.assertEqual(first, analyze(self.frame, historical_end))

    def test_too_few_baseline_trips_produces_no_comparative_action(self):
        one_vehicle = self.frame.loc[self.frame["vehicle_id"] == "DEMO-08"]
        short = pd.concat([one_vehicle.iloc[:2], one_vehicle.iloc[-7:]])
        self.assertEqual(analyze(short)["actions"], [])

    def test_zero_distance_has_no_infinity_and_no_fuel_ranking(self):
        self.frame.loc[self.frame["vehicle_id"] == "DEMO-08", "distance_km"] = 0
        report = analyze(self.frame)
        self.assertFalse(any(a["kind"] == "fuel" for a in report["actions"]))
        report = analyze(self.frame.loc[self.frame["vehicle_id"] == "DEMO-08"])
        self.assertIsNone(report["summary"]["fuel_per_100km"])

    def test_zero_fuel_while_driving_is_flagged_and_not_ranked(self):
        demo = generate_demo()
        demo.loc[demo.index[-1], "fuel_liters"] = 0
        frame, quality = parse_csv(demo.to_csv(index=False).encode())
        self.assertEqual(quality["unreliable_fuel"], 1)
        report = analyze(frame)
        self.assertIsNone(report["summary"]["fuel_per_100km"])
        self.assertFalse(any(a["kind"] == "fuel" for a in report["actions"]))

    def test_fuel_is_distance_weighted_not_mean_of_trip_rates(self):
        sample = self.frame.tail(2).copy()
        sample["distance_km"] = [10.0, 90.0]
        sample["fuel_liters"] = [10.0, 9.0]
        self.assertEqual(analyze(sample)["summary"]["fuel_per_100km"], 19.0)

    def test_different_site_cannot_supply_idle_baseline(self):
        cold = self.frame["vehicle_type"] == "中型冷藏車"
        previous = self.frame["date"] < pd.Timestamp("2026-09-15")
        self.frame.loc[cold & previous, "site"] = "另一個地點"
        self.assertFalse(any(a["site"] == "示範冷鏈點 B" for a in analyze(self.frame)["actions"]))

    def test_action_id_stable_under_input_row_order(self):
        one = [a["id"] for a in analyze(self.frame)["actions"]]
        two = [a["id"] for a in analyze(self.frame.sample(frac=1, random_state=1))["actions"]]
        self.assertEqual(one, two)

    def test_review_has_counts_raw_values_and_no_causal_claim(self):
        action = analyze(self.frame)["actions"][0]
        review = week_review(self.frame, action, "2026-09-15")
        self.assertTrue(review["comparable"])
        self.assertFalse(review["controls_available"])
        self.assertGreater(review["differences"]["idle_minutes_per_trip"], 0)
        self.assertGreaterEqual(review["before"]["trips"], 3)
        self.assertIn("無法將變化歸因", review["caveats"][0])

    def test_incomplete_followup_never_reports_difference(self):
        action = analyze(self.frame)["actions"][0]
        review = week_review(self.frame, action, "2026-09-20")
        self.assertFalse(review["complete"])
        self.assertFalse(review["comparable"])
        self.assertIsNone(review["differences"]["idle_minutes_per_trip"])


if __name__ == "__main__":
    unittest.main()
