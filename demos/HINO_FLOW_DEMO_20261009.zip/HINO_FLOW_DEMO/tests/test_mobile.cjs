// Run: node --test tests/test_mobile.cjs
// Pure state-machine checks; these do not validate real sensors or audio output.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const core = require('../mobile/core.js');

const NOW = '2026-09-23T10:00:00+08:00';
const assignment = {classification: '可改善', owner: '調度組', due: '2026-09-29', note: '已確認卸貨窗口，改採分時預約。'};
const series = (start, count, idle) => Array.from({length: count}, (_, index) => ({
  date: new Date(Date.parse(start + 'T00:00:00Z') + index * 86400000).toISOString().slice(0, 10),
  idle,
}));
const dataset = () => ({before: series('2026-09-15', 7, 44), after: series('2026-09-22', 7, 30)});
function moving() { const state = core.initial(); state.driving = true; return state; }
function draft() {
  const state = core.initial();
  const action = core.feedback(state, 'seed-wait', '卸貨排程等待', '上午卸貨排隊，等待月台。', NOW);
  return {state, action};
}
function assigned() {
  const pair = draft();
  pair.state.role = 'manager';
  core.assign(pair.state, pair.action.id, assignment, NOW);
  return pair;
}
function completed() {
  const pair = assigned();
  core.complete(pair.state, pair.action.id, '2026-09-22', NOW);
  return pair;
}

test('initial state is stopped with seed review and no granted voice consent', () => {
  const state = core.initial();
  assert.equal(state.driving, false);
  assert.equal(state.events[0].id, 'seed-wait');
  assert.deepEqual(state.actions, []);
  assert.equal(Boolean(state.voice || state.voiceEnabled || state.voiceConsent), false);
  assert.equal(core.receive(state, 'idle', 0).record, false);
});

test('reload retains completed workflow but resets moving state and voice', () => {
  const {state, action} = completed();
  state.driving = true; state.voiceEnabled = true; state.voiceConsent = true;
  state.signal = false; state.refrigeration = true;
  state.gate.eco = 99000; state.gate.safety = 98000;
  const restored = core.restore(JSON.stringify(state));
  assert.equal(restored.driving, false);
  assert.equal(Boolean(restored.voice || restored.voiceEnabled || restored.voiceConsent), false);
  assert.equal(restored.actions[0].id, action.id);
  assert.equal(restored.actions[0].status, '已完成');
  assert.equal(restored.actions[0].intervention, '2026-09-22');
  assert.equal(restored.audit.length, 3);
  assert.equal(restored.gate.eco, null);
});

test('invalid persisted data returns a clean demo rather than granting manager role', () => {
  for (const raw of ['bad JSON', 'null', '{}', JSON.stringify({version: -1, role: 'manager', events: [], actions: [], audit: []})]) {
    const state = core.restore(raw);
    assert.equal(state.role, 'driver');
    assert.equal(state.driving, false);
    assert.equal(state.events[0].id, 'seed-wait');
  }
  const source = core.initial(); source.role = 'administrator';
  assert.equal(core.restore(JSON.stringify(source)).role, 'driver');
});

test('signal loss rejects incoming events without recording or consuming cooldown', () => {
  const state = moving(); state.signal = false;
  const before = state.events.length;
  for (const kind of ['ldws', 'idle', 'acceleration']) {
    const result = core.receive(state, kind, 10000);
    assert.equal(result.allowed, false);
    assert.equal(result.record, false);
  }
  assert.equal(state.events.length, before);
  assert.deepEqual(state.gate.signatures, {});
  assert.equal(state.gate.eco, null);
});

test('refrigeration or PTO suppresses extra idle coaching but preserves its review evidence', () => {
  for (const flag of ['refrigeration', 'pto']) {
    const state = moving(); state[flag] = true;
    const result = core.receive(state, 'idle', 0);
    assert.equal(result.allowed, false);
    assert.equal(result.record, true);
    assert.equal(result.event.suppressed, true);
    assert.ok(state.events.some(event => event.id === result.event.id));
    assert.equal(state.gate.eco, null);
  }
});

test('safety event preempts the next 10 seconds of extra eco coaching', () => {
  const state = moving();
  assert.equal(core.receive(state, 'ldws', 0).priority, 'safety');
  const suppressed = core.receive(state, 'acceleration', 9999);
  assert.equal(suppressed.allowed, false);
  assert.equal(suppressed.record, true);
  assert.match(suppressed.text, /原車警示優先/);
  assert.equal(core.receive(state, 'idle', 10000).allowed, true);
});

test('eco delivery is limited to one per 60 seconds, including text-only delivery', () => {
  const state = moving();
  assert.equal(core.receive(state, 'acceleration', 0).allowed, true);
  const blocked = core.receive(state, 'idle', 59999);
  assert.equal(blocked.allowed, false);
  assert.equal(blocked.record, true);
  assert.match(blocked.text, /60 秒/);
  assert.equal(core.receive(state, 'acceleration', 60000).allowed, true);
});

test('3-second extra coaching duplicate gate does not create two event records', () => {
  const state = moving();
  const first = core.receive(state, 'acceleration', 0);
  const count = state.events.length;
  const duplicate = core.receive(state, 'acceleration', 2999);
  assert.equal(duplicate.record, false);
  assert.equal(state.events.length, count);
  const later = core.receive(state, 'acceleration', 3000);
  assert.equal(later.record, true);
  assert.notEqual(later.event.id, first.event.id);
});

test('separate OEM safety warnings do not inherit the app coaching duplicate cooldown', () => {
  const state = moving();
  assert.equal(core.receive(state, 'ldws', 1000).allowed, true);
  const second = core.receive(state, 'ldws', 2000);
  assert.equal(second.allowed, true, 'App must not depict its 3s coaching gate as suppressing a new OEM warning');
  assert.equal(second.priority, 'safety');
});

test('event injection rejects unknown events and invalid timestamps', () => {
  const state = moving();
  assert.throws(() => core.receive(state, 'auto_brake', 0), /未知/);
  for (const now of [NaN, Infinity, -1]) assert.throws(() => core.receive(state, 'idle', now), /時間無效/);
});

test('driver feedback requires stopped state, a supported category, and a known event', () => {
  const state = moving();
  assert.throws(() => core.feedback(state, 'seed-wait', '卸貨排程等待', '', NOW), /結束/);
  state.driving = false;
  assert.throws(() => core.feedback(state, 'seed-wait', '其他', '', NOW), /選擇作業原因/);
  assert.throws(() => core.feedback(state, 'does-not-exist', '卸貨排程等待', '', NOW), /找不到/);
  assert.throws(() => core.feedback(state, 'seed-wait', '卸貨排程等待', '字'.repeat(301), NOW), /300/);
  assert.equal(state.actions.length, 0);
});

test('one feedback yields exactly one action and one audit item; repeat submissions are rejected', () => {
  const {state, action} = draft();
  assert.equal(action.eventId, 'seed-wait');
  assert.equal(action.suggestedOwner, '調度組');
  assert.equal(action.status, '待確認');
  assert.equal(state.events[0].reviewed, true);
  assert.equal(state.actions.length, 1);
  assert.equal(state.audit.length, 1);
  assert.throws(() => core.feedback(state, 'seed-wait', '卸貨排程等待', '另一份', NOW), /已送出/);
  assert.equal(state.actions.length, 1);
  assert.equal(state.audit.length, 1);
});

test('assignment gate uses the explicit manager demo role and never falls back from unknown roles', () => {
  const {state, action} = draft();
  for (const role of ['driver', undefined, 'admin', '']) {
    state.role = role;
    assert.throws(() => core.assign(state, action.id, assignment, NOW), /角色模擬，非登入權限/);
  }
  state.role = 'manager';
  core.assign(state, action.id, assignment, NOW);
  assert.equal(action.status, '進行中');
  // Setting a role in local state is a demo affordance, not authentication.
  assert.equal(core.restore(JSON.stringify(state)).role, 'manager');
});

test('assignment validates real dates, classification, owner, and a review explanation before mutation', () => {
  const {state, action} = draft(); state.role = 'manager';
  for (const patch of [
    {due: '2026-02-30'}, {due: '2026-9-23'}, {due: '2026-09-23T10:00:00Z'},
    {classification: '已解決'}, {owner: 'anyone'}, {note: '   '}, {note: '字'.repeat(301)},
  ]) {
    assert.throws(() => core.assign(state, action.id, {...assignment, ...patch}, NOW));
    assert.equal(action.status, '待確認');
    assert.equal(action.owner, '');
  }
  assert.equal(core.validDate('2028-02-29'), true);
  assert.equal(core.validDate('2026-02-29'), false);
});

test('necessary-operation classification does not become a completed intervention', () => {
  const {state, action} = draft(); state.role = 'manager';
  core.assign(state, action.id, {...assignment, classification: '必要作業'}, NOW);
  assert.equal(action.status, '必要作業');
  assert.throws(() => core.complete(state, action.id, '2026-09-22', NOW), /覆核與指派/);
  assert.equal(action.intervention, '');
});

test('completion requires assigned manager workflow and records intervention separately from due date', () => {
  const {state, action} = draft();
  assert.throws(() => core.complete(state, action.id, '2026-09-22', NOW));
  state.role = 'manager';
  assert.throws(() => core.complete(state, action.id, '2026-09-22', NOW));
  core.assign(state, action.id, assignment, NOW);
  assert.throws(() => core.complete(state, action.id, '2026-02-30', NOW));
  core.complete(state, action.id, '2026-09-22', NOW);
  assert.equal(action.status, '已完成');
  assert.equal(action.intervention, '2026-09-22');
  assert.equal(action.due, '2026-09-29');
  assert.equal(state.audit.length, 3);
  assert.throws(() => core.complete(state, action.id, '2026-09-23', NOW), /覆核與指派/);
});

test('a future planned date cannot be marked as an actual completed intervention', () => {
  const {state, action} = assigned();
  assert.throws(() => core.complete(state, action.id, '2099-01-01', NOW), /日期|未來|介入/);
  assert.equal(action.status, '進行中');
  assert.equal(action.intervention, '');
});

test('review without loaded follow-up shows baseline and no invented result', () => {
  const {action} = completed();
  const result = core.review(action, dataset(), false);
  assert.equal(result.before, 44);
  assert.equal(result.beforeN, 7);
  assert.equal(result.after, null);
  assert.equal(result.afterN, 0);
  assert.equal(result.change, null);
  assert.match(result.message, /尚未完整|樣本不足/);
});

test('loaded review uses the exact 7-day windows and discloses descriptive synthetic status', () => {
  const {action} = completed();
  const data = dataset();
  data.before.push({date: '2026-09-14', idle: 999});
  data.after.push({date: '2026-09-29', idle: 999});
  const result = core.review(action, data, true);
  assert.equal(result.before, 44);
  assert.equal(result.after, 30);
  assert.equal(result.beforeN, 7);
  assert.equal(result.afterN, 7);
  assert.ok(Math.abs(result.change - (30 - 44) / 44 * 100) < 1e-10);
  assert.match(result.message, /合成資料/);
  assert.match(result.message, /不是實測節油或因果效果/);
});

test('changing intervention date re-slices rows; it does not reuse fixed dashboard numbers', () => {
  const {action} = completed();
  action.intervention = '2026-09-23';
  const result = core.review(action, dataset(), true);
  assert.equal(result.beforeN, 7);
  assert.equal(result.afterN, 6);
  assert.ok(Math.abs(result.before - (44 * 6 + 30) / 7) < 1e-10);
  assert.equal(result.change, null, 'Sep 29 is required to complete the after window');
});

test('unrelated events cannot borrow seed waiting-event improvement figures', () => {
  const state = moving();
  const event = core.receive(state, 'ldws', 1000).event;
  state.driving = false;
  const action = core.feedback(state, event.id, '臨時路況', '事件待查', NOW);
  state.role = 'manager';
  core.assign(state, action.id, {...assignment, owner: '車隊教練'}, NOW);
  core.complete(state, action.id, '2026-09-22', NOW);
  const result = core.review(action, dataset(), true);
  assert.equal(action.comparable, false);
  assert.equal(result.before, null);
  assert.equal(result.after, null);
  assert.equal(result.change, null);
  assert.match(result.message, /不套用其他事件/);
});

test('incomplete period, insufficient samples, and zero baseline never yield a savings percentage', () => {
  const {action} = completed();
  const incomplete = dataset(); incomplete.after = incomplete.after.slice(0, 3);
  assert.equal(core.review(action, incomplete, true).change, null);
  const sparse = dataset(); sparse.before = sparse.before.slice(0, 2);
  assert.equal(core.review(action, sparse, true).change, null);
  const zero = dataset(); zero.before = zero.before.map(row => ({...row, idle: 0}));
  assert.equal(core.review(action, zero, true).change, null);
});

test('shipped synthetic seed supplies 21 matching trips per week without leaking follow-up before loading', () => {
  const context = {window: {}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', 'mobile', 'seed.js'), 'utf8'), context);
  const seed = context.window.FlowSeed;
  const {action} = completed();
  const before = core.review(action, seed, false);
  assert.equal(before.beforeN, 21);
  assert.equal(before.afterN, 0);
  assert.equal(before.change, null);
  const after = core.review(action, seed, true);
  assert.equal(after.beforeN, 21);
  assert.equal(after.afterN, 21);
  assert.ok(Math.abs(after.before - seed.current) < 0.01);
  assert.ok(after.after > 0 && after.after < after.before);
  assert.match(seed.source, /合成/);
  assert.match(seed.source, /不是實際成效/);
});

test('reclassifying a completed action does not keep displaying its prior intervention result', () => {
  for (const classification of ['必要作業', '可改善']) {
    const {state, action} = completed();
    core.assign(state, action.id, {...assignment, classification, note: '主管重新確認作業脈絡。'}, NOW);
    assert.notEqual(action.status, '已完成');
    assert.equal(core.review(action, dataset(), true).change, null);
  }
});
