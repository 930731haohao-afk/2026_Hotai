// Run with: node tests/test_voice.cjs
// Uses fake DOM, clock, telemetry timers and speech; never plays actual audio.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'assets', 'voice_demo.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(source);

function harness({supported = true, finishSpeech = true} = {}) {
  const elements = new Map();
  const timers = new Map();
  const docHandlers = new Map();
  const pageHandlers = new Map();
  let now = 0;
  let timerId = 0;
  let cancelCount = 0;
  const utterances = [];
  const get = id => {
    if (!elements.has(id)) elements.set(id, {
      textContent: '', hidden: false, checked: false, disabled: false,
      className: '', value: id === 'scenario' ? 'smooth' : '',
      handlers: new Map(),
      addEventListener(event, fn) { this.handlers.set(event, fn); },
    });
    return elements.get(id);
  };
  const document = {
    hidden: false,
    getElementById: get,
    addEventListener(event, fn) { docHandlers.set(event, fn); },
  };
  const speech = {
    speaking: false,
    getVoices() { return [{lang: 'en-US'}, {lang: 'zh-TW'}]; },
    cancel() { cancelCount += 1; this.speaking = false; },
    speak(utterance) {
      utterances.push(utterance);
      this.speaking = true;
      utterance.onstart();
      if (finishSpeech) { this.speaking = false; utterance.onend(); }
    },
  };
  const window = {addEventListener(event, fn) { pageHandlers.set(event, fn); }};
  function Utterance(text) { this.text = text; }
  if (supported) Object.assign(window, {speechSynthesis: speech, SpeechSynthesisUtterance: Utterance});
  const addTimer = (fn, period, repeat) => {
    const id = ++timerId;
    timers.set(id, {fn, period, repeat, due: now + period});
    return id;
  };
  const context = {
    window, document, SpeechSynthesisUtterance: Utterance,
    performance: {now: () => now},
    setInterval: (fn, ms) => addTimer(fn, ms, true),
    clearInterval: id => timers.delete(id),
    setTimeout: (fn, ms) => addTimer(fn, ms, false),
    clearTimeout: id => timers.delete(id),
  };
  vm.runInNewContext(source, context);
  const dispatch = (id, event) => {
    const element = get(id);
    assert.equal(element.disabled, false, `${id} must be enabled before interaction`);
    const handler = element.handlers.get(event);
    assert.ok(handler, `${id} must handle ${event}`);
    handler();
  };
  return {
    get, window, document, utterances, speech,
    evaluate: window.HinoVoiceDemo.evaluateTelemetry,
    click: id => dispatch(id, 'click'),
    scenario(value) { get('scenario').value = value; dispatch('scenario', 'change'); },
    consent(value) { get('voice-enabled').checked = value; dispatch('voice-enabled', 'change'); },
    advance(ms) {
      const target = now + ms;
      while (true) {
        const pending = [...timers].filter(([, timer]) => timer.due <= target).sort((a, b) => a[1].due - b[1].due);
        if (!pending.length) break;
        const [id, timer] = pending[0];
        now = timer.due;
        if (timer.repeat) timer.due += timer.period;
        else timers.delete(id);
        timer.fn();
      }
      now = target;
    },
    delayedSample(ms) {
      // Simulate a stalled event loop: receive exactly one late sample.
      now += ms;
      for (const timer of [...timers.values()]) {
        if (timer.repeat) { timer.due = now + timer.period; timer.fn(); }
      }
    },
    hide() { document.hidden = true; docHandlers.get('visibilitychange')(); },
    pagehide() { pageHandlers.get('pagehide')(); },
    cancelCount: () => cancelCount,
  };
}

let passed = 0;
function test(name, fn) {
  fn();
  passed += 1;
  console.log(`PASS ${name}`);
}
const sample = {speed_kmh: 35, acceleration_mps2: 2.2, idle_seconds: 0, engine_on: true, refrigerated: false, pto: false};

test('three valid consecutive moving samples trigger exactly one short reminder', () => {
  const h = harness();
  let r = h.evaluate(sample);
  assert.equal(r.event, null);
  r = h.evaluate(sample, r.state);
  assert.equal(r.event, null);
  r = h.evaluate(sample, r.state);
  assert.equal(r.event.kind, 'acceleration');
  assert.ok([...r.event.text].length <= 40);
  r = h.evaluate(sample, r.state);
  assert.equal(r.event, null, 'same episode is not queued repeatedly');
});

test('below-threshold sample breaks acceleration streak', () => {
  const h = harness();
  let r = h.evaluate(sample);
  r = h.evaluate(sample, r.state);
  r = h.evaluate({...sample, acceleration_mps2: 1.99}, r.state);
  assert.equal(r.state.accelStreak, 0);
  r = h.evaluate(sample, r.state);
  assert.equal(r.event, null);
  assert.equal(r.state.accelStreak, 1);
});

test('idle boundary at 180s; refrigeration, PTO and engine-off exclusions', () => {
  const h = harness();
  const stopped = {...sample, speed_kmh: 0, acceleration_mps2: 0, idle_seconds: 179};
  assert.equal(h.evaluate(stopped).event, null);
  stopped.idle_seconds = 180;
  assert.equal(h.evaluate(stopped).event.kind, 'idle');
  assert.ok([...h.evaluate(stopped).event.text].length <= 40);
  assert.equal(h.evaluate({...stopped, refrigerated: true}).event.kind, 'suppressed_idle');
  assert.equal(h.evaluate({...stopped, pto: true}).event.kind, 'suppressed_idle');
  assert.equal(h.evaluate({...stopped, engine_on: false}).event, null);
});

test('invalid telemetry resets detection without any reminder', () => {
  const h = harness();
  for (const invalid of [{speed_kmh: NaN}, {speed_kmh: -1}, {acceleration_mps2: Infinity}, {idle_seconds: -1}, {pto: 'false'}]) {
    const result = h.evaluate({...sample, ...invalid}, {accelStreak: 2, latched: null});
    assert.equal(result.event, null);
    assert.equal(result.state.accelStreak, 0);
  }
});

test('initial load never speaks; manual start without consent remains muted', () => {
  const h = harness();
  assert.equal(h.get('voice-enabled').checked, false);
  h.advance(60000);
  assert.equal(h.utterances.length, 0);
  assert.equal(h.get('clock').textContent, '模擬時間 00:00');
  h.scenario('acceleration');
  h.click('start');
  h.advance(5000);
  assert.equal(h.get('events').textContent, 1);
  assert.equal(h.utterances.length, 0);
  assert.match(h.get('transcript').textContent, /平順加速/);
});

test('opted-in acceleration speaks at sample 5 with zh-TW voice', () => {
  const h = harness();
  h.scenario('acceleration'); h.consent(true); h.click('start');
  h.advance(4000);
  assert.equal(h.utterances.length, 0);
  h.advance(1000);
  assert.equal(h.utterances.length, 1);
  assert.equal(h.utterances[0].lang, 'zh-TW');
  assert.equal(h.get('speech-state').textContent, '播報完畢');
});

test('idle preview is explicit and triggers after 11 received samples', () => {
  const h = harness();
  h.scenario('waiting'); h.consent(true);
  assert.equal(h.get('idle').textContent, 169);
  assert.match(h.get('scenario-note').textContent, /169/);
  h.click('start'); h.advance(10000);
  assert.equal(h.utterances.length, 0);
  h.advance(1000);
  assert.equal(h.utterances.length, 1);
  assert.match(h.utterances[0].text, /作業結束後確認原因/);
});

test('necessary refrigeration stays silent at the idle threshold', () => {
  const h = harness();
  h.scenario('coldchain'); h.consent(true); h.click('start'); h.advance(11000);
  assert.equal(h.utterances.length, 0);
  assert.equal(h.get('suppressed').textContent, 1);
  assert.match(h.get('reason').textContent, /必要作業/);
});

test('global 60s cooldown persists stop, scenario switches and test audio', () => {
  const h = harness();
  h.scenario('acceleration'); h.consent(true); h.click('start'); h.advance(5000);
  assert.equal(h.utterances.length, 1);
  h.click('stop'); h.scenario('waiting'); h.click('start'); h.advance(11000);
  assert.equal(h.utterances.length, 1);
  h.click('test');
  assert.equal(h.utterances.length, 1);
  h.advance(49000); // Exactly 60s since the first utterance.
  h.click('test');
  assert.equal(h.utterances.length, 2);
  h.click('test');
  assert.equal(h.utterances.length, 2, 'test audio also consumes cooldown');
});

test('pause cancels audio and breaks an incomplete acceleration streak', () => {
  const h = harness();
  h.scenario('acceleration'); h.consent(true); h.click('start'); h.advance(4000);
  const canceledBefore = h.cancelCount();
  h.click('pause');
  assert.ok(h.cancelCount() > canceledBefore);
  h.advance(10000);
  assert.equal(h.get('clock').textContent, '模擬時間 00:04');
  h.click('start'); h.advance(1000);
  assert.equal(h.utterances.length, 0);
  h.advance(2000);
  assert.equal(h.utterances.length, 1);
});

test('late sample resets streak instead of filling unobserved sensor time', () => {
  const h = harness();
  h.scenario('acceleration'); h.consent(true); h.click('start'); h.advance(4000);
  h.delayedSample(5000);
  assert.equal(h.utterances.length, 0);
  assert.equal(h.get('clock').textContent, '模擬時間 00:05');
  h.advance(2000);
  assert.equal(h.utterances.length, 1);
});

test('muting cancels speech; reminder is never queued behind active speech', () => {
  const h = harness({finishSpeech: false});
  h.scenario('acceleration'); h.consent(true); h.click('start'); h.advance(5000);
  assert.equal(h.utterances.length, 1);
  h.click('test');
  assert.equal(h.utterances.length, 1);
  assert.match(h.get('reason').textContent, /不排入佇列/);
  h.consent(false);
  assert.equal(h.speech.speaking, false);
  assert.equal(h.get('speech-state').textContent, '語音關閉');
});

test('hidden document and pagehide cancel telemetry and speech', () => {
  const h = harness({finishSpeech: false});
  h.scenario('acceleration'); h.consent(true); h.click('start'); h.advance(5000);
  h.hide();
  assert.equal(h.speech.speaking, false);
  h.advance(10000);
  assert.equal(h.get('clock').textContent, '模擬時間 00:05');
  h.pagehide();
  assert.equal(h.speech.speaking, false);
});

test('unsupported browser exposes text fallback and disables audio controls', () => {
  const h = harness({supported: false});
  assert.equal(h.get('voice-enabled').disabled, true);
  assert.equal(h.get('test').disabled, true);
  assert.equal(h.get('warning').hidden, false);
  h.scenario('acceleration'); h.click('start'); h.advance(5000);
  assert.match(h.get('transcript').textContent, /平順加速/);
  assert.equal(h.utterances.length, 0);
});

assert.ok(!/https?:\/\//.test(html), 'self-contained artifact contains no remote URL');
console.log(`\n${passed} voice checks passed. No real audio was played.`);
