"""Persistence, dataset boundaries, validation, and audit regression checks."""

from copy import deepcopy
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest

from hino.storage import Store, dataset_id


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.path = Path(self.temporary.name) / "feedback.sqlite3"
        self.store = Store(self.path)
        self.action = {
            "id": "idle-001", "title": "卸貨等候確認",
            "scope": {"route": "R1", "vehicle_ids": ["H001", "H002"]},
            "evidence": {"idle_minutes": 87, "sample_count": 12},
        }

    def save(self, dataset="demo", action=None, **changes):
        values = dict(classification="待查", reason="", assignee="",
                      due_date="", status="待處理", intervention_date="")
        values.update(changes)
        self.store.save_action(dataset, action or self.action, **values)

    def test_persistence_after_recreation(self):
        self.save(classification="可避免", reason="已確認預約時段重疊",
                  assignee="調度", due_date="2026-09-29", status="進行中")
        recreated = Store(self.path)
        state = recreated.get_states("demo")["idle-001"]
        self.assertEqual(state["assignee"], "調度")
        self.assertEqual(state["classification"], "可避免")
        self.assertIn("+00:00", state["updated_at"])
        saved = recreated.list_actions("demo")[0]
        self.assertEqual(saved["scope"], self.action["scope"])
        self.assertEqual(saved["evidence"], self.action["evidence"])
        self.assertEqual(len(recreated.history("demo")), 1)

    def test_same_action_id_is_isolated_by_dataset(self):
        self.save("alpha", classification="必要", reason="冷鏈需求")
        self.save("beta", reason="等待調度回覆", status="進行中")
        self.assertEqual(self.store.get_states("alpha")["idle-001"]["classification"], "必要")
        self.assertEqual(self.store.get_states("beta")["idle-001"]["classification"], "待查")
        self.assertEqual(self.store.get_states("other"), {})
        self.assertEqual(self.store.list_actions("other"), [])
        self.assertEqual(self.store.history("other"), [])
        self.assertEqual(len(self.store.history("alpha")), 1)
        self.assertEqual(self.store.history("alpha")[0]["after"]["reason"], "冷鏈需求")

    def test_audit_retains_before_after_and_original_evidence(self):
        self.save()
        first = self.store.history("demo")[0]
        altered_action = deepcopy(self.action)
        altered_action["evidence"]["idle_minutes"] = 1000
        self.save(action=altered_action, classification="必要", reason="冷藏卸貨")
        records = self.store.history("demo", "idle-001")
        self.assertEqual(len(records), 2)
        self.assertIsNone(records[1]["before"])
        self.assertEqual(records[1], first)
        self.assertEqual(records[0]["before"], first["after"])
        self.assertEqual(records[0]["after"]["classification"], "必要")
        self.assertEqual(records[0]["after"]["action"]["evidence"]["idle_minutes"], 87)
        self.assertEqual(self.store.list_actions("demo")[0]["evidence"]["idle_minutes"], 87)
        self.assertEqual(self.store.history("demo", "nonexistent"), [])

    def test_identical_save_does_not_fabricate_another_change(self):
        self.save()
        initial = self.store.get_states("demo")
        self.save()
        self.assertEqual(len(self.store.history("demo")), 1)
        self.assertEqual(self.store.get_states("demo"), initial)

    def test_quotes_and_sql_metacharacters_are_plain_data(self):
        action = deepcopy(self.action)
        action["id"] = "idle'); DROP TABLE actions; --"
        action["title"] = '冷鏈 "A" 區與 O\'Brien 路線'
        dataset = "fleet'; DROP TABLE action_history; --"
        self.save(dataset, action, classification="必要", reason="冷藏溫控\n引號 ' \" 保留")
        record = self.store.list_actions(dataset)[0]
        self.assertEqual(record["title"], action["title"])
        self.assertEqual(record["reason"], "冷藏溫控\n引號 ' \" 保留")
        self.assertEqual(len(self.store.history(dataset, action["id"])), 1)
        self.save()
        self.assertEqual(len(self.store.list_actions("demo")), 1)

    def test_invalid_feedback_does_not_write_state_or_audit(self):
        invalid_cases = [
            {"classification": "節能"}, {"status": "done"},
            {"classification": "必要", "reason": "  "},
            {"classification": "可避免"},
            {"assignee": "調度"},
            {"due_date": "2026-02-30"}, {"due_date": "2026-9-3"},
            {"due_date": "2026-W01-1"}, {"due_date": "20260929"},
            {"intervention_date": "not-a-date"},
            {"reason": "x" * 2001}, {"assignee": "x" * 121},
            {"reason": "bad\x00input"}, {"reason": None},
            {"classification": "可避免", "reason": "排程可調整", "status": "已完成"},
        ]
        for invalid in invalid_cases:
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):
                    self.save(**invalid)
        self.assertEqual(self.store.get_states("demo"), {})
        self.assertEqual(self.store.history("demo"), [])

    def test_completed_intervention_and_necessary_review(self):
        self.save(classification="可避免", reason="已調整預約",
                  status="已完成", intervention_date="2026-09-22")
        self.assertEqual(self.store.get_states("demo")["idle-001"]["intervention_date"], "2026-09-22")
        self.save("other", classification="必要", reason="冷鏈作業經確認", status="已完成")
        self.assertEqual(self.store.get_states("other")["idle-001"]["status"], "已完成")

    def test_action_id_alias_and_invalid_payload(self):
        self.save(action={"action_id": "alias", "evidence": [1, 2]})
        self.assertIn("alias", self.store.get_states("demo"))
        for action in ({}, {"id": 123}, {"id": " "},
                       {"id": "one", "action_id": "two"},
                       {"id": "nan", "evidence": float("nan")},
                       {"id": "large", "evidence": "x" * 262_145}):
            with self.subTest(action_id=action.get("id")):
                with self.assertRaises(ValueError):
                    self.store.save_action("demo", action, "待查", "", "", "", "待處理")
        self.assertEqual(len(self.store.history("demo")), 1)

    def test_audit_failure_rolls_back_current_state(self):
        self.save()
        with closing(sqlite3.connect(self.path)) as connection:
            connection.execute("""
                CREATE TRIGGER test_reject_audit BEFORE INSERT ON action_history
                BEGIN SELECT RAISE(ABORT, 'test audit failure'); END;
            """)
            connection.commit()
        with self.assertRaises(sqlite3.IntegrityError):
            self.save(classification="必要", reason="冷链需求")
        self.assertEqual(self.store.get_states("demo")["idle-001"]["classification"], "待查")
        self.assertEqual(len(self.store.history("demo")), 1)

    def test_dataset_hash_uses_contents_and_validates_bytes(self):
        self.assertEqual(dataset_id(b"abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
        self.assertEqual(dataset_id(b"abc"), dataset_id(b"abc"))
        self.assertNotEqual(dataset_id(b"abc"), dataset_id(b"abcd"))
        with self.assertRaises(TypeError):
            dataset_id("abc")


if __name__ == "__main__":
    unittest.main()
