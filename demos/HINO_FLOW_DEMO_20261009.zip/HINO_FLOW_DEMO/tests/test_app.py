"""Real Streamlit widget flows, with all persistent state in temporary folders."""

from datetime import timedelta
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from hino.analytics import analyze, parse_csv
from hino.demo import get_demo_csv
from hino.storage import Store, dataset_id


APP = Path(__file__).resolve().parents[1] / "app.py"


class AppTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.runtime = Path(self.temporary.name)
        environment = patch.dict(os.environ, {"HINO_RUNTIME_DIR": str(self.runtime)})
        environment.start()
        self.addCleanup(environment.stop)
        raw = get_demo_csv()
        self.workspace_id = "demo-" + dataset_id(raw)
        self.df, _ = parse_csv(raw)
        self.action = analyze(self.df)["actions"][0]
        self.store = Store(self.runtime / "actions.sqlite3")

    def app(self):
        app = AppTest.from_file(str(APP), default_timeout=15).run()
        self.assert_clean(app)
        return app

    def assert_clean(self, app):
        self.assertEqual(len(app.exception), 0,
                         [exception.message for exception in app.exception])

    @staticmethod
    def widgets(app, kind, label):
        return [element for element in getattr(app, kind) if element.label == label]

    def navigate(self, app, page):
        app.radio(key="navigation").set_value(page).run()
        self.assert_clean(app)

    def seed(self, *, intervention_date="", status="進行中"):
        self.store.save_action(
            self.workspace_id, self.action, classification="可避免",
            reason="已向調度確認，調整卸貨預約窗口。", assignee="調度小組",
            due_date="2026-09-29", status=status,
            intervention_date=intervention_date,
        )

    def test_dashboard_renders_three_action_cards_and_computed_metrics(self):
        app = self.app()
        self.assertEqual(app.title[0].value, "本週行動總覽")
        self.assertEqual(len(self.widgets(app, "button", "儲存判斷與指派")), 3)
        self.assertEqual(len(self.widgets(app, "radio", "營運判斷")), 3)
        self.assertEqual(len(app.metric), 4)
        self.assertTrue(any(metric.label == "營運車輛" and metric.value == "8 台"
                            for metric in app.metric))
        self.assertTrue(any("SYNTHETIC DEMO" in item.value for item in app.markdown))

    def test_necessary_requires_reason_removes_card_and_survives_new_session(self):
        app = self.app()
        first_key = self.widgets(app, "button", "儲存判斷與指派")[0].key
        self.widgets(app, "radio", "營運判斷")[0].set_value("必要")
        app.button(key=first_key).click().run()
        self.assert_clean(app)
        self.assertTrue(any("請填寫判定原因" in error.value for error in app.error))
        self.assertEqual(self.store.get_states(self.workspace_id), {})

        self.widgets(app, "text_area", "原因與作業脈絡")[0].set_value("已確認冷鏈機組需持續供電。")
        self.widgets(app, "text_input", "負責人／角色")[0].set_value("冷鏈調度")
        app.button(key=first_key).click().run()
        self.assert_clean(app)
        self.assertTrue(any("已儲存" in message.value for message in app.success))
        self.assertNotIn(first_key, [button.key for button in app.button])
        states = self.store.get_states(self.workspace_id)
        self.assertEqual(states[self.action["id"]]["classification"], "必要")

        restarted = self.app()
        self.assertNotIn(first_key, [button.key for button in restarted.button])
        self.widgets(restarted, "radio", "行動範圍")[0].set_value("必要作業").run()
        self.assert_clean(restarted)
        self.assertEqual(len(self.widgets(restarted, "radio", "營運判斷")), 1)
        self.assertEqual(self.widgets(restarted, "radio", "營運判斷")[0].value, "必要")
        self.assertEqual(self.widgets(restarted, "text_area", "原因與作業脈絡")[0].value,
                         "已確認冷鏈機組需持續供電。")

    def test_tracking_edits_state_and_displays_both_audit_events(self):
        self.seed()
        app = self.app()
        self.navigate(app, "行動追蹤")
        self.assertEqual(app.title[0].value, "行動追蹤")
        self.assertEqual(self.widgets(app, "text_input", "負責人／角色")[0].value, "調度小組")
        self.assertTrue(any(header.value == "變更紀錄" for header in app.subheader))
        frame = app.dataframe[0].value
        self.assertEqual(frame.iloc[0]["狀態"], "進行中")
        self.assertEqual(frame.iloc[0]["負責人"], "調度小組")

        self.widgets(app, "text_area", "原因與作業脈絡")[0].set_value("已完成卸貨時段調整，待追蹤資料。")
        self.widgets(app, "selectbox", "處理狀態")[0].set_value("已完成")
        self.widgets(app, "date_input", "實際介入日期（尚未執行可留白）")[0].set_value("2026-09-20")
        self.widgets(app, "button", "儲存判斷與指派")[0].click().run()
        self.assert_clean(app)
        self.assertEqual(app.dataframe[0].value.iloc[0]["狀態"], "已完成")
        history = self.store.history(self.workspace_id, self.action["id"])
        self.assertEqual(len(history), 2)
        self.assertEqual(history[0]["after"]["intervention_date"], "2026-09-20")
        self.assertTrue(any("可避免 · 已完成" in element.value for element in app.markdown))
        self.assertTrue(any("可避免 · 進行中" in element.value for element in app.markdown))

    def test_empty_tracking_and_review_explain_the_next_action(self):
        app = self.app()
        self.navigate(app, "行動追蹤")
        self.assertTrue(any("還沒有儲存的行動" in message.value for message in app.info))
        self.navigate(app, "週度回看")
        self.assertTrue(any("先儲存一個行動" in message.value for message in app.info))
        self.assertEqual(len(app.metric), 0)

    def test_review_without_intervention_does_not_invent_a_comparison(self):
        self.seed()
        app = self.app()
        self.navigate(app, "週度回看")
        self.assertTrue(any("尚未記錄實際介入日期" in message.value for message in app.info))
        self.assertEqual(len(app.metric), 0)
        self.assertFalse(any("觀察到的" in message.value for message in app.info))

    def test_review_incomplete_and_future_windows_suppress_improvement_ratio(self):
        last_day = self.df["date"].max().date()
        for intervention in (last_day - timedelta(days=1), last_day + timedelta(days=1)):
            with self.subTest(intervention=intervention):
                self.seed(intervention_date=intervention.isoformat())
                app = self.app()
                self.navigate(app, "週度回看")
                self.assertTrue(any("暫不解讀改善比例" in warning.value for warning in app.warning))
                self.assertFalse(any("觀察到的怠速變化" in message.value for message in app.info))
                self.assertFalse(any("觀察到的油耗變化" in message.value for message in app.info))
                self.assertEqual(len(app.metric), 4)

    def test_complete_review_labels_change_as_observational(self):
        last_day = self.df["date"].max().date()
        self.seed(intervention_date=(last_day - timedelta(days=6)).isoformat(), status="已完成")
        app = self.app()
        self.navigate(app, "週度回看")
        changes = [message.value for message in app.info if "觀察到的怠速變化" in message.value]
        self.assertEqual(len(changes), 1)
        self.assertIn("不能歸因", changes[0])
        self.assertTrue(any("尚未建立有效的未介入對照組" in warning.value for warning in app.warning))

    def test_voice_demo_loads_as_explicitly_simulated_separate_surface(self):
        app = self.app()
        self.navigate(app, "語音提醒（模擬）")
        self.assertEqual(app.title[0].value, "即時語音提醒")
        self.assertEqual(len(app.get("iframe")), 1)
        self.assertTrue(any("未使用 CSV 作為即時訊號" in item.value for item in app.caption))


if __name__ == "__main__":
    unittest.main()
