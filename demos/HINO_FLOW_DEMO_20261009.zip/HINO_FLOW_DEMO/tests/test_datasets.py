from __future__ import annotations

import csv
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

from hino.datasets import ACTION_COLUMNS, DatasetLibrary, MAX_BYTES, export_action_csv, safe_csv
from hino.analytics import COLUMNS, parse_csv


def trip(trip_id="T-001", **overrides):
    return {"trip_id": trip_id, "vehicle_id": "HINO-01", "date": "2026-09-01",
            "vehicle_type": "大貨車", "route": "台北線", "distance_km": 90,
            "idle_minutes": 20, "fuel_liters": 22.5, "site": "內湖倉",
            "operation": "一般配送", "load_tons": 5, **overrides}


def csv_data(*records):
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=COLUMNS, lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    return stream.getvalue().encode("utf-8-sig")


class DatasetLibraryTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name) / "datasets"
        self.library = DatasetLibrary(self.root)

    def tearDown(self):
        self.directory.cleanup()

    def test_initial_import_is_normalized_and_persistent(self):
        self.assertIsNone(self.library.current())
        raw = csv_data(trip(load_tons=""))
        result = self.library.import_new(raw, "../../外部.csv")
        self.assertEqual(result["filename"], "外部.csv")
        self.assertEqual(result["workspace_id"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(result["source_sha256"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(result["version_id"], hashlib.sha256(result["data"]).hexdigest())
        self.assertIn(b"2026-09-01", result["data"])
        self.assertNotIn(b"00:00:00", result["data"])
        frame, quality = parse_csv(result["data"])
        self.assertEqual(quality["accepted"], 1)
        self.assertEqual(frame.iloc[0]["route"], "台北線")
        self.assertEqual(DatasetLibrary(self.root).current(), result)
        self.assertEqual(len(list(self.root.glob("*.csv"))), 1)
        self.assertFalse((self.root.parent / "外部.csv").exists())

    def test_invalid_rows_are_excluded_with_quality_preserved(self):
        raw = csv_data(trip(), trip("bad", distance_km=-1))
        result = self.library.import_new(raw, "品質測試.csv")
        self.assertEqual(result["quality"]["rows"], 2)
        self.assertEqual(result["quality"]["accepted"], 1)
        self.assertEqual(result["quality"]["rejected"], 1)
        self.assertEqual(result["row_count"], 1)
        self.assertNotIn(b"bad", result["data"])
        self.assertEqual(self.library.current()["quality"], result["quality"])

    def test_append_preserves_scope_and_skips_identical_normalized_rows(self):
        original = self.library.import_new(csv_data(trip()), "week1.csv")
        result = self.library.append(csv_data(trip(distance_km="90.000"), trip("T-002", date="2026-09-02")), "week2.csv")
        self.assertEqual(result["workspace_id"], original["workspace_id"])
        self.assertNotEqual(result["version_id"], original["version_id"])
        self.assertEqual(result["added_rows"], 1)
        self.assertEqual(result["skipped_duplicates"], 1)
        self.assertEqual(result["row_count"], 2)
        frame, _ = parse_csv(result["data"])
        self.assertEqual(frame["trip_id"].tolist(), ["T-001", "T-002"])

    def test_new_dataset_isolates_workspace(self):
        first = self.library.import_new(csv_data(trip()), "first.csv")
        second = self.library.import_new(csv_data(trip("different")), "other.csv")
        self.assertNotEqual(first["workspace_id"], second["workspace_id"])

    def test_append_counts_valid_duplicates_and_preserves_rejected_row_count(self):
        self.library.import_new(csv_data(trip()), "first.csv")
        result = self.library.append(csv_data(trip(), trip(), trip("T-002"), trip("T-002"), trip("bad", distance_km=-1)), "new.csv")
        self.assertEqual(result["added_rows"], 1)
        self.assertEqual(result["skipped_duplicates"], 3)
        self.assertEqual(result["quality"]["rows"], 5)
        self.assertEqual(result["quality"]["rejected"], 3)
        self.assertEqual(result["row_count"], 2)

    def test_conflicting_append_leaves_original_untouched(self):
        original = self.library.import_new(csv_data(trip()), "first.csv")
        with self.assertRaisesRegex(ValueError, "衝突"):
            self.library.append(csv_data(trip(distance_km=100), trip("T-002")), "conflict.csv")
        self.assertEqual(self.library.current(), original)
        self.assertEqual(len(list(self.root.glob("*.csv"))), 1)

    def test_conflict_within_appended_file_is_rejected(self):
        original = self.library.import_new(csv_data(trip()), "first.csv")
        with self.assertRaises(ValueError):
            self.library.append(csv_data(trip("new", distance_km=100), trip("new", distance_km=120), trip("valid")), "conflict.csv")
        self.assertEqual(self.library.current(), original)

    def test_malformed_all_invalid_and_oversized_input_leave_original_untouched(self):
        original = self.library.import_new(csv_data(trip()), "first.csv")
        invalid_inputs = [b"unknown,columns\n1,2", csv_data(trip(distance_km=-1)), b"x" * (MAX_BYTES + 1)]
        for raw in invalid_inputs:
            for method in (self.library.import_new, self.library.append):
                with self.subTest(raw_length=len(raw), method=method.__name__):
                    with self.assertRaises(ValueError):
                        method(raw, "invalid.csv")
                    self.assertEqual(self.library.current(), original)

    def test_atomic_pointer_failure_leaves_old_dataset(self):
        original = self.library.import_new(csv_data(trip()), "first.csv")
        with patch("hino.datasets.os.replace", side_effect=OSError("simulated write failure")):
            with self.assertRaises(OSError):
                self.library.append(csv_data(trip("T-002")), "second.csv")
        self.assertEqual(self.library.current(), original)
        self.assertEqual(len(list(self.root.glob("*.csv"))), 1)
        self.assertEqual(list(self.root.glob(".*.tmp")), [])

    def test_file_tampering_and_path_traversal_are_rejected(self):
        original = self.library.import_new(csv_data(trip()), "first.csv")
        stored = self.root / original["version_file"]
        stored.write_bytes(stored.read_bytes() + b"\n")
        with self.assertRaisesRegex(ValueError, "不符"):
            self.library.current()
        metadata = json.loads((self.root / "current.json").read_text(encoding="utf-8"))
        metadata["version_file"] = "../../external.csv"
        (self.root / "current.json").write_text(json.dumps(metadata), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "不合法"):
            self.library.current()

    def test_append_requires_existing_dataset_and_enforces_merged_row_limit(self):
        with self.assertRaises(ValueError):
            self.library.append(csv_data(trip()), "first.csv")
        original = self.library.import_new(csv_data(trip()), "first.csv")
        with patch("hino.datasets.MAX_ROWS", 1):
            with self.assertRaisesRegex(ValueError, "100,000"):
                self.library.append(csv_data(trip("T-002")), "second.csv")
        self.assertEqual(self.library.current(), original)


class SpreadsheetExportTests(unittest.TestCase):
    def test_formulas_are_text_and_chinese_and_numbers_roundtrip(self):
        dangerous = ["=HYPERLINK(\"http://invalid\")", "+CMD", "-CMD", "@SUM(A1)", "\tformula", "\nformula", "  =1+1", " \ttext"]
        frame = pd.DataFrame({"駕駛": ["王小明", *dangerous], "數值": [2, -3, 4, 5, 6, 7, 8, 9, 10]})
        encoded = safe_csv(frame)
        self.assertTrue(encoded.startswith(b"\xef\xbb\xbf"))
        rows = list(csv.DictReader(io.StringIO(encoded.decode("utf-8-sig"))))
        self.assertEqual(rows[0], {"駕駛": "王小明", "數值": "2"})
        self.assertEqual(rows[1]["數值"], "-3")
        for row, raw in zip(rows[1:], dangerous):
            self.assertEqual(row["駕駛"], "'" + raw)
        self.assertEqual(frame.iloc[1]["駕駛"], dangerous[0], "export must not mutate its input")

    def test_untrusted_headers_are_sanitized(self):
        encoded = safe_csv(pd.DataFrame({"=1+1": ["安全"]}))
        rows = list(csv.reader(io.StringIO(encoded.decode("utf-8-sig"))))
        self.assertEqual(rows[0], ["'=1+1"])

    def test_action_export_only_includes_defined_fields(self):
        payload = export_action_csv([{"id": "action-1", "title": "油耗改善", "reason": "=bad()", "assignee": "林主管", "internal_secret": "hidden"}])
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig"))))
        self.assertEqual(tuple(rows[0]), ACTION_COLUMNS)
        self.assertEqual(rows[0]["title"], "油耗改善")
        self.assertEqual(rows[0]["reason"], "'=bad()")
        self.assertNotIn("hidden", payload.decode("utf-8-sig"))

    def test_empty_action_export_keeps_schema(self):
        self.assertEqual(export_action_csv([]).decode("utf-8-sig").strip(), ",".join(ACTION_COLUMNS))

    def test_action_id_falls_back_to_storage_id(self):
        payload = export_action_csv([{"action_id": "saved-1", "title": "追蹤"}])
        rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig"))))
        self.assertEqual(rows[0]["id"], "saved-1")


if __name__ == "__main__":
    unittest.main()
