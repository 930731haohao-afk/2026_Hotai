$ErrorActionPreference = 'Stop'
$entryPath = Join-Path $PSScriptRoot 'mobile_server.py'
$pidPath = Join-Path $PSScriptRoot 'runtime\mobile-server.pid'
if (-not (Test-Path -LiteralPath $pidPath)) { return }
$serverProcessId=0
if (-not [int]::TryParse((Get-Content -LiteralPath $pidPath -Raw).Trim(), [ref]$serverProcessId)) { throw 'Invalid process ID file.' }
$candidate=Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction SilentlyContinue
if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($entryPath)) { Stop-Process -Id $serverProcessId; Write-Output 'Phone demo stopped.' }
elseif ($candidate) { throw 'Process belongs to another app and was not stopped.' }
