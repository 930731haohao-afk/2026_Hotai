$ErrorActionPreference = 'Stop'
$appPath = Join-Path $PSScriptRoot 'app.py'
$pidPath = Join-Path $PSScriptRoot 'runtime\server.pid'
if (-not (Test-Path -LiteralPath $pidPath)) { Write-Output 'No saved server process.'; return }
$serverProcessId = 0
if (-not [int]::TryParse((Get-Content -LiteralPath $pidPath -Raw).Trim(), [ref]$serverProcessId)) { throw 'Invalid server process file.' }
$candidate = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction SilentlyContinue
if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($appPath) -and $candidate.CommandLine.Contains('streamlit')) {
    Stop-Process -Id $serverProcessId
    Write-Output 'HINO MVP stopped. Your saved actions and datasets remain available.'
} elseif ($candidate) { throw 'The process belongs to another app and was left running.' }
