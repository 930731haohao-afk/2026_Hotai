param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$rootPath = $PSScriptRoot
$pythonPath = Join-Path $rootPath '.venv\Scripts\python.exe'
$entryPath = Join-Path $rootPath 'mobile_server.py'
$runtimePath = Join-Path $rootPath 'runtime'
New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
$pidPath = Join-Path $runtimePath 'mobile-server.pid'
$existing = $null
if (Test-Path -LiteralPath $pidPath) {
    $serverProcessId = 0
    if ([int]::TryParse((Get-Content -LiteralPath $pidPath -Raw).Trim(), [ref]$serverProcessId)) {
        $candidate = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction SilentlyContinue
        if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($entryPath)) { $existing = $candidate }
    }
}
if (-not $existing) {
    if (Get-NetTCPConnection -LocalPort 8504 -State Listen -ErrorAction SilentlyContinue) { throw 'Port 8504 is already used by another app.' }
    if (-not (Test-Path -LiteralPath $pythonPath)) { throw 'Project Python is missing. See README.md to set up the environment.' }
    $server = Start-Process -FilePath $pythonPath -ArgumentList @(('"' + $entryPath + '"')) -WorkingDirectory $rootPath -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtimePath 'mobile-server.out.log') -RedirectStandardError (Join-Path $runtimePath 'mobile-server.err.log') -PassThru
    Set-Content -LiteralPath $pidPath -Value $server.Id -Encoding ascii
}
$ready = $false
for ($attempt=0; $attempt -lt 20; $attempt++) {
    try { $r=Invoke-WebRequest -Uri 'http://127.0.0.1:8504/' -UseBasicParsing -TimeoutSec 2; if ($r.StatusCode -eq 200 -and $r.Content.Contains('HINO FLOW')) { $ready=$true; break } } catch { Start-Sleep -Milliseconds 300 }
}
if (-not $ready) { throw 'Preview did not start. See runtime/mobile-server.err.log.' }
Write-Output 'HINO FLOW ready: http://127.0.0.1:8504/'
if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:8504/' }
