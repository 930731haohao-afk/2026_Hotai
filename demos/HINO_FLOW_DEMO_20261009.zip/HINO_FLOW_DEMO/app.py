"""HINO fleet action MVP. Local workstation only; all figures computed in Python."""
from __future__ import annotations

import html
import os
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from hino.analytics import analyze, parse_csv, week_review
from hino.datasets import DatasetLibrary, export_action_csv
from hino.demo import get_demo_csv
from hino.storage import Store, dataset_id

BASE = Path(__file__).resolve().parent
RUNTIME = Path(os.environ.get("HINO_RUNTIME_DIR", str(BASE / "runtime")))
RUNTIME.mkdir(parents=True, exist_ok=True)
st.set_page_config(page_title="HINO Fleet Actions｜車隊節能行動助手", page_icon="◈", layout="wide")

STYLES = """
<style>
.stApp {font-family: 'Segoe UI', 'Microsoft JhengHei', sans-serif;}
.block-container {padding-top:2.1rem; padding-bottom:3rem; max-width:1500px;}
[data-testid="stSidebar"] {background:#182730;}
[data-testid="stSidebar"] p {color:#e6edf0;}
[data-testid="stSidebar"] .stCaption p {color:#a4b5bf;}
[data-testid="stSidebar"] [data-baseweb="select"] * {color:#19242d;}
[data-testid="stSidebar"] [role="spinbutton"] {color:#19242d!important;}
[data-testid="stSidebar"] .stRadio label {padding:8px 0;}
h1 {font-size:2rem!important; font-weight:750!important; letter-spacing:-.03em;}
h2 {font-size:1.4rem!important; font-weight:700!important;}
h3 {font-size:1.14rem!important; font-weight:700!important;}
[data-testid="stMetric"] {background:white; padding:18px 20px; border:1px solid #e4e8ec; border-radius:12px;}
[data-testid="stMetricValue"] {font-size:1.85rem!important; letter-spacing:-.04em;}
[data-testid="stVerticalBlockBorderWrapper"]>div {border-color:#e1e6e9!important; border-radius:12px;}
.eyebrow {color:#83959f; font-size:12px; letter-spacing:.17em; font-weight:700; margin-bottom:8px;}
.brand {font-size:2rem; color:white; font-weight:850; letter-spacing:.08em; line-height:1.05;}
.brand span {color:#f16062;}
.brand-sub {color:#bdcbd2; font-size:14px; margin:10px 0 30px;}
.tag {display:inline-block; padding:4px 10px; border-radius:5px; background:#edf1f4; color:#49606e; font-size:13px; font-weight:600; margin-right:6px; margin-bottom:8px;}
.tag.red {background:#fce9e9; color:#ab3035;}
.tag.green {background:#e4f2ec; color:#246b51;}
.tag.amber {background:#fff2d9; color:#866012;}
.context {padding:14px 18px; border-left:3px solid #c33438; background:#fff; border-radius:0 8px 8px 0; color:#566772; font-size:14px; margin:10px 0 24px;}
.mini-label {font-size:13px; color:#778894; margin-bottom:4px;}
.stat {font-size:1.65rem; font-weight:750; color:#263845; margin-bottom:4px;}
.stat.highlight {color:#b7373d;}
.footer-note {color:#778894; font-size:12px; margin-top:24px; border-top:1px solid #e1e6e9; padding-top:14px;}
div.stButton>button, div.stDownloadButton>button {border-radius:7px; font-weight:600;}
.st-key-kpis [data-testid="stHorizontalBlock"] {display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));}
.st-key-kpis [data-testid="stColumn"] {width:100%!important;min-width:0!important;}
@media(max-width:1100px) {
 .st-key-kpis [data-testid="stHorizontalBlock"] {grid-template-columns:repeat(2,minmax(0,1fr));}
 .st-key-board > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] {display:flex;flex-direction:column;}
 .st-key-board > [data-testid="stLayoutWrapper"] > [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {width:100%!important;flex:1 1 auto!important;}
}
@media(max-width:750px) {.block-container {padding:1rem;} h1 {font-size:1.65rem!important;} .stat{font-size:1.4rem;}}
</style>
"""
st.markdown(STYLES, unsafe_allow_html=True)


def esc(value):
    return html.escape(str(value))


def number(value, digits=0, suffix=""):
    if value is None or pd.isna(value):
        return "—"
    return f"{value:,.{digits}f}{suffix}"


@st.cache_data(show_spinner=False)
def load_data(raw):
    return parse_csv(raw)


@st.cache_data(show_spinner=False)
def compute(raw, end):
    frame, _ = parse_csv(raw)
    return analyze(frame, end)


def tags(items):
    st.markdown("".join(f'<span class="tag {esc(color)}">{esc(label)}</span>' for label, color in items), unsafe_allow_html=True)


def brief_report(result, saved, source):
    s = result["summary"]
    lines = ["# 車隊節能行動週報", "", f"資料來源：{source}",
             f"分析期間：{result['current_start']} 至 {result['current_end']}", "",
             f"- 車輛：{s['vehicles']} 台；車次：{s['trips']} 筆",
             f"- 里程：{number(s['distance_km'], 1)} km",
             f"- 怠速：{number(s['idle_minutes'], 1)} 分鐘（包含必要作業，尚非浪費量）",
             f"- 每百公里耗油：{number(s['fuel_per_100km'], 2)} L / 100 km", "", "## 行動與追蹤"]
    for a in result["actions"]:
        state = saved.get(a["id"], {})
        lines.extend(["", f"### {a['title']}", f"- 判斷：{state.get('classification', '待查')}",
                      f"- 說明：{a['description']}", f"- 當期 {a['current_n']} 筆；歷史 {a['baseline_n']} 筆",
                      f"- 負責人：{state.get('assignee') or '尚未指派'}；追蹤日：{state.get('due_date') or '尚未設定'}",
                      f"- 狀態：{state.get('status', '待處理')}；原因：{state.get('reason') or '尚未補充'}"])
    lines.extend(["", "## 方法與限制", "本週報以固定規則及計算結果產生，未呼叫生成式 AI。",
                  "同組歷史中位數只作為查核線索；不跨路線排名駕駛。必要冷鏈及動力輸出作業須由管理者確認。",
                  "前後變化不是介入因果效果；未校正載重、天候及同期調度，也未建立有效控制組。",
                  "此為本機 MVP，不代表 HINO 官方產品、已串接 iTRAQ 或已驗證節油成效。"])
    return "\n".join(lines)


def action_form(a, state, store, workspace_id, prefix="card"):
    with st.form(f"{prefix}_{a['id']}"):
        options = ["待查", "可避免", "必要"]
        classification = st.radio("營運判斷", options, index=options.index(state.get("classification", "待查")), horizontal=True)
        reason = st.text_area("原因與作業脈絡", state.get("reason", ""), placeholder="例如：冷藏機組必須運轉；或卸貨窗口未預約，請調度協調。", max_chars=2000)
        c1, c2 = st.columns(2)
        assignee = c1.text_input("負責人／角色", state.get("assignee", ""), placeholder="例如：調度小組", max_chars=100)
        due = c2.date_input("下次追蹤日期", value=date.fromisoformat(state["due_date"]) if state.get("due_date") else date.today() + timedelta(days=7))
        c3, c4 = st.columns(2)
        statuses = ["待處理", "進行中", "已完成"]
        status = c3.selectbox("處理狀態", statuses, index=statuses.index(state.get("status", "待處理")))
        intervention = c4.date_input("實際介入日期（尚未執行可留白）", value=date.fromisoformat(state["intervention_date"]) if state.get("intervention_date") else None)
        if st.form_submit_button("儲存判斷與指派", type="primary", width="stretch"):
            try:
                store.save_action(workspace_id, a, classification, reason, assignee, due.isoformat() if due else "", status, intervention.isoformat() if intervention else "")
            except ValueError as exc:
                st.error(str(exc))
            else:
                st.session_state["flash"] = "已儲存。必要作業會移出優先清單，紀錄可在「行動追蹤」查看。"
                st.rerun()


def action_card(a, rank, state, store, workspace_id):
    with st.container(border=True):
        classification = state.get("classification", "待查")
        tags([(f"{rank:02d} · {'怠速線索' if a['kind'] == 'idle' else '油耗線索'}", "red"),
              (classification, "green" if classification == "必要" else "amber"),
              (f"可信度 {a['confidence']}", "")])
        st.subheader(a["title"])
        st.write(a["description"])
        left, right = st.columns(2)
        with left:
            st.markdown(f'<div class="mini-label">本期 · {esc(a["current_n"])} 筆</div><div class="stat highlight">{number(a["current_value"], 1)} <small>{esc(a["unit"])}</small></div>', unsafe_allow_html=True)
        with right:
            st.markdown(f'<div class="mini-label">同組歷史中位數 · {esc(a["baseline_n"])} 筆</div><div class="stat">{number(a["baseline_value"], 1)} <small>{esc(a["unit"])}</small></div>', unsafe_allow_html=True)
        st.caption(f"{a['vehicle_type']} · {a['route']} · {len(a['vehicle_ids'])} 台車")
        st.write(f"**下一步**　{a['suggestion']}")
        if state.get("assignee"):
            st.caption(f"負責：{state['assignee']}　｜　追蹤：{state['due_date']}　｜　{state['status']}")
        with st.expander("查看證據、補充原因與指派"):
            for evidence in a.get("evidence", []):
                st.write(f"• {evidence}")
            for caveat in a.get("caveats", []):
                st.caption(f"注意：{caveat}")
            action_form(a, state, store, workspace_id)


def dashboard(df, result, quality, store, workspace_id, source):
    states = store.get_states(workspace_id)
    s = result["summary"]
    st.markdown('<div class="eyebrow">WEEKLY ACTION BOARD</div>', unsafe_allow_html=True)
    st.title("本週行動總覽")
    st.caption(f"{result['current_start']} — {result['current_end']}　／　與相同車型、路線的歷史資料比較")
    with st.container(key="kpis"):
        c1, c2, c3, c4 = st.columns(4)
    c1.metric("營運車輛", f"{s['vehicles']} 台", help=f"本期 {s['trips']} 筆車次")
    c2.metric("行駛里程", number(s["distance_km"]) + " km")
    c3.metric("每百公里耗油", number(s["fuel_per_100km"], 1) + (" L" if s["fuel_per_100km"] is not None else ""), help="總油量 ÷ 總里程 × 100；缺少可靠油量時不顯示。")
    c4.metric("觀察到的怠速", number(s["idle_minutes"]) + " 分", help="包含必要作業，不能直接視為浪費或換算成已節省油量。")
    st.markdown('<div class="context">先確認營運原因，再決定改善行動。冷鏈、動力輸出與必要等待，應由管理者補充脈絡。</div>', unsafe_allow_html=True)
    with st.container(key="board"):
        main, aside = st.columns([1.9, 1], gap="large")
    with main:
        st.subheader("優先處理的三件事")
        view = st.radio("行動範圍", ["本週優先", "全部線索", "必要作業"], horizontal=True, label_visibility="collapsed")
        active = [a for a in result["actions"] if states.get(a["id"], {}).get("classification") != "必要" and states.get(a["id"], {}).get("status") != "已完成"]
        if view == "本週優先":
            actions = active[:3]
        elif view == "必要作業":
            actions = [a for a in result["actions"] if states.get(a["id"], {}).get("classification") == "必要"]
        else:
            actions = result["actions"]
        if not actions:
            st.info("目前沒有符合條件的行動。可切換全部線索，或匯入更多同組歷史資料。")
        for rank, a in enumerate(actions, 1):
            action_card(a, rank, states.get(a["id"], {}), store, workspace_id)
    with aside:
        with st.container(border=True):
            st.subheader("近四週怠速趨勢")
            cutoff = pd.Timestamp(result["current_end"])
            recent = df.loc[(df["date"] <= cutoff) & (df["date"] >= cutoff - timedelta(days=27))]
            days = recent.groupby("date", as_index=False)["idle_minutes"].sum()
            if not days.empty:
                fig = go.Figure(go.Scatter(x=days["date"], y=days["idle_minutes"], mode="lines+markers", line=dict(color="#bf3e42", width=2.5), marker=dict(size=4), fill="tozeroy", fillcolor="rgba(195,52,56,0.06)", hovertemplate="%{x}<br>怠速 %{y:,.0f} 分<extra></extra>"))
                fig.update_layout(height=230, margin=dict(l=0, r=5, t=5, b=0), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(color="#667a88", size=12), xaxis=dict(showgrid=False, tickformat="%m/%d"), yaxis=dict(gridcolor="#e9eef2", title="分鐘", rangemode="tozero"), showlegend=False)
                st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
            st.caption("全隊每日加總，會受當日車次數與必要作業影響。")
        with st.container(border=True):
            st.subheader("行動進度")
            necessary = sum(x.get("classification") == "必要" for x in states.values())
            done = sum(x.get("status") == "已完成" for x in states.values())
            st.write(f"**{len(active)}** 件本期線索待處理")
            st.write(f"**{necessary}** 件累計確認為必要作業")
            st.write(f"**{done}** 件累計已完成")
            st.caption("必要作業保留在紀錄中；不再佔用本期優先順位。")
        with st.container(border=True):
            st.subheader("資料狀態")
            st.write(f"{quality['accepted']} 筆有效車次")
            st.caption(f"資料期間　{quality['start_date']} — {quality['end_date']}")
            if quality.get("missing_fuel", 0):
                st.warning("部分車次缺少油量；相關油耗指標停用。")
            if quality.get("missing_load", 0):
                st.caption("載重資訊不完整，差異僅供追查。")
            st.download_button("下載本週摘要", brief_report(result, states, source), "車隊行動週報.md", "text/markdown", width="stretch")
        with st.expander("這份建議怎麼產生？"):
            st.write("以同車型／同路線分組，怠速另按作業地點，油耗另按車輛。比較當期與之前最多 21 天的中位數；兩期至少各 3 筆才提供比較。")
            st.write("採規則與統計基線，不含已訓練的預測模型。排序是查核優先度，不是司機評分。")
            st.caption("目前摘要由固定文字模板產生，未啟用外部 AI API。")


def import_page(library, current, quality, df):
    st.markdown('<div class="eyebrow">DATA WORKSPACE</div>', unsafe_allow_html=True)
    st.title("資料匯入與健檢")
    st.caption("使用每車次彙總的 CSV。日期、里程與油量單位先對齊，再開始比較。")
    left, right = st.columns([1.65, 1], gap="large")
    with left:
        with st.container(border=True):
            st.subheader("匯入車次資料")
            uploaded = st.file_uploader("選擇 UTF-8 CSV（上限 20 MB）", type=["csv"])
            mode = st.radio("匯入方式", ["建立新資料集", "追加到目前匯入資料"], horizontal=True, help="追加保留已指派行動；相同車次 ID 的內容不同時會拒絕更新，避免改寫歷史。")
            if mode.startswith("追加") and not current:
                st.info("尚無匯入資料。請先建立一份新資料集。")
            if uploaded is not None:
                try:
                    candidate, q = load_data(uploaded.getvalue())
                    st.write(f"可接受 **{q['accepted']}** 筆；拒絕 **{q['rejected']}** 筆；重複 **{q['duplicates']}** 筆。")
                    for issue in q.get("errors", []) + q.get("warnings", []):
                        st.warning(issue)
                    st.dataframe(candidate.head(8), hide_index=True, width="stretch")
                    confirm_partial = True
                    if q["rejected"] or q["duplicates"]:
                        confirm_partial = st.checkbox("我已檢查錯誤摘要，同意只匯入有效且不重複的車次")
                    if st.button("確認匯入", type="primary", disabled=not confirm_partial or (mode.startswith("追加") and not current)):
                        if mode.startswith("追加"):
                            result = library.append(uploaded.getvalue(), uploaded.name)
                        else:
                            result = library.import_new(uploaded.getvalue(), uploaded.name)
                        st.session_state["switch_to_import"] = True
                        st.session_state["flash"] = f"已匯入 {result.get('filename', uploaded.name)}，可以開始檢視行動。"
                        st.rerun()
                except (ValueError, UnicodeError, OSError) as exc:
                    st.error(str(exc))
            if current:
                st.caption(f"已儲存資料共 {current['row_count']} 筆；最近匯入 {current['imported_at']}（UTC）。")
                last = current.get("quality", {})
                st.caption(f"最近一次上傳：{last.get('rows', 0)} 筆，接受 {last.get('accepted', 0)} 筆、排除 {last.get('rejected', 0)} 筆。")
        with st.container(border=True):
            st.subheader("目前資料品質")
            cols = st.columns(3)
            cols[0].metric("有效車次", quality["accepted"])
            cols[1].metric("缺少油量", quality.get("missing_fuel", 0))
            cols[2].metric("缺少載重", quality.get("missing_load", 0))
            for msg in quality.get("warnings", []) + quality.get("errors", []):
                st.warning(msg)
            if not quality.get("warnings") and not quality.get("errors"):
                st.success("格式與基本數值檢查通過；這不代表感測器已校正或資料來源已驗證。")
            st.dataframe(df.head(30), hide_index=True, width="stretch")
    with right:
        with st.container(border=True):
            st.subheader("先用範例試跑")
            st.write("28 天、8 台車，包含卸貨等待、必要冷鏈作業與油耗偏高的合成情境。")
            st.download_button("下載完整範例 CSV", get_demo_csv(), "demo_trips.csv", "text/csv", width="stretch")
            st.caption("CSV schema 是本 MVP 的匯入格式，並非 HINO 或 iTRAQ 官方格式。")
        with st.container(border=True):
            st.subheader("欄位與單位")
            st.markdown("**必填**\n\n`trip_id` 唯一車次\n\n`vehicle_id` 去識別車輛\n\n`date` 日期 YYYY-MM-DD\n\n`vehicle_type` 車型\n\n`route` 路線類別\n\n`distance_km` 本車次公里\n\n`idle_minutes` 本車次怠速分鐘")
            st.markdown("**選填**\n\n`fuel_liters` 本車次燃油公升\n\n`site` 作業地點\n\n`operation` 作業說明\n\n`load_tons` 載重公噸")
            st.caption("里程與油量須為該車次用量，不接受未換算的累計里程表、累計油量。日期以台灣當地作業日整理；跨日車次先按作業定義歸屬。")


def tracking_page(store, workspace_id):
    st.markdown('<div class="eyebrow">ACTION FOLLOW-UP</div>', unsafe_allow_html=True)
    st.title("行動追蹤")
    st.caption("保留誰做了判斷、要處理什麼，以及下一次回看的日期。")
    saved = store.list_actions(workspace_id)
    if not saved:
        st.info("還沒有儲存的行動。請先在「行動總覽」展開行動卡，補充判斷並指派。")
        return
    filter_by = st.radio("顯示狀態", ["全部", "待處理", "進行中", "已完成", "必要作業"], horizontal=True)
    shown = [a for a in saved if filter_by == "全部" or (a["classification"] == "必要" if filter_by == "必要作業" else a["status"] == filter_by)]
    rows = [{"行動": a["title"], "判斷": a["classification"], "負責人": a["assignee"] or "未指派", "追蹤日期": a["due_date"], "狀態": a["status"]} for a in shown]
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")
    st.download_button("匯出全部行動紀錄", export_action_csv(saved), "行動紀錄.csv", "text/csv")
    if not shown:
        return
    selected_id = st.selectbox("選擇要更新的行動", [a["id"] for a in shown], format_func=lambda x: next(a["title"] for a in shown if a["id"] == x))
    selected = next(a for a in shown if a["id"] == selected_id)
    left, right = st.columns([1.6, 1], gap="large")
    with left:
        with st.container(border=True):
            st.subheader(selected["title"])
            st.write(selected["description"])
            action_form(selected, selected, store, workspace_id, "track")
    with right:
        st.subheader("變更紀錄")
        for event in store.history(workspace_id, selected_id)[:12]:
            after = event["after"]
            with st.container(border=True):
                st.caption(event["changed_at"] + "（UTC）")
                st.write(f"**{after['classification']} · {after['status']}**")
                st.write(after.get("reason") or "未填寫原因")
                st.caption(f"負責：{after.get('assignee') or '未指派'}")


def review_page(df, store, workspace_id, result, source):
    st.markdown('<div class="eyebrow">WEEKLY REVIEW</div>', unsafe_allow_html=True)
    st.title("週度回看")
    st.caption("對照同一組車輛或作業的介入前後資料。先看原始數值與樣本，再解讀變化。")
    saved = store.list_actions(workspace_id)
    with st.expander("下載目前分析週報", expanded=False):
        report = brief_report(result, store.get_states(workspace_id), source)
        st.download_button("下載 Markdown 週報", report, "車隊行動週報.md", "text/markdown", key="review_report")
        st.caption("以已計算的固定數字整理，未呼叫生成式 AI。")
    if not saved:
        st.info("先儲存一個行動並填寫實際介入日期，這裡就能查看後續資料是否足夠。")
        return
    choices = {a["id"]: a for a in saved}
    selected_id = st.selectbox("回看的行動", list(choices), format_func=lambda x: choices[x]["title"])
    a = choices[selected_id]
    if not a.get("intervention_date"):
        st.info("此行動尚未記錄實際介入日期。執行後到「行動追蹤」補上日期，再追加後續車次資料。")
        return
    comparison = week_review(df, a, a["intervention_date"])
    st.write(f"**實際介入日期：{a['intervention_date']}**　｜　{a['assignee'] or '尚未指派'}　｜　{a['status']}")
    before, after = comparison["before"], comparison["after"]
    c1, c2 = st.columns(2)
    for col, title, period in [(c1, "介入前 7 天", before), (c2, "介入後 7 天", after)]:
        with col, st.container(border=True):
            st.subheader(title)
            st.caption(f"{period['start']} — {period['end']}")
            st.write(f"樣本：**{period['trips']} 筆車次**")
            st.metric("每車次平均怠速", number(period.get("idle_minutes_per_trip"), 1) + " 分")
            st.metric("每百公里耗油", number(period.get("fuel_per_100km"), 2) + " L")
    if comparison["comparable"]:
        value_key = "idle_minutes_per_trip" if a["kind"] == "idle" else "fuel_per_100km"
        b, f = before.get(value_key), after.get(value_key)
        if b is not None and f is not None and b > 0:
            change = (f - b) / b * 100
            st.info(f"觀察到的{'怠速' if a['kind'] == 'idle' else '油耗'}變化：{change:+.1f}%。這是前後觀察差異，不能歸因為此行動造成的節油效果。")
    else:
        st.warning("同組樣本不足，或資料尚未涵蓋完整後 7 天，暫不解讀改善比例。請追加後續資料。")
    for caveat in comparison.get("caveats", []):
        st.caption(caveat)
    st.warning("尚未建立有效的未介入對照組，也未估計信賴區間；載重、路線細節與同期營運改變都可能影響結果。")
    with st.expander("駕駛摘要（停車後閱讀）"):
        st.write(f"**{a['title']}**")
        st.write(a["suggestion"])
        st.write(f"管理者補充：{a.get('reason') or '待補充'}")
        st.caption("請於安全停車後閱讀；是否調整作業由車隊確認。本助手不提供行車中操作或直接熄火指令。")


def main():
    library = DatasetLibrary(RUNTIME / "datasets")
    store = Store(RUNTIME / "actions.sqlite3")
    if st.session_state.pop("switch_to_import", False):
        st.session_state["source_selector"] = "我的匯入資料"
    try:
        imported = library.current()
    except (ValueError, OSError):
        st.error("匯入資料檔無法讀取。請保留 runtime 資料夾，以便檢查檔案完整性。")
        imported = None
    with st.sidebar:
        st.markdown('<div class="eyebrow">FLEET ACTION STUDIO</div><div class="brand">HINO<span> /</span></div><div class="brand-sub">車隊節能行動助手</div>', unsafe_allow_html=True)
        page = st.radio("工作台", ["行動總覽", "資料匯入", "行動追蹤", "週度回看", "語音提醒（模擬）"], key="navigation")
        st.divider()
        source = st.radio("資料來源", ["合成示範資料", "我的匯入資料"], key="source_selector")
        if source == "我的匯入資料" and imported is None:
            st.caption("尚未匯入 CSV；先展示合成資料。")
            source = "合成示範資料"
    raw = imported["data"] if source == "我的匯入資料" else get_demo_csv()
    workspace_id = imported["workspace_id"] if source == "我的匯入資料" else "demo-" + dataset_id(raw)
    try:
        df, quality = load_data(raw)
    except ValueError as exc:
        st.error(f"資料無法分析：{exc}")
        return
    with st.sidebar:
        max_date = pd.Timestamp(df["date"].max()).date()
        min_date = pd.Timestamp(df["date"].min()).date()
        end = st.date_input("分析截止日", value=max_date, min_value=min_date, max_value=max_date, key=f"week_{workspace_id}_{max_date}")
        st.caption("分析截止日前 7 天；基準僅使用更早的資料。")
        st.divider()
        st.caption("合成展示 · 非官方產品" if source == "合成示範資料" else "本機匯入 · 來源待驗證")
        st.caption("資料與指派儲存在這台電腦。未連接 iTRAQ 或外部 AI 服務。")
    result = compute(raw, end)
    if source == "合成示範資料":
        tags([("SYNTHETIC DEMO", "red"), ("28 天 / 8 台車 · 情境數據", "")])
    else:
        tags([("本機資料", "green"), (imported["filename"], "")])
    if "flash" in st.session_state:
        st.success(st.session_state.pop("flash"))
    freshness = (date.today() - max_date).days
    if source != "合成示範資料" and freshness > 7:
        st.warning(f"最新車次距今天 {freshness} 天。以下分析以檔案內日期為準。")
    if page == "行動總覽":
        dashboard(df, result, quality, store, workspace_id, source)
    elif page == "資料匯入":
        import_page(library, imported, quality, df)
    elif page == "行動追蹤":
        tracking_page(store, workspace_id)
    elif page == "週度回看":
        review_page(df, store, workspace_id, result, source)
    else:
        st.markdown('<div class="eyebrow">DRIVER VOICE LAB</div>', unsafe_allow_html=True)
        st.title("即時語音提醒")
        st.caption("行車訊號符合條件時，播放簡短節能提醒。以下為獨立的模擬情境，未使用 CSV 作為即時訊號。")
        st.iframe(BASE / "assets" / "voice_demo.html", height="content")
        with st.expander("接到真實車輛前，需要什麼？"):
            st.write("需要授權的即時速度、時間戳、引擎與作業狀態；先確認訊號頻率、延遲、斷線與錯值，再串接可播放聲音的車用裝置。逐趟 CSV 只能做批次分析。")
            st.write("示範門檻尚未依車型、載重與感測器校正，也未做道路測試。語音不是車載安全警示系統，不能據此宣稱可預防事故或已證明節油。")
            st.caption("不使用麥克風。語音由瀏覽器／裝置提供，是否需網路及發音效果取決於所選語音服務。")
    st.markdown('<div class="footer-note">HINO Fleet Actions · 競賽概念 MVP　｜　建議需由管理者覆核；觀察變化不代表因果成效。</div>', unsafe_allow_html=True)


if __name__ == "__main__":
    main()
