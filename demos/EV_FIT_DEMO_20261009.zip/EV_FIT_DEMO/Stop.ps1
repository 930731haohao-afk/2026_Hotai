$ErrorActionPreference = 'Stop'
$pidPath = Join-Path $PSScriptRoot 'runtime\server.pid'
$appPath = Join-Path $PSScriptRoot 'app.py'
if (Test-Path -LiteralPath $pidPath) {
    $serverProcessId = 0
    if ([int]::TryParse((Get-Content -LiteralPath $pidPath -Raw).Trim(), [ref]$serverProcessId)) {
        $candidate = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction Stop
        if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($appPath) -and $candidate.CommandLine.Contains('streamlit')) {
            # Windows venv python may launch a base-python child; verify it too.
            $children = Get-CimInstance Win32_Process -Filter "ParentProcessId = $serverProcessId" -ErrorAction Stop
            foreach ($child in $children) {
                if ($child.CommandLine -and $child.CommandLine.Contains($appPath) -and $child.CommandLine.Contains('streamlit')) {
                    $childProcess = Get-Process -Id $child.ProcessId -ErrorAction SilentlyContinue
                    if ($childProcess) { $childProcess.Kill(); $childProcess.WaitForExit(3000) | Out-Null }
                }
            }
            $parentProcess = Get-Process -Id $serverProcessId -ErrorAction SilentlyContinue
            if ($parentProcess) { $parentProcess.Kill(); $parentProcess.WaitForExit(3000) | Out-Null }
            Write-Output 'EV FIT stopped.'
        }
    }
    Remove-Item -LiteralPath $pidPath
}
