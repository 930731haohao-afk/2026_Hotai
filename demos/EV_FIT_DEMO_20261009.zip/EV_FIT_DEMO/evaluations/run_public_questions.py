"""Reproduce the existing preview path, without modifying app/KB or calling LLMs."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
from ev.assistant import answer_question, load_knowledge, retrieve
from ev.explore import card_kind


def main():
    folder = BASE / "evaluations"
    inputs = ["public_questions_local.json", "public_questions_research.json", "public_questions_finance.json"]
    cases = []
    for name in inputs:
        cases.extend(json.loads((folder / name).read_text(encoding="utf-8")))
    knowledge = load_knowledge()
    results = []
    with patch("ev.assistant.generate", side_effect=AssertionError("A preview evaluation must not call a model")) as mock:
        for case in cases:
            question = case["question_zh"]
            result = answer_question(question, mode="preview", knowledge=knowledge)
            results.append({
                **case,
                "actual_mode": result["mode"],
                "actual_answer": result["answer"],
                "actual_follow_up": result["follow_up"],
                "actual_entries": result["entries"],
                "actual_card": card_kind(result),
                "retrieval_candidates": [{"id": e["id"], "score": e["score"]} for e in retrieve(question, knowledge=knowledge)],
            })
        assert mock.call_count == 0
    evidence = {
        "evaluated_at_utc": datetime.now(timezone.utc).isoformat(),
        "mode": "preview_only",
        "llm_calls": 0,
        "case_count": len(cases),
        "scope": "Purposive diagnostic questions paraphrased/translated from public posts; not a representative user sample or an LLM benchmark.",
        "production_files_sha256": {p: sha256((BASE / p).read_bytes()).hexdigest() for p in ["ev/assistant.py", "ev/explore.py", "data/knowledge.json"]},
        "results": results,
    }
    target = folder / "public_probe_results.json"
    target.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for result in results:
        print(result["id"], ",".join(e["id"] for e in result["actual_entries"]) or "none", result["actual_card"])
    print(f"Saved {len(results)} results; model calls: 0")


if __name__ == "__main__":
    main()
