"""Render human assessments beside reproducible current preview evidence."""
import json
from pathlib import Path

FOLDER = Path(__file__).resolve().parent
ASSESSMENTS = {
    "L01": ("基本相關", "有提醒沒有家充仍需確認固定補能機會與時間。可以更直接拆解加油與充電『一樣方便』的類比。", "條件澄清＋充電安排；先確認真實可用條件。"),
    "L02": ("未回答核心", "回家充安裝流程，沒有先釐清大雨、戶外設備適用性或受潮損壞。不是直接說安全，但也沒有處理這題的安全重點。", "安全條件確認；先問設備型號與異常狀態，不先展示成本或SOC。"),
    "L03": ("未回答核心", "因插電式油電等字詞命中動力類型介紹，回車型比較卡，沒有回答安裝安全。", "安裝條件確認；引導合格人員查核，不提供DIY施工步驟。"),
    "R01": ("未回答核心", "回充電損耗與計費端，沒有清楚回答同一套能量循環不能創造淨能量，也未解釋發電的減速負載。", "觀念澄清卡：原能量→驅動→回收與損耗，搭配簡短說明。"),
    "R02": ("部分切題", "有正確區分kW/kWh並追問數字來自哪裡；但沒有回到兩次充電紀錄異常的比較，也未請求起訖SOC、實際充電／連接時間或帳單口徑。", "單位確認＋紀錄對照卡。先整理證據，不武斷判為損耗、天冷或故障。"),
    "R03": ("未回答核心", "回80%以上快充可能變慢，卻沒有回答保留容量是否足以推論每天100%不影響電池，也未先確認車型和版本。", "車型／版本確認；分開談電池管理與快充時間。"),
    "F01": ("未回答核心", "問題核心是公共充電費與汽油費的比較口徑，卻回快充速度與高SOC，顯示關鍵字排名不等於理解意圖。", "同里程成本比較；先確認實際充電來源，不把家充示範比例當本人條件。"),
    "F02": ("部分切題", "有利率/APR與明細觀念，但沒有修正明示算式，也未直接比對同費用口徑。現有貸款卡為台幣固定預設示例，不能當作已讀懂這份美金報價。", "算式核對＋現金總價／分期總額對照；幣別、稅費與借款費用需一致。"),
}


def main():
    evidence = json.loads((FOLDER / "public_probe_results.json").read_text(encoding="utf-8"))
    synthetic = json.loads((FOLDER / "synthetic_probe_results.json").read_text(encoding="utf-8"))
    lines = [
        "# EV FIT 真實提問測試與回應設計", "",
        "查核與實測：2026-09-24。從7個公開討論串整理8題中文轉述，另加8題清楚標示的人工壓力案例。論壇提供真實疑問，正確知識另查官方資料，沒有把留言當作事實。", "",
        "**結論：目前知識庫預覽能處理部分常見問題，但尚不能可靠處理錯誤前提、數值矛盾與安全情境。** 有來源、有卡片、程式測試通過，都不等於已回答到使用者的問題。", "",
        "這次呼叫目前 `answer_question(..., mode='preview')` 與同一張卡片的類型選擇程式，共0次LLM呼叫；沒有改寫正式回答邏輯或知識庫。以下『實際回覆』是現行程式輸出，『建議回答』是根據官方資料撰寫的改善目標，不是實測LLM答案。", "",
        "這是刻意挑選困難題的診斷，不是隨機使用者樣本，不推估整體答對率。公開原題經繁中轉述或翻譯；措辭會影響目前關鍵字檢索結果。", "",
        "## 八題實測摘要", "",
        "|案例|問題重點|實際命中／卡片|人工檢視|", "|---|---|---|---|",
    ]
    card_names = {"charging": "充電安排", "energy": "能源費", "vehicles": "車型比較", "battery": "SOC／電量", "loan": "貸款示例", "next_steps": "下一步"}
    for case in evidence["results"]:
        status, observation, desired = ASSESSMENTS[case["id"]]
        ids = "、".join(e["id"] for e in case["actual_entries"]) or "無"
        lines.append(f"|{case['id']}|{case['question_zh']}|{ids}／{card_names[case['actual_card']]}|{status}|")
    lines += ["", "## 公開問題與實際／建議回覆", ""]
    for case in evidence["results"]:
        status, observation, desired = ASSESSMENTS[case["id"]]
        lines += [f"### {case['id']}：{case['thread_title']}", "",
                  f"原討論：[閱讀原帖]({case['thread_url']})；日期：{case.get('thread_date') or '未取得'}。下題是中文轉述，非逐字引文。", "",
                  f"**測試問題：** {case['question_zh']}", "",
                  "**現版實際回覆：**", "", case["actual_answer"], "",
                  f"實際追問：{case['actual_follow_up']}", "",
                  f"**檢視：{status}。** {observation}", "",
                  f"**建議回答：** {case['ideal_answer_zh']}", "",
                  f"建議只追問一件事：{case['clarifying_question']}", "",
                  f"合適的互動：{desired}", "",
                  "官方依據：" + "；".join(f"[{s['title']}]({s['url']})" for s in case["ground_truth_sources"]), "",
                  f"適用限制：{case['limitations']}", ""]
    lines += ["## 人工壓力案例（不是網友原話）", "",
              "|案例|人工測試句|觀察|", "|---|---|---|"]
    for case in synthetic["cases"]:
        query = case["query"] if case["id"] != "S08" else "刻意帶有假的API金鑰樣式字串"
        lines.append(f"|{case['id']}|{query}|{case['risk_observation']}|")
    lines += ["", "## 建議的回應順序", "",
              "1. **先理解意圖與條件。** 辨識是在問原理、個人適配、故障、安全或帳單；數字的單位、期間與幣別沒有對齊就先追問。",
              "2. **檢查前提。** 對『沒家充但80%在家充』等表面不一致先對齊定義；沒有專用充電樁，也可能仍有其他在家充電方式。里程則先確認每日與每月是否指相同日期和用途，不直接判定使用者說錯。",
              "3. **確認證據是否足以回答這題。** 命中相近文章不代表文章處理了雨天、進水、特定車型等關鍵限制；缺資料就清楚說明。",
              "4. **需要時才計算。** 算術與金額交給有單位與範圍檢查的程式；不讓模型憑空補費率、推定故障或承諾省錢。",
              "5. **再選互動卡。** 安全、矛盾或缺資料時先出確認卡；條件一致後才出成本／續航圖，卡片不能用漂亮數字掩蓋沒回答到問題。", "",
              "例如，對人工案例『沒有家充，但80%充電都在家』，建議答：『我先確認「沒有家充」的意思：是完全不能在家充電，還是沒有專用充電樁、但仍用其他合規設備在家充電？』並提供「完全不能在家充／沒有專用樁但可在家充／只是未來假設」選項。這是建議設計，尚未實作成矛盾判斷器。", "",
              "## 優先補強與驗收", "",
              "優先補安全情境與條件矛盾，再補語意／答案充分性判斷、單位與期間一致性、最後才調整互動卡推薦。不要只擴充更多圖表。",
              "拿這組題目作回歸集，但另留未看過的新題做驗證；不可只為這16句寫規則便宣稱能理解所有用戶。真實LLM需另測不同說法、多輪修正、拒答、逐句引用與延遲。", "",
              "## 可重跑的證據", "",
              "在 `ev-mvp` 資料夾執行：", "", "```powershell", "..\\hino-mvp\\.venv\\Scripts\\python.exe -X utf8 evaluations/run_public_questions.py", "```", "",
              "- `public_questions_*.json`：公開問題的來源、日期、轉述、理想回覆及限制。",
              "- `public_probe_results.json`：8題實際輸出、檢索排序、卡片類型及正式程式／知識庫SHA256。",
              "- `synthetic_probe_results.json`：8題人工壓力案例與完整結果。",
              "- 卡片翻頁為本次另行完成的介面更新，不代表上述回答品質缺口已修復。", ""]
    target = FOLDER / "真實提問測試報告.md"
    target.write_text("\n".join(lines), encoding="utf-8")
    print(target)


if __name__ == "__main__":
    main()
