"""Question-first Streamlit UI; credentials and chats stay in session memory."""
from __future__ import annotations

import math
import os
import re
import time
import uuid

import streamlit as st

from ev.assistant import answer_question, load_knowledge
from ev.intake import parse_description
from ev.llm import DEFAULT_MODELS, LLMConfig, PROVIDER_NAMES, ProviderError
from ev.interactive_ui import render_interaction


MAX_MESSAGES = 20
MAX_LLM_ATTEMPTS = 30
MIN_REQUEST_INTERVAL = 2.0
STARTERS = (
    ("沒有家充，也能換電動車嗎？", "如果不能裝家充，還適合買電動車嗎？"),
    ("省下油錢，就代表比較便宜？", "電動車省下的能源費，跟總持有成本 TCO 有什麼不同？"),
    ("油車、油電、純電怎麼分？", "燃油車 ICE、油電車 HEV 與純電車 BEV 有什麼差別？"),
    ("買車只看貸款月付夠嗎？", "買車貸款只看每個月的月付金就夠了嗎？還要注意哪些成本？"),
)


def _initialize():
    defaults = {"chat_messages": [], "answer_mode": "preview", "llm_request_count": 0,
                "llm_total_estimated_usd": 0.0, "llm_unknown_cost_calls": 0,
                "llm_provider": "openai", "llm_api_key": "", "_active_reply_id": None}
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


def _clear_chat():
    st.session_state["chat_messages"] = []
    st.session_state["_active_reply_id"] = None
    st.session_state["_explore_state"] = {}
    for key in list(st.session_state):
        if str(key).startswith("explore_"):
            del st.session_state[key]
    for key in ("_pending_question", "_chat_error"):
        st.session_state.pop(key, None)
    # Keep the attempt count, timing gate and cost totals for this session.


def _queue_question(question):
    st.session_state["_pending_question"] = question


def _go_to_simulation():
    descriptions = [m["content"] for m in st.session_state.get("chat_messages", []) if m.get("role") == "user"]
    description = "\n".join(descriptions)[-1000:]
    extracted = parse_description(description)
    if extracted["fields"]:
        st.session_state["intake_result"] = extracted
        st.session_state["intake_description"] = description
        st.session_state["_sim_mode"] = "advanced"
    st.session_state["product_page"] = "生活適配試算"


def _stage_card_simulation(fields, note):
    """Only queue card values for explicit confirmation in the other page."""
    if fields:
        st.session_state["intake_result"] = {"fields": dict(fields), "notes": [note, "這些值來自互動卡片，確認後才會套用。"]}
    else:
        st.session_state.pop("intake_result", None)
    st.session_state["_explore_handoff_note"] = note
    st.session_state["_sim_mode"] = "advanced"
    st.session_state["product_page"] = "生活適配試算"


def _provider_changed():
    # A typed key must not carry over into the next provider's input box.
    st.session_state["llm_api_key"] = ""
    st.session_state.pop("_llm_notice", None)


def _enable_llm():
    provider = st.session_state["llm_provider"]
    key = st.session_state.get("llm_api_key", "").strip()
    if provider == "openai" and not key:
        key = os.environ.get("OPENAI_API_KEY", "").strip()
    elif provider == "gemini" and not key:
        key = (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()
    if provider != "ollama" and not key:
        st.session_state["_llm_notice"] = ("error", "尚未提供 API 金鑰。請填入金鑰，或先在本機環境設定相對應的環境變數。")
        return
    try:
        config = LLMConfig(provider=provider,
                           model=st.session_state.get(f"llm_model_{provider}", DEFAULT_MODELS[provider]).strip(),
                           api_key="" if provider == "ollama" else key,
                           timeout=25, max_output_tokens=1000)
    except (ProviderError, ValueError) as error:
        st.session_state["_llm_notice"] = ("error", str(error))
        return
    st.session_state["_active_llm"] = config
    st.session_state["answer_mode"] = "llm"
    st.session_state["llm_api_key"] = ""
    st.session_state["_llm_notice"] = ("success", "設定已保存在本次連線中；下一次送出問題才會檢查模型連線。")


def _disable_llm():
    st.session_state.pop("_active_llm", None)
    st.session_state["llm_api_key"] = ""
    st.session_state["answer_mode"] = "preview"
    st.session_state["_llm_notice"] = ("info", "已清除本次連線的模型設定與輸入金鑰，切回知識庫摘錄；本機環境變數未變更。")


def _sidebar():
    with st.sidebar:
        st.markdown('<div class="brand">轉電之前<small>EV FIT</small></div><div class="quiet">從一個問題開始，想清楚再換車。</div>', unsafe_allow_html=True)
        st.divider()
        st.markdown("**你的換車知識助理**")
        st.caption("先聊充電、續航與成本觀念。想把答案放進自己的生活，再進入一週試算。")
        st.button("帶著我的條件去試算 →", key="chat_to_sim", on_click=_go_to_simulation, width="stretch")
        st.button("開始新對話", key="clear_chat", on_click=_clear_chat, width="stretch")
        st.caption("最多保留本次連線最近 20 則訊息，不會將對話或金鑰寫入 SQLite。")

        with st.expander("Demo 模型設定", expanded=False):
            st.caption("展示者設定一次即可；商用時由伺服器管理，客戶不用填金鑰。")
            st.selectbox("回答服務", list(DEFAULT_MODELS), format_func=lambda value: PROVIDER_NAMES[value],
                         key="llm_provider", on_change=_provider_changed)
            provider = st.session_state["llm_provider"]
            model_key = f"llm_model_{provider}"
            st.session_state.setdefault(model_key, DEFAULT_MODELS[provider])
            st.text_input("模型 ID", key=model_key, max_chars=128)
            if provider != "ollama":
                st.text_input("API 金鑰（只用於本次連線）", type="password", key="llm_api_key", max_chars=4096,
                              help="可留空使用本機環境變數；不要將金鑰貼進對話。")
                variable = "OPENAI_API_KEY" if provider == "openai" else "GEMINI_API_KEY 或 GOOGLE_API_KEY"
                st.caption(f"留空時讀取 {variable}。啟用後不會將環境變數內容回填畫面。")
                st.caption("啟用後，送出的問題、最多最近 6 則對話與公開知識片段，會交給選定的模型供應商。試算器裡的財務欄位不會自動送出。")
                st.caption("API 用量另外計費；ChatGPT／Codex 訂閱不包含這個網站的 API 費用。")
            else:
                st.caption("連接這台電腦的 Ollama；需已啟動服務並備妥模型。本頁不會下載或安裝模型。")
                st.caption("問題、最多最近 6 則對話與公開知識片段送至本機服務；不自動傳送試算器的財務欄位。")
            st.button("啟用選定模型", key="enable_llm", on_click=_enable_llm, width="stretch")
            st.button("清除設定，使用知識庫摘錄", key="disable_llm", on_click=_disable_llm, width="stretch")
            notice = st.session_state.get("_llm_notice")
            if notice:
                {"error": st.error, "success": st.success, "info": st.info}[notice[0]](notice[1])
            active = st.session_state.get("_active_llm")
            if st.session_state["answer_mode"] == "llm" and active:
                st.caption(f"目前啟用：{PROVIDER_NAMES[active.provider]} · {active.model}")
            count = st.session_state["llm_request_count"]
            total = st.session_state["llm_total_estimated_usd"]
            unknown = st.session_state["llm_unknown_cost_calls"]
            st.caption(f"本次連線模型嘗試 {count}/{MAX_LLM_ATTEMPTS} 次；已知用量估算 US$ {total:.5f}。")
            if unknown:
                st.caption(f"另有 {unknown} 次費用未知或未提供估算，不代表免費；實際費用以供應商帳單為準。")
            st.caption("開始新對話不會重設模型嘗試上限與用量記錄。")


def _submit_question(question, knowledge):
    question = question.strip()
    st.session_state.pop("_chat_error", None)
    if not question or len(question) > 1200:
        st.session_state["_chat_error"] = "請輸入 1–1,200 字的問題。"
        return
    if re.search(r"\bsk-[A-Za-z0-9_-]{12,}|\bAIza[A-Za-z0-9_-]{20,}", question):
        st.session_state["_chat_error"] = "問題似乎含有 API 金鑰，請移除後再問。金鑰應填在側欄模型設定。"
        return
    mode = st.session_state["answer_mode"]
    active = st.session_state.get("_active_llm")
    if mode == "llm":
        if active is None:
            st.session_state["_chat_error"] = "模型設定已失效，請在側欄重新啟用模型，或手動切回知識庫摘錄。"
            return
        if st.session_state["llm_request_count"] >= MAX_LLM_ATTEMPTS:
            st.session_state["_chat_error"] = "本次連線已達 30 次模型嘗試上限。仍可使用知識庫摘錄與生活適配試算。"
            return
        now = time.monotonic()
        if now - st.session_state.get("_last_llm_request_at", -math.inf) < MIN_REQUEST_INTERVAL:
            st.session_state["_chat_error"] = "請間隔至少 2 秒再送出下一個模型問題。"
            return
        st.session_state["_last_llm_request_at"] = now
        st.session_state["llm_request_count"] += 1
    history = [{"role": m["role"], "content": m["content"]} for m in st.session_state["chat_messages"][-6:]]
    try:
        with st.spinner("正在閱讀相關資料…" if mode == "preview" else "正在根據來源整理回答…"):
            result = answer_question(question, history, mode=mode, config=active, knowledge=knowledge)
    except (ProviderError, ValueError) as error:
        if mode == "llm":
            st.session_state["llm_unknown_cost_calls"] += 1
        st.session_state["_chat_error"] = str(error)
        return
    if result.get("mode") == "llm":
        cost = result.get("estimated_cost_usd")
        if isinstance(cost, (float, int)) and not isinstance(cost, bool) and math.isfinite(cost) and cost >= 0:
            st.session_state["llm_total_estimated_usd"] += cost
        else:
            st.session_state["llm_unknown_cost_calls"] += 1
    turn_id = uuid.uuid4().hex[:12]
    st.session_state["chat_messages"] = (st.session_state["chat_messages"] + [
        {"role": "user", "content": question},
        {"role": "assistant", "content": result["answer"], "result": result, "turn_id": turn_id},
    ])[-MAX_MESSAGES:]
    st.session_state["_active_reply_id"] = turn_id
    active_turns = {m.get("turn_id") for m in st.session_state["chat_messages"] if m["role"] == "assistant"}
    st.session_state["_explore_state"] = {key: value for key, value in st.session_state.get("_explore_state", {}).items() if key in active_turns}


def _single_follow_up(text):
    # A model must not turn the UI into a multi-question intake form.
    text = str(text or "").strip()
    if not text:
        return ""
    return re.split(r"(?<=[？?])", text, maxsplit=1)[0].strip()[:400]


def _answer_lead(text):
    paragraphs = [p.strip() for p in str(text).split("\n\n") if p.strip()]
    if len(paragraphs) > 1 and paragraphs[0].startswith("**") and paragraphs[0].endswith("**"):
        paragraphs.pop(0)
    first = paragraphs[0] if paragraphs else ""
    lead = re.split(r"(?<=[。！？])", first, maxsplit=1)[0]
    return lead if len(lead) <= 180 else lead[:180] + "…"


def _reply_pairs():
    """Keep conversation context intact; pair each reply with its user question."""
    replies, question = [], ""
    for message in st.session_state["chat_messages"]:
        if message["role"] == "user":
            question = message["content"]
        elif message["role"] == "assistant":
            # Existing sessions may contain messages from before turn IDs existed.
            message.setdefault("turn_id", uuid.uuid4().hex[:12])
            replies.append((message, question))
    return replies


def _navigate_reply(offset):
    """A deck navigation event changes selection only, never the conversation."""
    replies = [m for m in st.session_state["chat_messages"] if m["role"] == "assistant"]
    if not replies:
        return
    ids = [message["turn_id"] for message in replies]
    selected = st.session_state.get("_active_reply_id")
    index = ids.index(selected) if selected in ids else len(ids) - 1
    st.session_state["_active_reply_id"] = ids[max(0, min(len(ids) - 1, index + offset))]


def _render_messages(knowledge):
    curated = {source["url"]: source for source in knowledge["sources"]}
    replies = _reply_pairs()
    if not replies:
        return
    ids = [message["turn_id"] for message, _ in replies]
    selected = st.session_state.get("_active_reply_id")
    if selected not in ids:
        selected = ids[-1]
        st.session_state["_active_reply_id"] = selected
    index = ids.index(selected)
    message, question = replies[index]
    turn_id = message["turn_id"]

    # Only this reply's widgets are rendered. Per-turn exploration values live
    # independently of Streamlit's cleanup of widgets on other deck pages.
    with st.container(key="reply_deck"):
        st.caption("你的問題")
        st.text(question)
        with st.chat_message("assistant", avatar="🌿"):
            result = message.get("result", {})
            mode = result.get("mode", "preview")
            if mode == "llm":
                provider = PROVIDER_NAMES.get(result.get("provider"), "模型服務")
                st.caption(f"{provider} 回答 · {result.get('model', '')}")
            elif mode == "no_evidence":
                st.caption("目前來源不足 · 未呼叫模型")
            else:
                st.caption("知識庫摘錄 · 非 LLM 生成")
            # The service removes invented URLs/media and escapes HTML.
            st.markdown(_answer_lead(message["content"]), unsafe_allow_html=False)
            with st.expander("閱讀文字說明", expanded=False):
                st.markdown(message["content"], unsafe_allow_html=False)
            render_interaction(result, turn_id, _queue_question, _stage_card_simulation)
            if result.get("stale_sources"):
                st.warning("部分來源超過 120 天未重新核對；涉及現行條件時，請先確認官方更新。")
            sources = [curated[s["url"]] for s in result.get("sources", []) if s.get("url") in curated]
            if sources:
                with st.expander(f"查看資料來源（{len(sources)}）", expanded=False):
                    st.caption("引用 ID 核對不代表每句內容都經自動事實查核。")
                    for source in sources:
                        st.link_button(source["title"], source["url"])
                        st.caption(f"最後查核：{source['checked_at']}")
                    entries = result.get("entries", [])
                    if entries:
                        st.caption("參考知識條目：" + "、".join(e["id"] for e in entries))
            follow_up = _single_follow_up(result.get("follow_up"))
            if follow_up:
                st.markdown("**接著可以想一想**")
                st.markdown(follow_up, unsafe_allow_html=False)
        with st.container(key="reply_navigation"):
            previous, position, following = st.columns([1, 2, 1], vertical_alignment="center")
            previous.button("← 上一張", key="reply_previous", disabled=index == 0,
                            on_click=_navigate_reply, args=(-1,))
            position.markdown(f'<div style="text-align:center;color:#607056;font-size:14px">第 {index + 1} / {len(replies)} 張</div>', unsafe_allow_html=True)
            following.button("下一張 →", key="reply_next", disabled=index == len(replies) - 1,
                             on_click=_navigate_reply, args=(1,))
        st.caption("左右翻頁只回看歷史，不會重新生成回答；新問題會接續最新對話。")


def render_assistant():
    """Render one page; only a submitted or explicitly queued question runs work."""
    _initialize()
    _sidebar()
    try:
        knowledge = load_knowledge()
    except (OSError, ValueError, KeyError):
        st.error("目前無法讀取知識庫，請檢查本機資料檔。問答暫停，仍可切換生活適配試算。")
        return

    has_dialogue = bool(st.session_state["chat_messages"] or st.session_state.get("_pending_question") or st.session_state.get("question_input"))
    if has_dialogue:
        st.markdown("### 你的油轉電探索")
        st.caption("調整卡片看差異，或接著問一個問題。")
    else:
        left, right = st.columns([1.6, 1], gap="large")
        with left:
            st.markdown('<div class="eyebrow">BEFORE YOU SWITCH.</div>', unsafe_allow_html=True)
            st.markdown("<h1>想換電動車，<br>先把問題問清楚。</h1>", unsafe_allow_html=True)
            st.markdown("問一個問題，動手調整、比較，再決定下一步。")
        with right:
            st.markdown('<div class="ask-card"><div class="eyebrow">ASK · EXPLORE · DECIDE</div><div class="ask-orbit">↗</div><div class="hero-name">答案，可以動手探索。</div><div class="quiet">比較卡、情境圖表與下一步。<br>拖曳就能看懂條件改變的差異。</div></div>', unsafe_allow_html=True)
    if st.session_state["answer_mode"] == "preview":
        st.caption("知識庫摘錄 · 非 LLM 生成｜互動數值由程式計算")
    else:
        active = st.session_state.get("_active_llm")
        st.caption(f"LLM 模式 · {PROVIDER_NAMES[active.provider]} · 提問時才連線" if active else "LLM 模式 · 請重新確認側欄設定")

    with st.container():
        submitted = st.chat_input("例如：我住公寓，不能裝家充，會不會很麻煩？", key="question_input", max_chars=1200)
    columns = st.columns(2, gap="small")
    for index, (label, question) in enumerate(STARTERS):
        columns[index % 2].button(label, key=f"starter_{index}", on_click=_queue_question,
                                  args=(question,), width="stretch")
    st.caption("不需提供姓名、聯絡方式或完整地址。問答處理成本觀念；個人金額請交給生活適配試算。")
    pending = st.session_state.pop("_pending_question", None)
    if submitted or pending:
        _submit_question(submitted or pending, knowledge)
    if st.session_state.get("_chat_error"):
        st.error(st.session_state["_chat_error"])
        st.caption("這次未加入對話，也沒有改用其他回答模式。請調整後再送出。")
    if st.session_state["chat_messages"]:
        st.divider()
        _render_messages(knowledge)
    else:
        st.caption("可以點選一個常見問題，或直接輸入你想了解的事。")
    st.markdown('<div class="foot">研究展示原型 · 非 TOYOTA 官方服務。來源有市場與版本限制；最新報價、貸款條件及站點狀態需另行查核。</div>', unsafe_allow_html=True)
