"""Small, bounded HTTP adapters for real model calls; Python standard library only.

Documentation checked 2026-09-23:
OpenAI: https://developers.openai.com/api/docs/guides/structured-outputs?api-mode=responses
Pricing/model: https://developers.openai.com/api/docs/models/gpt-5.4-mini
Gemini: https://ai.google.dev/api/generate-content
Model: https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite
Ollama: https://docs.ollama.com/api/chat and https://docs.ollama.com/modelfile
Thinking: https://docs.ollama.com/capabilities/thinking

No credential discovery, SDK retries, tools, URL overrides, or server-side history.
The caller owns consent, prompt/retrieval construction, and citation allowlisting.
"""

from dataclasses import dataclass, field
import http.client
import json
import math
import re
import socket
from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


DEFAULT_MODELS = {
    "openai": "gpt-5.4-mini-2026-03-17",
    "gemini": "gemini-3.5-flash-lite",
    "ollama": "qwen3:4b",
}
PROVIDER_NAMES = {"openai": "OpenAI", "gemini": "Google Gemini", "ollama": "Ollama（本機）"}
MAX_RESPONSE_BYTES = 1024 * 1024
MAX_REQUEST_BYTES = 256 * 1024
MAX_HISTORY_CHARS = 60000
MAX_ANSWER_CHARS = 12000
MAX_FOLLOW_UP_CHARS = 1000
MAX_SOURCE_IDS = 20
_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_LOCAL_MODEL = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}\Z")
_SOURCE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,79}\Z")
_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "answer": {"type": "string", "description": "依提供的資料以繁體中文回答，不編造來源或個人資料。"},
        "source_ids": {"type": "array", "items": {"type": "string"}, "description": "僅列出本次提供且實際支持答案的來源 ID；無來源時為空陣列。"},
        "follow_up": {"type": "string", "description": "一個有助於下一步的簡短追問；不需要追問時為空字串。"},
    },
    "required": ["answer", "source_ids", "follow_up"],
    "additionalProperties": False,
}
_FORMAT_INSTRUCTION = (
    "請只輸出符合指定 JSON Schema 的物件，包含 answer、source_ids、follow_up。"
    "answer 使用繁體中文；source_ids 僅能使用對話中提供的來源 ID，不得創造 ID。"
    "沒有足夠資料時清楚說明缺少資訊；沒有追問時 follow_up 為空字串。"
)


class ProviderError(Exception):
    """A safe, user-facing error. Never include upstream messages or credentials."""


@dataclass(frozen=True)
class LLMConfig:
    provider: str = "openai"
    model: str = ""
    api_key: str = field(default="", repr=False)
    timeout: float = 25
    max_output_tokens: int = 1000

    def __post_init__(self):
        if not isinstance(self.provider, str) or self.provider not in DEFAULT_MODELS:
            raise ProviderError("請選擇支援的模型服務。")
        if not isinstance(self.model, str):
            raise ProviderError("模型名稱格式不正確。")
        if not self.model:
            object.__setattr__(self, "model", DEFAULT_MODELS[self.provider])
        pattern = _LOCAL_MODEL if self.provider == "ollama" else _MODEL
        if not pattern.fullmatch(self.model) or ".." in self.model or "//" in self.model:
            raise ProviderError("模型名稱格式不正確；請只填模型 ID。")
        if self.provider == "ollama" and re.search(r"(?:[:/-]cloud)(?:$|[:/-])", self.model, re.IGNORECASE):
            raise ProviderError("本機模式不支援 Ollama 雲端模型，請選擇已下載的本機模型。")
        if not isinstance(self.api_key, str) or len(self.api_key) > 4096 or any(ord(c) < 33 or ord(c) > 126 for c in self.api_key):
            raise ProviderError("API 金鑰格式不正確，請重新貼上。")
        if isinstance(self.timeout, bool) or not isinstance(self.timeout, (int, float)) or not math.isfinite(self.timeout) or not 1 <= self.timeout <= 60:
            raise ProviderError("連線等待時間須介於 1 至 60 秒。")
        if isinstance(self.max_output_tokens, bool) or not isinstance(self.max_output_tokens, int) or not 128 <= self.max_output_tokens <= 4096:
            raise ProviderError("輸出長度須介於 128 至 4096 tokens。")


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _http_error(status):
    if status in (401, 403):
        return ProviderError("模型服務拒絕驗證，請確認 API 金鑰、專案權限與模型存取資格。")
    if status == 429:
        return ProviderError("模型服務的額度或速率已達上限，請檢查用量後稍候再試。")
    if 300 <= status < 400:
        return ProviderError("模型服務要求轉址；為保護金鑰，本次連線已停止。")
    if status == 404:
        return ProviderError("找不到指定模型，請確認模型 ID、存取資格或本機模型是否已下載。")
    if status == 400:
        return ProviderError("模型服務不接受此請求，請確認模型支援文字與結構化輸出。")
    if status >= 500:
        return ProviderError("模型服務暫時無法使用，請稍候再試。")
    return ProviderError("模型服務回傳非預期狀態，本次未取得有效回答。")


def _reject_constant(_value):
    raise ValueError("invalid JSON number")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def _json_loads(text):
    return json.loads(text, parse_constant=_reject_constant, object_pairs_hook=_unique_object)


def _request_json(url, payload, headers, timeout):
    try:
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, UnicodeError):
        raise ProviderError("訊息包含無法傳送的內容，請重新輸入。") from None
    if len(body) > MAX_REQUEST_BYTES:
        raise ProviderError("這次對話內容過長，請縮短問題或清除較舊的對話。")
    request = Request(url, data=body, headers={"Content-Type": "application/json", "Accept": "application/json", "Accept-Encoding": "identity", **headers}, method="POST")
    # Do not inherit proxy routing, including for the local-only Ollama endpoint.
    opener = build_opener(ProxyHandler({}), _NoRedirect())
    try:
        with opener.open(request, timeout=timeout) as response:
            status = response.getcode()
            if not isinstance(status, int) or isinstance(status, bool):
                raise ProviderError("模型服務未回傳有效 HTTP 狀態。")
            if status != 200:
                raise _http_error(status)
            if response.geturl() != url:
                raise ProviderError("模型服務端點與指定位置不同，本次連線已停止。")
            length = response.headers.get("Content-Length")
            if length is not None:
                try:
                    length = int(length)
                except (TypeError, ValueError):
                    raise ProviderError("模型服務回傳無效的資料長度。") from None
                if length < 0 or length > MAX_RESPONSE_BYTES:
                    raise ProviderError("模型服務回覆超過大小上限，本次未顯示內容。")
            raw = response.read(MAX_RESPONSE_BYTES + 1)
    except HTTPError as error:
        status = error.code
        error.close()
        raise _http_error(status) from None
    except (TimeoutError, socket.timeout):
        raise ProviderError("模型服務回覆逾時，請稍候重試或降低輸出長度。") from None
    except URLError as error:
        timed_out = isinstance(error.reason, (TimeoutError, socket.timeout))
        message = "模型服務回覆逾時，請稍候重試。" if timed_out else "無法連接模型服務，請確認網路；本機模式請先啟動 Ollama。"
        raise ProviderError(message) from None
    except (OSError, http.client.HTTPException):
        raise ProviderError("模型服務連線中斷，請稍候重試。") from None
    if not isinstance(raw, bytes) or not raw or len(raw) > MAX_RESPONSE_BYTES:
        raise ProviderError("模型服務回覆為空或超過大小上限，本次未顯示內容。")
    try:
        response_json = _json_loads(raw.decode("utf-8"))
    except (ValueError, UnicodeError, RecursionError):
        raise ProviderError("模型服務回傳無效的 JSON，本次未顯示內容。") from None
    if not isinstance(response_json, dict) or response_json.get("error"):
        raise ProviderError("模型服務未回傳有效回答，請稍候再試。")
    return response_json


def _messages(messages):
    if not isinstance(messages, list) or not 1 <= len(messages) <= 32:
        raise ProviderError("對話訊息為空或過長，請重新開始對話。")
    clean, total, seen_dialogue = [], 0, False
    for message in messages:
        if not isinstance(message, dict) or set(message) != {"role", "content"}:
            raise ProviderError("對話訊息格式不正確。")
        role, content = message["role"], message["content"]
        if role not in ("system", "developer", "user", "assistant") or not isinstance(content, str) or not content.strip():
            raise ProviderError("對話角色或文字格式不正確。")
        if role in ("system", "developer") and seen_dialogue:
            raise ProviderError("系統指示須置於對話開頭。")
        if role in ("user", "assistant"):
            seen_dialogue = True
        total += len(content)
        if len(content) > 30000 or total > MAX_HISTORY_CHARS:
            raise ProviderError("這次對話內容過長，請縮短問題或清除較舊的對話。")
        clean.append({"role": role, "content": content})
    dialogue = [m for m in clean if m["role"] in ("user", "assistant")]
    if not dialogue or dialogue[0]["role"] != "user" or dialogue[-1]["role"] != "user":
        raise ProviderError("對話必須由使用者問題開始，最後一則也須為使用者問題。")
    return clean


def _structured_answer(text):
    if not isinstance(text, str) or not text.strip() or len(text) > 64000:
        raise ProviderError("模型沒有提供有效的文字回答。")
    try:
        answer = _json_loads(text)
    except (ValueError, RecursionError):
        raise ProviderError("模型回答未符合指定格式，本次未顯示內容；請重試。") from None
    if not isinstance(answer, dict) or set(answer) != {"answer", "source_ids", "follow_up"}:
        raise ProviderError("模型回答欄位不完整或含額外欄位，本次未顯示內容。")
    if not isinstance(answer["answer"], str) or not answer["answer"].strip() or len(answer["answer"]) > MAX_ANSWER_CHARS:
        raise ProviderError("模型回答為空或過長，本次未顯示內容。")
    if not isinstance(answer["follow_up"], str) or len(answer["follow_up"]) > MAX_FOLLOW_UP_CHARS:
        raise ProviderError("模型的追問格式不正確，本次未顯示內容。")
    ids = answer["source_ids"]
    if not isinstance(ids, list) or len(ids) > MAX_SOURCE_IDS or any(not isinstance(item, str) or not _SOURCE_ID.fullmatch(item) for item in ids):
        raise ProviderError("模型的來源引用格式不正確，本次未顯示內容。")
    return {"answer": answer["answer"].strip(), "source_ids": list(dict.fromkeys(ids)), "follow_up": answer["follow_up"].strip()}


def _token_count(value):
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 100000000:
        raise ProviderError("模型服務回傳無效的用量資訊，本次未顯示內容。")
    return value


def _openai(messages, config):
    payload = {"model": config.model, "input": [{"role": "system", "content": _FORMAT_INSTRUCTION}] + messages,
               "text": {"format": {"type": "json_schema", "name": "ev_answer", "strict": True, "schema": _JSON_SCHEMA}},
               "max_output_tokens": config.max_output_tokens, "store": False}
    if config.model in ("gpt-5.4-mini", "gpt-5.4-mini-2026-03-17"):
        payload["reasoning"] = {"effort": "none"}
    response = _request_json("https://api.openai.com/v1/responses", payload, {"Authorization": "Bearer " + config.api_key}, config.timeout)
    if response.get("status") != "completed":
        raise ProviderError("模型回答尚未完成或已中止，本次不使用部分回答；請重試。")
    output = response.get("output")
    if not isinstance(output, list):
        raise ProviderError("模型服務沒有回傳有效的回答內容。")
    texts = []
    for item in output:
        if not isinstance(item, dict):
            raise ProviderError("模型服務回答結構不正確。")
        if item.get("type") == "reasoning":
            continue
        if item.get("type") != "message" or item.get("role") != "assistant" or item.get("status", "completed") != "completed":
            raise ProviderError("模型回傳非預期內容，本次不使用回答。")
        content = item.get("content")
        if not isinstance(content, list):
            raise ProviderError("模型服務回答結構不正確。")
        for block in content:
            if not isinstance(block, dict):
                raise ProviderError("模型服務回答結構不正確。")
            if block.get("type") == "refusal":
                raise ProviderError("模型拒絕回答這個問題，請調整問題內容。")
            if block.get("type") != "output_text" or not isinstance(block.get("text"), str):
                raise ProviderError("模型回傳非預期內容，本次不使用回答。")
            texts.append(block["text"])
    usage = response.get("usage")
    if usage is None:
        usage = {}
    if not isinstance(usage, dict):
        raise ProviderError("模型服務回傳無效的用量資訊。")
    counts = {"input_tokens": _token_count(usage.get("input_tokens")), "output_tokens": _token_count(usage.get("output_tokens"))}
    cost = None
    if config.model in ("gpt-5.4-mini", "gpt-5.4-mini-2026-03-17") and None not in counts.values():
        # Conservative standard price estimate: excludes cache discounts, tax,
        # account credits and any provider-specific billing adjustments.
        cost = (counts["input_tokens"] * 0.75 + counts["output_tokens"] * 4.5) / 1000000
    return "".join(texts), counts, cost


def _gemini(messages, config):
    system = [_FORMAT_INSTRUCTION] + [m["content"] for m in messages if m["role"] in ("system", "developer")]
    contents = []
    for message in messages:
        if message["role"] in ("system", "developer"):
            continue
        role = "model" if message["role"] == "assistant" else "user"
        part = {"text": message["content"]}
        if contents and contents[-1]["role"] == role:
            contents[-1]["parts"].append(part)
        else:
            contents.append({"role": role, "parts": [part]})
    payload = {"systemInstruction": {"parts": [{"text": "\n\n".join(system)}]}, "contents": contents,
               "generationConfig": {"maxOutputTokens": config.max_output_tokens, "candidateCount": 1,
                                    "responseFormat": {"text": {"mimeType": "APPLICATION_JSON", "schema": _JSON_SCHEMA}}}}
    response = _request_json("https://generativelanguage.googleapis.com/v1beta/models/" + config.model + ":generateContent", payload, {"x-goog-api-key": config.api_key}, config.timeout)
    feedback = response.get("promptFeedback")
    if isinstance(feedback, dict) and feedback.get("blockReason"):
        raise ProviderError("模型服務拒絕處理這個問題，請調整問題內容。")
    candidates = response.get("candidates")
    if not isinstance(candidates, list) or len(candidates) != 1 or not isinstance(candidates[0], dict):
        raise ProviderError("模型服務沒有回傳單一有效回答。")
    candidate = candidates[0]
    if candidate.get("finishReason") != "STOP":
        raise ProviderError("模型回答尚未完成或遭服務商中止，本次不使用部分回答。")
    content = candidate.get("content")
    if not isinstance(content, dict) or content.get("role", "model") != "model" or not isinstance(content.get("parts"), list):
        raise ProviderError("模型服務回答結構不正確。")
    texts = []
    for part in content["parts"]:
        if not isinstance(part, dict):
            raise ProviderError("模型服務回答結構不正確。")
        if part.get("thought") is True:
            continue
        if not isinstance(part.get("text"), str) or any(key in part for key in ("functionCall", "inlineData", "fileData", "executableCode")):
            raise ProviderError("模型回傳非預期內容，本次不使用回答。")
        texts.append(part["text"])
    usage = response.get("usageMetadata")
    if usage is None:
        usage = {}
    if not isinstance(usage, dict):
        raise ProviderError("模型服務回傳無效的用量資訊。")
    input_tokens = _token_count(usage.get("promptTokenCount"))
    output_tokens = _token_count(usage.get("candidatesTokenCount"))
    thoughts = _token_count(usage.get("thoughtsTokenCount", 0))
    if output_tokens is not None and thoughts is not None:
        output_tokens += thoughts
    return "".join(texts), {"input_tokens": input_tokens, "output_tokens": output_tokens}, None


def _ollama(messages, config):
    system = [_FORMAT_INSTRUCTION] + [message["content"] for message in messages if message["role"] in ("system", "developer")]
    normalized = [{"role": "system", "content": "\n\n".join(system)}]
    normalized += [message for message in messages if message["role"] in ("user", "assistant")]
    payload = {"model": config.model, "messages": normalized, "format": _JSON_SCHEMA, "stream": False,
               "options": {"num_predict": config.max_output_tokens, "num_ctx": 8192}}
    if config.model.split(":", 1)[0].rsplit("/", 1)[-1] == "qwen3":
        # The verified local default otherwise spends its bounded output budget
        # on thinking before the JSON answer. Do not impose this on other models.
        payload["think"] = False
    response = _request_json("http://127.0.0.1:11434/api/chat", payload, {}, config.timeout)
    if response.get("done") is not True or response.get("done_reason") != "stop":
        raise ProviderError("本機模型回答尚未完成或已達長度上限，本次不使用部分回答。")
    message = response.get("message")
    if not isinstance(message, dict) or message.get("role") != "assistant" or message.get("tool_calls"):
        raise ProviderError("本機模型沒有回傳有效的文字回答。")
    counts = {"input_tokens": _token_count(response.get("prompt_eval_count")), "output_tokens": _token_count(response.get("eval_count"))}
    return message.get("content"), counts, None


def generate(messages: list[dict], config: LLMConfig) -> dict:
    """Perform exactly one model request and return validated structured output.

    Missing usage is represented by None, never zero. A successful adapter
    response does not prove citations are grounded; the caller must allowlist
    source_ids against the actual retrieved evidence before showing the answer.
    """
    if not isinstance(config, LLMConfig):
        raise ProviderError("模型設定格式不正確。")
    if config.provider != "ollama" and not config.api_key:
        raise ProviderError("尚未提供 API 金鑰；請先完成模型連線設定。")
    clean = _messages(messages)
    text, usage, cost = {"openai": _openai, "gemini": _gemini, "ollama": _ollama}[config.provider](clean, config)
    result = _structured_answer(text)
    result.update({"provider": config.provider, "model": config.model, "usage": usage, "estimated_cost_usd": cost})
    return result
