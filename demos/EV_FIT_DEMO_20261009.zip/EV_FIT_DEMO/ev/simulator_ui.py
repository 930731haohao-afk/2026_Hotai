"""EV FIT: a local, deterministic, source-aware EV lifestyle prototype."""
from __future__ import annotations

import html
import json
import math
import os
from dataclasses import asdict
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from ev.engine import Ownership, Profile, compare_scenarios, summarize
from ev.intake import parse_description
from ev.reports import build_html, build_markdown
from ev.storage import Store

BASE = Path(__file__).resolve().parents[1]


def _open_detailed():
    st.session_state["_sim_mode"] = "advanced"


def _return_to_guided():
    """Keep the current editor values, including a just-changed widget."""
    defaults = asdict(Profile())
    previous = st.session_state.get("_saved_profile", {})
    profile = {k: st.session_state.get("p_" + k, previous.get(k, v)) for k, v in defaults.items()}
    Profile(**profile)
    st.session_state["_saved_profile"] = profile
    owner_defaults = asdict(Ownership())
    owner_previous = st.session_state.get("_saved_ownership", {})
    st.session_state["_saved_ownership"] = {k: st.session_state.get("o_" + k, owner_previous.get(k, v)) for k, v in owner_defaults.items()}
    charging = "home" if profile["home_charging"] == "yes" else "unknown" if profile["home_charging"] == "unknown" else "public" if profile["public_available"] else "unavailable"
    st.session_state["_guided_answers"] = {"distance": "custom", "distance_km": profile["weekday_km"],
        "charging": charging, "trips": "custom", "weekend_km": profile["weekend_km"], "trips_per_month": profile["trips_per_month"]}
    for suffix, field in [("distance_km", "weekday_km"), ("weekend_km", "weekend_km"), ("trips_per_month", "trips_per_month")]:
        st.session_state["_guided_custom_" + suffix] = float(profile[field])
        st.session_state.pop("guided_custom_" + suffix, None)
    st.session_state["_guided_step"] = 3
    st.session_state["_guided_pending"] = ["家充與可用公共充電條件仍待確認。"] if charging == "unknown" else []
    st.session_state["_guided_assumptions"] = ["沿用詳細調整中的條件；選項卡不會把你的數字取整或換回示範值。"]
    st.session_state.pop("_guided_edit_stage", None)
    st.session_state.pop("_guided_custom_open", None)
    st.session_state.pop("_guided_error", None)
    st.session_state["_sim_mode"] = "guided"


def render_simulator():
    """Choice-first by default; keep the complete calculator on demand."""
    st.session_state.setdefault("_sim_mode", "guided")
    if st.session_state["_sim_mode"] == "advanced":
        st.button("← 回到選項式試算", key="sim_back_to_quick", on_click=_return_to_guided)
        render_detailed_simulator()
    else:
        from ev.guided_ui import render_guided_simulator
        render_guided_simulator(_open_detailed)


def render_detailed_simulator():
    if st.session_state.get("_explore_handoff_note"):
        st.info(st.session_state.pop("_explore_handoff_note"))
    def esc(value):
        return html.escape(str(value))


    def n(value, digits=0):
        return "—" if value is None else f"{value:,.{digits}f}"


    def money(value):
        return "暫不估算" if value is None else f"NT$ {value:,.0f}"


    DEFAULTS = asdict(Profile())
    DEFAULTS["home_power_kw"] = 7.0
    for key, value in DEFAULTS.items():
        st.session_state.setdefault("p_" + key, st.session_state.get("_saved_profile", {}).get(key, value))
    st.session_state.setdefault("scenario_name", "家充尚未確認的通勤家庭")
    OWN_DEFAULTS = asdict(Ownership())
    OWN_DEFAULTS["ev_price"] = 1280000.0
    for key, value in OWN_DEFAULTS.items():
        st.session_state.setdefault("o_" + key, st.session_state.get("_saved_ownership", {}).get(key, value))


    def apply_preset(kind):
        vals = dict(DEFAULTS)
        if kind == "home":
            vals.update(home_charging="yes", weekday_km=40, weekend_km=200, trips_per_month=4)
            name = "有家充的通勤家庭"
        elif kind == "public":
            vals.update(home_charging="no", weekday_km=40, weekend_km=200, trips_per_month=4)
            name = "依賴公共充電的家庭"
        elif kind == "challenge":
            vals.update(home_charging="no", weekday_km=100, weekend_km=450, trips_per_month=4, public_hours=0.25)
            name = "充電時間有限的長途家庭"
        else:
            name = "家充尚未確認的通勤家庭"
        for key, value in vals.items():
            st.session_state["p_" + key] = value
        st.session_state["scenario_name"] = name


    def mark_custom():
        st.session_state["scenario_name"] = "你的自訂情境"


    def apply_intake():
        for key, value in st.session_state.get("intake_result", {}).get("fields", {}).items():
            if key in DEFAULTS:
                st.session_state["p_" + key] = value
        st.session_state["scenario_name"] = "已確認的文字輸入"
        st.session_state.pop("intake_result", None)


    def pnum(label, name, low, high, step=1.0, help=None):
        # Normalize callback-assigned ints to Streamlit's floating-point widget type.
        st.session_state["p_" + name] = float(st.session_state["p_" + name])
        return st.slider(label, min_value=float(low), max_value=float(high), step=float(step), key="p_" + name, help=help, on_change=mark_custom)


    def toggle_cost_known(field):
        amount_key = "o_" + field
        cache_key = "_cost_last_amount_" + field
        current = st.session_state.get(amount_key)
        if st.session_state["cost_known_" + field]:
            st.session_state[amount_key] = float(current if current is not None else st.session_state.get(cache_key, 0.0))
        else:
            if current is not None:
                st.session_state[cache_key] = float(current)
            st.session_state[amount_key] = None


    def optional_cost_slider(field, label):
        amount_key = "o_" + field
        known_key = "cost_known_" + field
        st.session_state.setdefault(known_key, st.session_state[amount_key] is not None)
        st.markdown(f"**{label}**")
        known = st.checkbox("已確認此項金額（可為 0）", key=known_key,
                            help=label, on_change=toggle_cost_known, args=(field,))
        if not known:
            st.session_state[amount_key] = None
            st.caption("尚未確認，保留未知；不會以 0 元計入。")
            return
        current = st.session_state[amount_key]
        if current is None:
            current = st.session_state.get("_cost_last_amount_" + field, 0.0)
        st.session_state[amount_key] = float(current)
        if field.endswith("_year"):
            upper, step = 200000.0, 500.0
        elif field == "home_install":
            upper, step = 500000.0, 1000.0
        else:
            upper, step = 5000000.0, 1000.0
        # A previously entered amount must not be truncated by the quick range.
        range_key = "_cost_slider_upper_" + field
        previous_upper = st.session_state.get(range_key)
        upper = max(upper, previous_upper or 0.0, math.ceil(float(current) / step) * step)
        slider_default = {}
        if previous_upper != upper:
            # Streamlit treats new bounds as a new widget. Carry the amount
            # through its default, rather than letting it reset to the minimum.
            st.session_state.pop(amount_key, None)
            st.session_state[range_key] = upper
            slider_default["value"] = float(current)
        st.slider(label + "（NT$）", min_value=0.0, max_value=upper,
                  step=step, key=amount_key, format="NT$ %.0f", **slider_default)


    with st.sidebar:
        st.markdown('<div class="brand">轉電之前<small>EV FIT</small></div><div class="quiet">先讓電動車，試著過你的一週。</div>', unsafe_allow_html=True)
        st.divider()
        st.markdown("### 01　你的日常")
        pnum("平日每天往返里程（km）", "weekday_km", 0, 500, 5)
        pnum("一趟週末往返里程（km）", "weekend_km", 0, 1500, 20)
        pnum("每月週末出遊（趟）", "trips_per_month", 0, 4.33, 1, "每週最多安排一趟，試算一年以 52 週計。")
        pnum("目前油車實際油耗（km/L）", "fuel_km_l", 1, 50, 0.5)
        st.markdown("### 02　在哪裡充電")
        st.selectbox("家充安裝條件", ["unknown", "yes", "no"], format_func=lambda x: {"unknown": "有待確認", "yes": "已確認可以家充", "no": "無法在家充電"}[x], key="p_home_charging", on_change=mark_custom)
        st.caption("有停車位不代表能安裝家充。未確認時，先按無家充試算。")
        if st.session_state["p_home_charging"] == "yes":
            pnum("每天在家可充電（小時）", "home_hours", 0, 24, 0.5)
        st.checkbox("有可用的公共充電選項", key="p_public_available", on_change=mark_custom, help="由你確認充電地點、接口與可用時間；本版未連接即時充電樁。")
        if st.session_state["p_public_available"]:
            pnum("每天可用的公共充電時間（小時）", "public_hours", 0, 12, 0.25, "每天至多一次補電，另計往返及等待時間；週末最後另有恢復起始電量的補電。")
            pnum("每次繞路＋等待（分鐘）", "detour_minutes", 0, 240, 5)
        with st.expander("能源費率與充電費用"):
            st.caption("以下均為可替換的情境假設，並非今日報價。")
            pnum("汽油（NT$/L）", "fuel_price", 1, 100, 0.5)
            pnum("家充（NT$/kWh）", "home_price", 0, 30, 0.5)
            pnum("公共充電（NT$/kWh）", "public_price", 0, 50, 0.5)
            pnum("每次公共充電附加費（NT$）", "public_parking_fee", 0, 1000, 10, "例如停車／服務費；不含電費。")
        with st.expander("耗能、電量與充電假設"):
            st.caption("可用容量與道路耗能為展示假設，可用實測值取代；官方 74.7 kWh 未標明可用容量。")
            pnum("可用電池容量（kWh）", "battery_kwh", 10, 100, 1)
            pnum("電池端耗能（kWh/100km）", "consumption_kwh_100km", 5, 60, 0.5)
            pnum("充電效率（0–1）", "charging_efficiency", 0.5, 1, 0.01, "計費電量＝電池耗能÷效率，只計一次損耗。")
            pnum("家充有效功率（kW）", "home_power_kw", 0.1, 11, 0.5)
            pnum("公共有效功率（kW）", "public_power_kw", 1, 160, 5, "為情境有效功率；80% 以上最多 20 kW，並非實測車款充電曲線。")
            pnum("週初電量（%）", "initial_soc", 20, 100, 5)
            pnum("備援電量（%）", "reserve_soc", 5, 50, 5)
        st.caption("輸入只用於本機計算。按下儲存後，才寫入本機紀錄。")


    left, right = st.columns([1.65, 1], gap="large")
    with left:
        st.markdown('<div class="eyebrow">YOUR LIFE, ELECTRIFIED.</div>', unsafe_allow_html=True)
        st.markdown("<h1>換成電動車，<br>你的生活要改多少？</h1>", unsafe_allow_html=True)
        st.markdown("從一週的真實安排出發，看懂充電、時間與支出。  \n先確認適不適合，再決定下一步。")
    with right:
        st.markdown('<div class="hero"><div class="hero-label">本次模擬車款 · 台灣版本</div><div class="hero-name">TOYOTA bZ4X</div><span class="pill">202510 規格</span><span class="pill">前輪驅動</span><div class="hero-bottom">官方電池容量 74.7 kWh<br>道路耗能與可用容量另設假設<br>研究原型 · 非 TOYOTA 官方服務</div><div class="battery"><div class="battery-fill"></div></div></div>', unsafe_allow_html=True)
    st.markdown('<div class="stepbar"><span><b>01</b>填入生活</span><span><b>02</b>看一週變化</span><span><b>03</b>帶走下一步</span></div>', unsafe_allow_html=True)

    with st.expander("用一句話開始，或選一個示範情境", expanded="intake_result" in st.session_state):
        presets = st.columns(4)
        for col, label, kind in zip(presets, ["家充待確認", "已確認有家充", "依賴公共充電", "長途＋時間有限"], ["unknown", "home", "public", "challenge"]):
            col.button(label, on_click=apply_preset, args=(kind,), width="stretch")
        st.session_state.setdefault("intake_description", "平日每天40公里，週末200公里，每月4趟，油耗14公里/公升，有車位但不確定能不能裝家充。")
        description = st.text_area("描述你的用車習慣", max_chars=1000, key="intake_description")
        st.caption("本機規則擷取：支援里程、出遊次數、油耗及家充條件；請確認欄位後套用。未連接生成式 AI。")
        if st.button("擷取可辨識欄位"):
            st.session_state["intake_result"] = parse_description(description)
        if "intake_result" in st.session_state:
            intake = st.session_state["intake_result"]
            field_names = {"weekday_km": "平日往返 km", "weekend_km": "週末一趟往返 km", "trips_per_month": "每月週末出遊次數", "fuel_km_l": "實際油耗 km/L", "home_charging": "家充條件", "home_hours": "家充時數"}
            if intake["fields"]:
                st.dataframe(pd.DataFrame([{"待確認欄位": field_names.get(k, k), "擷取內容": {"unknown": "待確認", "yes": "可以", "no": "無法"}.get(str(v), str(v))} for k, v in intake["fields"].items()]), hide_index=True, width="stretch")
                st.button("確認這些欄位並套用", type="primary", on_click=apply_intake)
            else:
                st.info("尚無可安全套用的欄位，請改用左側表單。")
            for note in intake.get("notes", []):
                st.caption(note)


    st.caption(f"目前情境：{st.session_state['scenario_name']}　·　修改左側條件會立即重算　·　起始值為示範假設")

    # Optional ownership inputs are collected before computing the single shared result.
    with st.expander("補上購車與持有成本（選填，未確認代表未知）"):
        st.selectbox("油車比較基準", ["keep", "new"], format_func=lambda x: "繼續使用現有油車" if x == "keep" else "另外買一台新油車", key="o_baseline")
        st.session_state["p_years"] = int(st.session_state["p_years"])
        years_value = st.session_state["p_years"]
        years_upper = max(15, st.session_state.get("_years_slider_max", 15), years_value)
        years_default = {}
        if st.session_state.get("_years_slider_max") != years_upper:
            st.session_state.pop("p_years", None)
            st.session_state["_years_slider_max"] = years_upper
            years_default["value"] = years_value
        st.slider("相同持有期間（年）", min_value=1, max_value=years_upper, step=1, key="p_years", **years_default)
        st.caption("先勾選已確認的費用，再拖曳金額；只有確定實際為 0 元時才保留 0。未勾選的項目仍是未知。")
        ownership_labels = [
            ("ice_value", "現有油車目前可售價／新油車購入價"), ("ev_price", "電動車購入價（官方起始值，可改實際報價）"),
            ("ice_resale", "持有期末油車預估殘值"), ("ev_resale", "持有期末電動車預估殘值"),
            ("ice_maintenance_year", "油車每年保養費"), ("ev_maintenance_year", "電動車每年保養費"),
            ("ice_insurance_year", "油車每年保險費"), ("ev_insurance_year", "電動車每年保險費"),
            ("ice_tax_year", "油車每年稅費"), ("ev_tax_year", "電動車每年稅費"),
            ("home_install", "家充設備＋安裝一次性費用"), ("extra_ev_parking_year", "電動車每年額外固定停車費"),
        ]
        cost_cols = st.columns(2)
        for idx, (key, label) in enumerate(ownership_labels):
            with cost_cols[idx % 2]:
                optional_cost_slider(key, label)
        st.caption("確定沒有費用時填 0。保留現有油車以目前可售價減未來殘值估折舊，不重算當年已付購車款；未納入貸款利息與折現。")

    try:
        profile = Profile(**{k: st.session_state["p_" + k] for k in DEFAULTS})
        ownership = Ownership(**{k: st.session_state["o_" + k] for k in OWN_DEFAULTS})
        result = summarize(profile, ownership)
        alternatives = compare_scenarios(profile)
    except (ValueError, TypeError) as exc:
        st.error(f"請先修正輸入：{exc}")
        st.stop()

    week = result["week"]
    decision = result["decision"]
    st.markdown(f'<div class="verdict {esc(decision["status"])}"><div class="verdict-title">{esc(decision["title"])}</div><div class="verdict-copy">{esc("；".join(decision.get("reasons", [])[:2]))}</div></div>', unsafe_allow_html=True)

    with st.container(key="kpis"):
        k = st.columns(4)
        saving = result["monthly_energy_saving"]
        k[0].metric("每月能源費用可省" if saving is None or saving >= 0 else "每月能源費用增加", money(None if saving is None else abs(saving)))
        k[1].metric("每週額外充電時間", "—" if result["weekly_extra_minutes"] is None else n(result["weekly_extra_minutes"]) + " 分鐘")
        k[2].metric("出遊週公共充電次數", n(week["public_sessions"]) + " 次")
        k[3].metric("同條件估算年里程", n(result["annual_km"]) + " km")
    st.caption("費用為情境估算；能源差額不是總持有成本差額。額外時間包含公共充電與自填繞路／等待，不扣原油車加油時間。")

    tabs = st.tabs(["一週生活模擬", "成本拆開看", "換個條件試試", "報告與下一步"])
    with tabs[0]:
        graph_col, detail_col = st.columns([2.1, 1], gap="large")
        with graph_col:
            st.subheader("電量，跟得上你的日常嗎？")
            st.caption("顯示含一次週末出遊的代表週；若出遊頻率為 0，則顯示通勤週。週末另補回起始電量，避免靠消耗初始電池假裝省時。")
            days = week["days"]
            labels = [str(d["day"]) for d in days]
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=labels, y=[d["end_soc"] for d in days], mode="lines+markers", name="當日結束電量", line=dict(color="#47784e", width=3, shape="linear"), marker=dict(size=8), fill="tozeroy", fillcolor="rgba(137,171,112,.13)", hovertemplate="%{x}<br>結束電量 %{y:.1f}%<extra></extra>"))
            fig.add_trace(go.Scatter(x=labels, y=[d["min_soc"] for d in days], mode="markers", name="當日最低電量", marker=dict(color="#bd9653", size=9, symbol="diamond"), hovertemplate="%{x}<br>最低電量 %{y:.1f}%<extra></extra>"))
            fig.add_hline(y=profile.reserve_soc, line_dash="dot", line_color="#b98562", annotation_text=f"備援 {profile.reserve_soc:g}%", annotation_position="top left")
            fig.update_layout(height=305, margin=dict(l=8,r=14,t=25,b=8), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", font=dict(family="Segoe UI, Microsoft JhengHei",color="#687761"), legend=dict(orientation="h", y=1.16, x=0), yaxis=dict(range=[0,105], ticksuffix="%", gridcolor="#e4e9df", zeroline=False), xaxis=dict(showgrid=False), hovermode="x unified")
            st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
        with detail_col:
            st.subheader("你的補電安排")
            st.markdown(f'<div class="daycard"><div class="daylabel">代表週總里程</div><div class="dayvalue">{n(week["total_km"])} <small>km</small></div><div class="quiet">家充計費電量 {n(week["home_grid_kwh"],1)} kWh<br>公共計費電量 {n(week["public_grid_kwh"],1)} kWh</div></div>', unsafe_allow_html=True)
            st.write("")
            st.markdown(f'<div class="note">家充利用停車時間，另列充電時長。公共充電需預留充電、繞路與等待時間。每次補電均受你設定的時窗限制。</div>', unsafe_allow_html=True)
        if week.get("warnings"):
            for warning in week["warnings"]:
                st.warning(warning)
        display_rows = []
        for d in days:
            events = d.get("events", [])
            event_text = "；".join(e if isinstance(e, str) else f"{e.get('reason', e.get('type', '補電'))} {n(e.get('minutes'), 0)} 分" for e in events)
            display_rows.append({"日期": d["day"], "預計里程 km": round(d["km"],1), "最低電量 %": round(d["min_soc"],1), "結束電量 %": round(d["end_soc"],1), "家充電量 kWh": round(d["home_kwh"],1), "公共電量 kWh": round(d["public_kwh"],1), "額外時間 分": round(d["extra_minutes"]), "未完成 km": round(d.get("unserved_km",0),1), "補電安排": event_text or "不需補電"})
        st.dataframe(pd.DataFrame(display_rows), hide_index=True, width="stretch")
        st.caption("表中充電量為計費端 kWh。未完成里程表示電量耗盡後仍無法完成的距離；另會檢查有無低於備援門檻，兩者都影響可行性。未整合路線、天候或即時充電樁。")
        with st.expander("查看計算規則與所有假設"):
            for assumption in result.get("assumptions", []):
                st.markdown("- " + assumption)

    with tabs[1]:
        st.subheader("先看能源，再談買車划不划算")
        st.caption("使用相同年里程與持有期間。費率可在左側修改；每月值為全年平均，不直接把出遊週乘上 52。")
        c = st.columns(3)
        c[0].metric("油車每月能源費", money(result["monthly_ice_energy"]))
        c[1].metric("電車每月充電費", money(result["monthly_ev_energy"]))
        c[2].metric("每年能源差額（正值為節省）", money(result["annual_energy_saving"]))
        tco = result["tco"]
        st.write("")
        st.subheader(f"{profile.years} 年持有成本")
        if tco.get("complete"):
            tc = st.columns(3)
            tc[0].metric("油車持有成本", money(tco["ice"]))
            tc[1].metric("電車持有成本", money(tco["ev"]))
            tc[2].metric("差額（正值為電車較省）", money(tco["difference"]))
        else:
            st.info("持有成本還缺資料，目前無法判定換車是否比較省錢。展開上方「補上購車與持有成本」後即可重算。")
            missing = tco.get("missing", [])
            names = dict(ownership_labels)
            names["feasible_charging_plan"] = "可完成行程的充電安排"
            st.write("待補：" + "、".join(names.get(str(v), str(v)) for v in missing))
        rows = tco.get("rows", [])
        if rows:
            cost_frame = pd.DataFrame(rows).rename(columns={"label": "成本項目", "ice": "油車（NT$）", "ev": "電車（NT$）"}).drop(columns=["key"], errors="ignore")
            st.dataframe(cost_frame, hide_index=True, width="stretch")
        st.markdown('<div class="note">成本範圍：折舊、能源、保養、保險、稅費、家充設備與額外停車費。殘值是估計；未計貸款利息與折現。官方建議售價不等於實際成交價。</div>', unsafe_allow_html=True)

    with tabs[2]:
        st.subheader("如果生活條件改變，結論也該跟著改變")
        st.caption("每個情境都以目前輸入為基礎，呼叫同一套計算引擎。此處比較能源與時間，不沿用未補齊的持有成本。")
        scenario_rows = []
        for alt in alternatives:
            ar = alt["result"]
            change_labels = {"home_charging": "家充", "trips_per_month": "每月出遊", "public_price": "公共電價", "consumption_kwh_100km": "電池端耗能"}
            def change_value(value):
                return {"unknown": "待確認", "yes": "可用", "no": "不可用"}.get(str(value), n(value, 2) if isinstance(value, (float, int)) else str(value))
            changed = "；".join(f"{change_labels.get(key, key)}：{change_value(val['from'])} → {change_value(val['to'])}" for key, val in alt["changed"].items())
            scenario_rows.append({"情境": alt["name"], "調整條件": changed, "每月能源費": money(ar["monthly_ev_energy"]), "每月節省": money(ar["monthly_energy_saving"]), "每週額外分鐘": n(ar["weekly_extra_minutes"]), "判斷": ar["decision"]["title"]})
        st.dataframe(pd.DataFrame(scenario_rows), hide_index=True, width="stretch")
        st.markdown("#### 直接切換示範，觀察整份報告的變化")
        a, b, c = st.columns(3)
        a.button("載入有家充家庭", key="demo_home", on_click=apply_preset, args=("home",), width="stretch")
        b.button("載入無家充家庭", key="demo_public", on_click=apply_preset, args=("public",), width="stretch")
        c.button("載入充電受限家庭", key="demo_challenge", on_click=apply_preset, args=("challenge",), width="stretch")
        st.caption("以上三個按鈕會載入完整示範參數；你自己的條件可在左側直接修改。")

    with tabs[3]:
        st.subheader("把不確定，變成下一次要確認的事")
        for idx, item in enumerate(decision.get("next_steps", []), 1):
            st.markdown(f"**{idx:02d}**　{item}")
        st.markdown("**試乘時，帶著這些問題：**")
        st.markdown("- 試走平日通勤路線，觀察實際耗能與停車動線。\n- 到預計使用的充電地點確認接口、費率、停車費與常見等待情況。\n- 帶家中車位條件與管委會規範，取得安裝可行性及書面報價。")
        source_path = BASE / "data" / "vehicle_sources.json"
        sources = json.loads(source_path.read_text(encoding="utf-8")) if source_path.exists() else {}
        report_profile = {**asdict(profile), "ownership": asdict(ownership)}
        md_report = build_markdown(report_profile, result, sources)
        html_report = build_html(report_profile, result, sources)
        actions = st.columns(3)
        actions[0].download_button("下載可列印報告", html_report, file_name="EV-FIT-生活適配報告.html", mime="text/html", width="stretch")
        actions[1].download_button("下載 Markdown", md_report, file_name="EV-FIT-生活適配報告.md", mime="text/markdown", width="stretch")
        if actions[2].button("儲存這次試算", width="stretch"):
            try:
                runtime = Path(os.environ.get("EV_FIT_RUNTIME_DIR", str(BASE / "runtime")))
                runtime.mkdir(parents=True, exist_ok=True)
                store = Store(runtime / "reports.sqlite3")
                try:
                    store.save_report(report_profile, result)
                finally:
                    store.close()
                st.success("已儲存至本機。未儲存文字描述，也未送出任何預約或聯絡資料。")
            except (OSError, ValueError) as exc:
                st.error(f"無法儲存：{exc}")
        st.caption("可列印報告：下載 HTML 後用瀏覽器開啟，再選列印／另存 PDF。")
        with st.expander("本機最近的試算"):
            runtime = Path(os.environ.get("EV_FIT_RUNTIME_DIR", str(BASE / "runtime")))
            db_path = runtime / "reports.sqlite3"
            history = []
            if db_path.exists():
                store = Store(db_path)
                try:
                    history = store.list_reports(5)
                finally:
                    store.close()
            if history:
                for item in history:
                    saved = item["result"]
                    st.write(f"{item['created_at']} · {saved['decision']['title']} · 每月能源差額 {money(saved['monthly_energy_saving'])}")
            else:
                st.caption("尚未儲存試算。")
        with st.expander("資料來源與適用範圍"):
            source_md = BASE / "SOURCES.md"
            if source_md.exists():
                st.markdown(source_md.read_text(encoding="utf-8"))
            else:
                st.info("來源資料正在建立中；所有試算參數暫依展示假設。")

    st.markdown('<div class="foot">EV FIT · 轉電之前　／　2026 和泰黑客松研究原型<br>確定性 Python 計算 · 無需 API 金鑰 · 試算由 Python 計算 · 問答助理位於另一分頁 · 無即時充電樁或正式預約串接<br>結果供情境比較；目前尚未完成真實車主訪談、道路校準或品牌合作驗證。</div>', unsafe_allow_html=True)


    st.session_state["_saved_profile"] = asdict(profile)
    st.session_state["_saved_ownership"] = asdict(ownership)
