"""Deterministic EV scenarios; no network calls or inferred vehicle specifications.

Distance and consumption refer to the battery side. Charger power and price
refer to the grid/billing side. Charging efficiency is applied exactly once.
"""

from dataclasses import dataclass, fields, replace
import math

EPS = 1e-8
WEEKS_PER_YEAR = 52
MAX_TRIPS_PER_MONTH = WEEKS_PER_YEAR / 12


def _number(name, value, minimum=0, maximum=None, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} 必須是有限數字。")
    if value < minimum or (positive and value <= 0) or (maximum is not None and value > maximum):
        raise ValueError(f"{name} 超出允許範圍。")


@dataclass(frozen=True)
class Profile:
    weekday_km: float = 40
    weekend_km: float = 200
    trips_per_month: float = 4
    home_charging: str = "unknown"
    home_hours: float = 8
    public_available: bool = True
    public_hours: float = 1.5
    detour_minutes: float = 15
    initial_soc: float = 80
    reserve_soc: float = 20
    battery_kwh: float = 65
    consumption_kwh_100km: float = 17
    charging_efficiency: float = 0.9
    home_power_kw: float = 6.6
    public_power_kw: float = 50
    home_price: float = 3
    public_price: float = 10
    fuel_km_l: float = 14
    fuel_price: float = 32
    public_parking_fee: float = 0
    years: int = 5

    def __post_init__(self):
        if self.home_charging not in ("yes", "no", "unknown"):
            raise ValueError("home_charging 必須是 yes、no 或 unknown。")
        if not isinstance(self.public_available, bool):
            raise ValueError("public_available 必須是布林值。")
        positive = {"battery_kwh", "consumption_kwh_100km", "charging_efficiency", "home_power_kw", "public_power_kw", "fuel_km_l"}
        limits = {"initial_soc": 100, "reserve_soc": 100, "charging_efficiency": 1, "trips_per_month": MAX_TRIPS_PER_MONTH, "home_hours": 24, "public_hours": 24, "years": 30}
        for field in fields(self):
            if field.name not in ("home_charging", "public_available"):
                _number(field.name, getattr(self, field.name), maximum=limits.get(field.name), positive=field.name in positive)
        if not isinstance(self.years, int) or self.years < 1:
            raise ValueError("years 必須是 1 至 30 的整數。")


@dataclass(frozen=True)
class Ownership:
    baseline: str = "keep"
    ice_value: float | None = None
    ice_resale: float | None = None
    ev_price: float | None = None
    ev_resale: float | None = None
    ice_maintenance_year: float | None = None
    ev_maintenance_year: float | None = None
    ice_insurance_year: float | None = None
    ev_insurance_year: float | None = None
    home_install: float | None = None
    ice_tax_year: float | None = None
    ev_tax_year: float | None = None
    extra_ev_parking_year: float | None = None

    def __post_init__(self):
        if self.baseline not in ("keep", "new"):
            raise ValueError("baseline 必須是 keep 或 new。")
        for field in fields(self):
            value = getattr(self, field.name)
            if field.name != "baseline" and value is not None:
                _number(field.name, value)


def simulate_week(profile: Profile) -> dict:
    """Simulate a trip week, or a no-trip week when trips_per_month is zero.

    Each day provides at most one public session, including Sunday restoration.
    A public stop occurs at the reserve threshold (or immediately if already
    below it). Overnight home charging targets initial SOC. Any insufficient
    battery becomes explicit unserved kilometres, never negative SOC.
    """
    p = profile
    capacity = p.battery_kwh
    energy = capacity * p.initial_soc / 100
    target = energy
    reserve = capacity * p.reserve_soc / 100
    per_km = p.consumption_kwh_100km / 100
    warnings = []
    if p.home_charging == "unknown":
        warnings.append("家充條件尚未確認，本次保守按無家充計算。")
    day_names = ["週一", "週二", "週三", "週四", "週五", "週六", "週日"]
    distances = [p.weekday_km] * 5 + [p.weekend_km if p.trips_per_month > 0 else 0, 0]
    days = []
    consumed = 0.0
    min_energy = energy

    for index, km in enumerate(distances):
        day = {"day": day_names[index], "km": km, "start_soc": energy / capacity * 100,
               "end_soc": 0.0, "min_soc": energy / capacity * 100,
               "home_kwh": 0.0, "public_kwh": 0.0, "charge_minutes": 0.0,
               "extra_minutes": 0.0, "events": [], "unserved_km": 0.0}
        day_min = energy
        public_used = False

        def charge(kind, desired_energy, reason):
            nonlocal energy, public_used
            available = p.home_charging == "yes" if kind == "home" else p.public_available and not public_used
            hours_left = p.home_hours if kind == "home" else p.public_hours
            if not available or hours_left <= 0 or desired_energy <= energy + EPS:
                return
            start = energy
            minutes = 0.0
            desired_energy = min(capacity, desired_energy)
            while energy < desired_energy - EPS and hours_left > EPS:
                if kind == "home":
                    power, boundary = p.home_power_kw, desired_energy
                elif energy < capacity * 0.8 - EPS:
                    power, boundary = p.public_power_kw, min(desired_energy, capacity * 0.8)
                else:
                    power, boundary = min(p.public_power_kw, 20), desired_energy
                battery_added = min(boundary - energy, power * p.charging_efficiency * hours_left)
                elapsed = battery_added / (power * p.charging_efficiency)
                energy += battery_added
                hours_left -= elapsed
                minutes += elapsed * 60
            added = energy - start
            if added <= EPS:
                return
            grid = added / p.charging_efficiency
            extra = minutes + p.detour_minutes if kind == "public" else 0.0
            day[f"{kind}_kwh"] += grid
            day["charge_minutes"] += minutes
            day["extra_minutes"] += extra
            day["events"].append({"type": kind, "reason": reason, "start_soc": start / capacity * 100,
                                  "end_soc": energy / capacity * 100, "battery_kwh": added,
                                  "grid_kwh": grid, "minutes": minutes, "extra_minutes": extra})
            if kind == "public":
                public_used = True

        def drive(required):
            nonlocal energy, consumed, day_min, min_energy
            used = min(energy, required)
            energy = max(0.0, energy - used)
            consumed += used
            day_min = min(day_min, energy)
            min_energy = min(min_energy, energy)
            return required - used

        required = km * per_km
        if required > EPS and energy - required < reserve - EPS:
            # Reach the planned public stop before consuming the reserve.
            before_stop = min(required, max(0.0, energy - reserve))
            drive(before_stop)
            remaining = required - before_stop
            charge("public", max(target, remaining + reserve), "途中補電")
            unmet = drive(remaining)
        else:
            unmet = drive(required)
        day["unserved_km"] = unmet / per_km
        if day_min < reserve - EPS:
            warnings.append(f"{day_names[index]}電量低於設定的 {p.reserve_soc:g}% 備援門檻。")
        if unmet > EPS:
            warnings.append(f"{day_names[index]}仍有 {unmet / per_km:.1f} 公里無法完成；需增加充電機會或調整行程。")
        charge("home", target, "晚間家充")
        if index == 6:
            charge("public", target, "週末補回起始電量")
        day["end_soc"] = energy / capacity * 100
        day["min_soc"] = day_min / capacity * 100
        days.append(day)

    sustainable = energy >= target - EPS
    if not sustainable:
        warnings.append("本週結束無法補回起始電量，連續使用此行程不可持續。")
    home_grid = sum(day["home_kwh"] for day in days)
    public_grid = sum(day["public_kwh"] for day in days)
    sessions = sum(event["type"] == "public" for day in days for event in day["events"])
    unserved = sum(day["unserved_km"] for day in days)
    return {"days": days, "total_km": sum(distances), "served_km": sum(distances) - unserved,
            "unserved_km": unserved, "battery_kwh_used": consumed,
            "grid_kwh": home_grid + public_grid, "home_grid_kwh": home_grid,
            "public_grid_kwh": public_grid, "charge_minutes": sum(day["charge_minutes"] for day in days),
            "extra_minutes": sum(day["extra_minutes"] for day in days), "public_sessions": sessions,
            "min_soc": min_energy / capacity * 100, "ending_soc": energy / capacity * 100,
            "sustainable": sustainable, "feasible": sustainable and unserved < EPS and min_energy >= reserve - EPS,
            "electricity_cost": home_grid * p.home_price + public_grid * p.public_price,
            "charging_parking_cost": sessions * p.public_parking_fee, "warnings": warnings}


def _annual(profile):
    trip = simulate_week(profile)
    regular = simulate_week(replace(profile, weekend_km=0, trips_per_month=0))
    weight = profile.trips_per_month * 12 / WEEKS_PER_YEAR
    feasible = (weight >= 1 - EPS or regular["feasible"]) and (weight <= EPS or trip["feasible"])

    def weighted(key):
        return WEEKS_PER_YEAR * ((1 - weight) * regular[key] + weight * trip[key])

    ice = weighted("total_km") / profile.fuel_km_l * profile.fuel_price
    ev = weighted("electricity_cost") if feasible else None
    return {"week": trip, "regular_week": regular, "trip_week_weight": weight, "feasible": feasible,
            "annual_km": weighted("total_km"), "annual_ice_energy": ice, "annual_ev_energy": ev,
            "annual_energy_saving": ice - ev if ev is not None else None,
            "annual_charging_parking": weighted("charging_parking_cost") if feasible else None,
            "weekly_extra_minutes": weighted("extra_minutes") / WEEKS_PER_YEAR}


def _tco(profile, ownership, annual):
    o = ownership or Ownership()
    missing = [field.name for field in fields(o) if field.name != "baseline" and getattr(o, field.name) is None]
    if not annual["feasible"]:
        missing.append("feasible_charging_plan")
    y = profile.years

    def times(value):
        return None if value is None else value * y

    def depreciation(price, resale):
        return None if price is None or resale is None else price - resale

    rows = [
        {"key": "depreciation", "label": "折舊／機會成本", "ice": depreciation(o.ice_value, o.ice_resale), "ev": depreciation(o.ev_price, o.ev_resale)},
        {"key": "energy", "label": "能源費", "ice": times(annual["annual_ice_energy"]), "ev": times(annual["annual_ev_energy"])},
        {"key": "maintenance", "label": "保養", "ice": times(o.ice_maintenance_year), "ev": times(o.ev_maintenance_year)},
        {"key": "insurance", "label": "保險", "ice": times(o.ice_insurance_year), "ev": times(o.ev_insurance_year)},
        {"key": "tax", "label": "稅費", "ice": times(o.ice_tax_year), "ev": times(o.ev_tax_year)},
        {"key": "home_install", "label": "家充設備與安裝", "ice": 0, "ev": o.home_install},
        {"key": "charging_parking", "label": "公共充電停車／服務費", "ice": 0, "ev": times(annual["annual_charging_parking"])},
        {"key": "extra_parking", "label": "電車額外停車費", "ice": 0, "ev": times(o.extra_ev_parking_year)},
    ]
    complete = not missing
    ice = sum(row["ice"] for row in rows) if complete else None
    ev = sum(row["ev"] for row in rows) if complete else None
    return {"complete": complete, "missing": missing, "ice": ice, "ev": ev,
            "difference": ice - ev if complete else None, "rows": rows,
            "baseline": o.baseline, "years": y}


def summarize(profile: Profile, ownership: Ownership | None = None) -> dict:
    annual = _annual(profile)
    stress_profile = replace(profile, consumption_kwh_100km=profile.consumption_kwh_100km * 1.25)
    stress = _annual(stress_profile)
    if not annual["feasible"]:
        status, title = "difficult", "目前條件下，先調整充電安排"
        reasons = ["目前行程低於備援門檻、存在未完成里程，或無法在週末補回起始電量。"]
        next_steps = ["確認每週可用的公共充電時段與站點，再重新模擬。", "試算更短的行程、較長的充電時窗或可用家充。"]
    elif profile.home_charging == "unknown":
        status, title = "confirm", "先確認家充條件，再做換車決定"
        reasons = ["依賴公共充電可以完成此假設行程，但尚未確認能否安裝家充。"]
        next_steps = ["向管委會與合格安裝商確認車位、供電及施工條件。", "實際走訪常用公共站點，確認營業時段、費率及排隊情況。"]
    elif not stress["feasible"]:
        status, title = "confirm", "一般耗能可行，較高耗能時需備案"
        reasons = ["基準行程可完成；耗能提高 25% 後無法維持相同備援與補電要求。"]
        next_steps = ["試乘時確認高速、冷氣與載重下的實際耗能。", "為長途行程準備額外可用的充電站與時段。"]
    else:
        status, title = "ready", "此假設行程具備油轉電可行性"
        reasons = ["基準與耗能提高 25% 的情境，均可完成行程並補回起始電量。"]
        next_steps = ["試乘並記錄相似行程的實際耗能。", "核對車價、保險與殘值，再比較完整持有成本。"]
    annual.update({
        "monthly_ice_energy": annual["annual_ice_energy"] / 12,
        "monthly_ev_energy": None if annual["annual_ev_energy"] is None else annual["annual_ev_energy"] / 12,
        "monthly_energy_saving": None if annual["annual_energy_saving"] is None else annual["annual_energy_saving"] / 12,
        "tco": _tco(profile, ownership, annual),
        "decision": {"status": status, "title": title, "reasons": reasons, "next_steps": next_steps},
        "stress_test": {**stress, "consumption_kwh_100km": stress_profile.consumption_kwh_100km},
        "assumptions": [
            f"可用電池 {profile.battery_kwh:g} kWh、電池端耗能 {profile.consumption_kwh_100km:g} kWh/100 km 均為可修改的展示假設，不是官方可用容量或道路耗能保證。",
            "平日每日里程視為當天總里程；週末單趟里程視為整段行程總里程，集中在週六；每週最多一趟。",
            "一週圖顯示有出遊週；每月出遊為 0 時顯示無出遊週。年成本以 52 週、260 個通勤日和每月出遊次數加權。",
            "每天最多一次公共充電機會，充電分鐘加固定繞行分鐘算額外時間；未模擬排隊、站點位置與即時故障。",
            "家充在每日行程後補至起始電量；週日再以公共充電補回起始電量，所有補電、時間與費用均計入。",
            "功率與電價均以計費端計算，入電池電量乘一次充電效率；公共充電 80% 以上功率取設定值與 20 kW 的較低者。",
            "較高耗能情境固定提高 25%，是壓力測試假設，不是經資料校準的預測區間。",
            "能源費僅計油費與電費；公共充電停車／服務費另列於總持有成本。",
            "總持有成本未折現、不含融資利息；保留油車使用目前可售價扣未來殘值，新油車則使用新購價扣未來殘值。",
        ],
    })
    return annual


def compare_scenarios(profile: Profile) -> list[dict]:
    extra_trip_frequency = min(MAX_TRIPS_PER_MONTH, profile.trips_per_month + 2)
    alternatives = [
        ("確認可以家充" if profile.home_charging != "yes" else "無法安裝家充", "home_charging", "yes" if profile.home_charging != "yes" else "no"),
        (f"每月出遊改為 {extra_trip_frequency:.2f} 趟（每週最多一趟）", "trips_per_month", extra_trip_frequency),
        ("公共電價提高 25%", "public_price", profile.public_price * 1.25),
        ("耗能提高 25%", "consumption_kwh_100km", profile.consumption_kwh_100km * 1.25),
    ]
    return [{"name": name, "changed": {field: {"from": getattr(profile, field), "to": value}},
             "result": summarize(replace(profile, **{field: value}))} for name, field, value in alternatives]
