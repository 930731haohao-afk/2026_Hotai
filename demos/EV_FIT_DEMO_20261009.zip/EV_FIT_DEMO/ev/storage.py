"""Local SQLite storage for structured, explicitly saved estimates."""

from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import threading
import uuid


_PRIVATE_KEYS = {
    "name", "full_name", "user_name", "username", "email", "phone", "address",
    "home_address", "work_address", "description", "raw_description", "raw_text",
    "text", "intake_text", "prompt", "user_id", "plate", "license_plate",
}
_PROFILE_KEYS = {
    "weekday_km", "weekend_km", "trips_per_month", "home_charging", "home_hours",
    "public_available", "public_hours", "detour_minutes", "initial_soc", "reserve_soc",
    "battery_kwh", "consumption_kwh_100km", "charging_efficiency", "home_power_kw",
    "public_power_kw", "home_price", "public_price", "fuel_km_l", "fuel_price",
    "public_parking_fee", "years", "ownership", "vehicle_id",
}
_OWNERSHIP_KEYS = {
    "baseline", "ice_value", "ice_resale", "ev_price", "ev_resale",
    "ice_maintenance_year", "ev_maintenance_year", "ice_insurance_year",
    "ev_insurance_year", "home_install", "ice_tax_year", "ev_tax_year", "extra_ev_parking_year",
}


def _safe_profile(profile):
    clean = {key: value for key, value in profile.items() if key in _PROFILE_KEYS}
    if "ownership" in clean:
        ownership = clean["ownership"]
        if not isinstance(ownership, dict):
            raise TypeError("ownership must be a dictionary")
        clean["ownership"] = {key: value for key, value in ownership.items() if key in _OWNERSHIP_KEYS}
    return _structured_only(clean)


def _structured_only(value):
    if isinstance(value, dict):
        return {
            str(key): _structured_only(item)
            for key, item in value.items()
            if str(key).lower() not in _PRIVATE_KEYS
        }
    if isinstance(value, list):
        return [_structured_only(item) for item in value]
    return value


class Store:
    """One local app database; this is not an authenticated multi-user service."""

    def __init__(self, path):
        self.path = str(path)
        self._lock = threading.RLock()
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        # A persistent connection also gives ':memory:' sensible semantics.
        self._connection = sqlite3.connect(self.path, check_same_thread=False)
        self._connection.execute(
            "CREATE TABLE IF NOT EXISTS reports ("
            "id TEXT PRIMARY KEY, created_at TEXT NOT NULL, "
            "profile_json TEXT NOT NULL, result_json TEXT NOT NULL)"
        )
        self._connection.commit()

    def save_report(self, profile: dict, result: dict) -> str:
        if not isinstance(profile, dict) or not isinstance(result, dict):
            raise TypeError("profile and result must be dictionaries")
        profile_json = json.dumps(_safe_profile(profile), ensure_ascii=False, allow_nan=False)
        result_json = json.dumps(_structured_only(result), ensure_ascii=False, allow_nan=False)
        report_id = uuid.uuid4().hex
        created_at = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        with self._lock, self._connection:
            self._connection.execute(
                "INSERT INTO reports (id, created_at, profile_json, result_json) VALUES (?, ?, ?, ?)",
                (report_id, created_at, profile_json, result_json),
            )
        return report_id

    def list_reports(self, limit=5) -> list:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer between 1 and 100")
        with self._lock:
            rows = self._connection.execute(
                "SELECT id, created_at, profile_json, result_json FROM reports "
                "ORDER BY created_at DESC, rowid DESC LIMIT ?", (limit,)
            ).fetchall()
        return [
            {"id": row[0], "created_at": row[1], "profile": json.loads(row[2]), "result": json.loads(row[3])}
            for row in rows
        ]

    def close(self):
        with self._lock:
            self._connection.close()
