"""Trusted interactive cards beside answers; widget changes never call an LLM."""
from __future__ import annotations

import html
import json
from pathlib import Path

import plotly.graph_objects as go
import streamlit as st

from ev.explore import card_kind, charging_preview, loan_example, micro_energy

BASE = Path(__file__).resolve().parents[1]


def _specs():
    return json.loads((BASE / "data" / "interaction_cards.json").read_text(encoding="utf-8"))["cards"]


def _state(turn_id):
    return st.session_state.setdefault("_explore_state", {}).setdefault(turn_id, {})


def _key(turn_id, name, default):
    key = f"explore_{turn_id}_{name}"
    if key not in st.session_state:
        st.session_state[key] = _state(turn_id).get(name, default)
    return key


def _slider(turn_id, name, label, low, high, default, step):
    value = st.slider(label, min_value=low, max_value=high, step=step, key=_key(turn_id, name, default),
                      on_change=_remember, args=(turn_id, name))
    _state(turn_id)[name] = value
    return value


def _remember(turn_id, name):
    _state(turn_id)[name] = st.session_state[f"explore_{turn_id}_{name}"]


def _chart(fig, turn_id, name, height=210):
    fig.update_layout(height=height, margin=dict(l=8, r=12, t=16, b=8),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family="Segoe UI, Microsoft JhengHei", color="#4a604c"),
                      legend=dict(orientation="h", y=1.23), bargap=.48)
    fig.update_xaxes(gridcolor="#e5ebe0", zeroline=False)
    fig.update_yaxes(gridcolor="#e5ebe0", zeroline=False)
    st.plotly_chart(fig, key=f"explore_{turn_id}_{name}_chart", width="stretch", config={"displayModeBar": False})


def _handoff_charging(turn_id, on_simulation):
    # Read the event's current widget state, not a previous-render snapshot.
    km = st.session_state.get(f"explore_{turn_id}_weekday_km", _state(turn_id).get("weekday_km", 40))
    home = st.session_state.get(f"explore_{turn_id}_home_choice", _state(turn_id).get("home_choice", "unknown"))
    _state(turn_id).update(weekday_km=km, home_choice=home)
    fields = {"weekday_km": float(km), "weekend_km": 0.0, "trips_per_month": 0.0, "home_charging": home}
    on_simulation(fields, "帶入本卡的通勤里程、家充條件與週末 0 公里。其他充電與成本設定請在完整試算中確認。")


def _charging(turn_id, spec, on_simulation):
    choices = {o["id"]: o for o in spec["options"]}
    home = st.radio("目前的家充條件", list(choices), format_func=lambda v: choices[v]["label"],
                    horizontal=True, key=_key(turn_id, "home_choice", "unknown"), on_change=_remember, args=(turn_id, "home_choice"))
    _state(turn_id)["home_choice"] = home
    st.caption(choices[home]["note"])
    km = _slider(turn_id, "weekday_km", "平日每天往返（km）", 0, 200, 40, 5)
    preview = charging_preview(km, home)
    week = preview["week"]
    cols = st.columns(3)
    cols[0].metric("這週里程", f"{week['total_km']:,.0f} km")
    cols[1].metric("公共充電", f"{week['public_sessions']} 次")
    cols[2].metric("公共充電額外時間", f"{week['extra_minutes']:,.0f} 分")
    fig = go.Figure(go.Scatter(x=[d["day"] for d in week["days"]], y=[d["end_soc"] for d in week["days"]],
                               mode="lines+markers", name="每日結束電量", line=dict(color="#518252", width=3),
                               marker=dict(size=7), fill="tozeroy", fillcolor="rgba(107,152,87,.12)",
                               hovertemplate="%{x} · 結束電量 %{y:.1f}%<extra></extra>"))
    fig.add_hline(y=20, line_dash="dot", line_color="#b18b4d", annotation_text="備援 20%")
    fig.update_yaxes(range=[0, 105], ticksuffix="%")
    _chart(fig, turn_id, "charging")
    if not week["feasible"]:
        st.warning("目前的示範充電安排無法維持備援或補回週初電量；請增加可用充電時間再評估。")
    elif home == "unknown":
        st.info("先依無家充估算。確認能裝家充後，點選上方選項就能直接比較。")
    else:
        st.caption("圖中已把週末補回起始電量算進去；家充利用停車時間，仍然需要實際充電。")
    with st.expander("這張卡用到的假設"):
        st.caption("只模擬每週五天通勤，週末里程為 0。可用電池 65 kWh、電池端耗能 17 kWh/100km、效率90%、週初80%、備援20%均為示範假設。家充7 kW、每晚8小時；公共有效功率50 kW、每天最多1次且每次1.5小時，繞路與等待15分鐘。非即時站點或路線規劃。")
    st.button("把這組通勤條件帶入完整試算 →", key=f"explore_{turn_id}_handoff", on_click=_handoff_charging,
              args=(turn_id, on_simulation), width="stretch")


def _energy(turn_id, on_simulation):
    cols = st.columns(2)
    with cols[0]:
        km = _slider(turn_id, "monthly_km", "每月里程（km）", 0, 5000, 1500, 100)
    with cols[1]:
        share = _slider(turn_id, "home_share", "在家充電的電量占比（%）", 0, 100, 80, 10)
    value = micro_energy(km, share)
    fig = go.Figure()
    for name, amounts, color in [("汽油", [value["ice_cost"], 0], "#9aa798"),
                                  ("家充", [0, value["home_cost"]], "#5e8d55"),
                                  ("公共充電", [0, value["public_cost"]], "#b4c985")]:
        fig.add_trace(go.Bar(y=["油車", "電車"], x=amounts, orientation="h", name=name, marker_color=color,
                             hovertemplate="%{y} · NT$ %{x:,.0f}<extra>%{fullData.name}</extra>"))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(title_text="每月費用（NT$）", tickformat=",.0f", nticks=4)
    _chart(fig, turn_id, "energy")
    cols = st.columns(3)
    cols[0].metric("每月油費", f"NT$ {value['ice_cost']:,.0f}")
    cols[1].metric("每月電費", f"NT$ {value['ev_cost']:,.0f}")
    cols[2].metric("能源可省" if value["saving"] >= 0 else "能源增加", f"NT$ {abs(value['saving']):,.0f}")
    st.markdown('<div class="explore-note"><b>這只是能源差額。</b>購車折舊、保險、保養、稅費、充電設備與停車服務費，還需要另外比較。</div>', unsafe_allow_html=True)
    with st.expander("計算假設與邊界"):
        for note in value["assumptions"]:
            st.caption(note)
        st.caption("家充占比是數學情境，不代表已確認可以家充。里程與充電分配均為卡片示範值，不會自動當成你的實際生活。")
    st.button("把完整持有成本一起看 →", key=f"explore_{turn_id}_handoff", on_click=on_simulation,
              args=({}, "此卡是月平均能源情境；完整試算請確認實際一週里程與充電條件，再補購車與持有成本。"), width="stretch")


def _vehicles(turn_id, spec):
    options = {o["id"]: o for o in spec["options"]}
    selected = st.multiselect("選想比較的車型", list(options), format_func=lambda v: options[v]["label"],
                             key=_key(turn_id, "vehicle_types", ["ICE", "BEV"]), on_change=_remember, args=(turn_id, "vehicle_types"))
    _state(turn_id)["vehicle_types"] = selected
    if not selected:
        st.info("至少選一種車型，就能看到它的補能方式與生活差異。")
        return
    for start in range(0, len(selected), 2):
        cols = st.columns(2)
        for col, vehicle_id in zip(cols, selected[start:start + 2]):
            item = options[vehicle_id]
            with col:
                st.markdown('<div class="vehicle-tile"><div class="vehicle-id">' + html.escape(vehicle_id) + '</div><h4>' + html.escape(item["label"]) + '</h4><p><b>能量來源</b><br>' + html.escape(item["energy"]) + '</p><p><b>需要插電嗎？</b><br>' + html.escape(item["plug"]) + '</p><p><b>保養觀念</b><br>' + html.escape(item["maintenance"]) + '</p><div class="quiet">' + html.escape(item["note"]) + '</div></div>', unsafe_allow_html=True)
    st.caption("這裡比較動力類型；實際車型規格、價格與保固仍需核對適用市場與版本。")


def _loan(turn_id):
    cols = st.columns(2)
    with cols[0]:
        principal = _slider(turn_id, "principal", "示範貸款本金（NT$）", 100000, 1500000, 600000, 50000)
    with cols[1]:
        rate = _slider(turn_id, "interest", "固定名目年利率（%）", 0.0, 12.0, 3.0, 0.5)
    term = _slider(turn_id, "months", "想比較的還款期數（月）", 12, 84, 60, 12)
    fixed = loan_example(principal, rate, 36)
    selected = loan_example(principal, rate, term)
    labels = ["基準 36 個月", f"目前 {term} 個月"]
    values = [fixed, selected]
    fig = go.Figure(go.Bar(x=labels, y=[v["total_interest"] for v in values], marker_color=["#9ca998", "#5e8d55"],
                           text=[f"NT$ {v['total_interest']:,.0f}" for v in values], textposition="outside",
                           hovertemplate="%{x}<br>總利息 NT$ %{y:,.0f}<extra></extra>"))
    fig.update_yaxes(title_text="總利息（NT$）", range=[0, max(1000, max(v["total_interest"] for v in values) * 1.3)])
    _chart(fig, turn_id, "loan", 225)
    cols = st.columns(2)
    for col, name, value in zip(cols, labels, values):
        with col:
            st.metric(name + " · 每月還款", f"NT$ {value['monthly_payment']:,.0f}")
            st.caption(f"總還款 NT$ {value['total_payment']:,.0f}（本金＋利息）")
    st.caption("同本金、同利率的數學情境：每月底本息平均攤還、無頭期或尾款差異、無手續費、無提前還款。名目年利率不是含費用的 APR；不是銀行報價或借貸建議。")
    st.caption("公式：月付＝本金×月利率÷[1−(1＋月利率)的負期數次方]；零利率時為本金÷期數。實際契約的計息與費用要另外確認。")


def _battery(turn_id):
    soc = _slider(turn_id, "soc", "目前電量 SOC（%）", 0, 100, 80, 5)
    consumption = _slider(turn_id, "consumption", "假設電池端耗能（kWh/100km）", 10.0, 30.0, 17.0, 0.5)
    available = max(0, soc - 20) * 65 / 100
    st.progress(soc / 100, text=f"目前 {soc}% · 保留 20% 備援")
    cols = st.columns(2)
    cols[0].metric("扣掉備援後的假設可用電量", f"{available:.1f} kWh")
    cols[1].metric("依耗能換算的情境距離", f"{available / consumption * 100:.0f} km")
    if soc < 20:
        st.warning("目前電量已低於這張卡的備援設定；請先安排補電。")
    st.caption("固定採可用容量 65 kWh 的展示假設，不是官方公布的可用容量。此卡只示範 SOC、備援與耗能的關係，沒有預測實際道路續航或推薦特定路線。")


def render_interaction(result, turn_id, on_question, on_simulation):
    """Render a server-defined card chosen from trusted knowledge IDs."""
    specs = _specs()
    kind = card_kind(result)
    spec = specs[kind]
    with st.container(border=True, key=f"explore_{turn_id}_card"):
        st.markdown('<div class="explore-kicker">' + html.escape(spec["kicker"]) + '</div>', unsafe_allow_html=True)
        st.markdown("#### " + spec["title"])
        st.caption(spec["description"])
        if kind == "charging":
            _charging(turn_id, spec, on_simulation)
        elif kind == "energy":
            _energy(turn_id, on_simulation)
        elif kind == "vehicles":
            _vehicles(turn_id, spec)
        elif kind == "loan":
            _loan(turn_id)
        elif kind == "battery":
            _battery(turn_id)
        else:
            if result.get("mode") == "no_evidence":
                st.info("目前還缺少足夠證據。先選一個方向，縮小問題範圍。")
            else:
                st.info("這個主題先以來源支持的文字說明為主；可展開閱讀，再選下一個想了解的方向。")
        questions = spec.get("choices", spec.get("related_questions", [])) if kind == "next_steps" else spec.get("related_questions", [])
        if questions:
            st.caption("接下來想了解什麼？點選後會送出下一個問題。")
            cols = st.columns(min(2, len(questions)))
            for index, item in enumerate(questions):
                cols[index % len(cols)].button(item["label"], key=f"explore_{turn_id}_ask_{index}",
                                              on_click=on_question, args=(item["question"],), width="stretch")
        st.caption("拖曳／選擇即時更新；卡片由固定程式計算，不會額外呼叫 LLM。示範值與正式試算分開，帶入前會先請你確認。")
