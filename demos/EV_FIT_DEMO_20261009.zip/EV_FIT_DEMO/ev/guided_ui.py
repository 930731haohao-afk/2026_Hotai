"""Three-choice lifestyle wizard; commits only explicit choices to session state."""
from __future__ import annotations

import html
from collections.abc import Callable

import plotly.graph_objects as go
import streamlit as st

from ev.engine import Profile, summarize
from ev.guided import CHARGING_OPTIONS, DISTANCE_OPTIONS, TRIP_OPTIONS, build_guided_profile


_GROUPS = (
    ("weekday_km",),
    ("home_charging", "public_available"),
    ("weekend_km", "trips_per_month"),
)
_ANSWER_KEYS = ("distance", "charging", "trips")
_STEP_NAMES = ("每日里程", "充電條件", "週末出遊")
_CUSTOM_WIDGETS = {
    "guided_custom_distance_km": "_guided_custom_distance_km",
    "guided_custom_weekend_km": "_guided_custom_weekend_km",
    "guided_custom_trips_per_month": "_guided_custom_trips_per_month",
}
_STYLE = """<style>
.st-key-guided_question {background:#faf9f3;border:1px solid #e0e5d9;
 border-radius:20px;padding:24px!important;margin-top:18px;}
.st-key-guided_question button {min-height:48px;}
.guided-intro {color:#758174;font-size:13px;line-height:1.8;margin-bottom:16px;}
.guided-status {background:#edf2e6;border:1px solid #d7e2ce;border-radius:14px;
 padding:20px 22px;margin:16px 0;}
.guided-status.pending {background:#fbf4e5;border-color:#e8d5ac;}
.guided-status.difficult {background:#f7eee8;border-color:#e6c9ba;}
.guided-status strong {display:block;color:#294b37;font-size:19px;margin:6px 0;}
.guided-status span {font-size:12px;color:#697861;}
.guided-status p {margin:6px 0 0;font-size:14px;}
.st-key-guided_steps [data-testid="stHorizontalBlock"]{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;}
.st-key-guided_steps [data-testid="stColumn"]{width:100%!important;min-width:0!important;}
.st-key-guided_steps button{font-size:12px;white-space:nowrap;padding:8px 5px;}
@media(max-width:650px){.st-key-guided_question{padding:16px!important;}
 .guided-status{padding:16px;} .guided-status strong{font-size:17px;}}
</style>"""


def _cache_custom(widget_key: str) -> None:
    st.session_state[_CUSTOM_WIDGETS[widget_key]] = st.session_state[widget_key]


def _custom_value(widget_key: str, default: float) -> None:
    """Keep a non-widget copy through Streamlit's page/widget cleanup."""
    cache_key = _CUSTOM_WIDGETS[widget_key]
    st.session_state.setdefault(cache_key, float(default))
    if widget_key not in st.session_state:
        st.session_state[widget_key] = float(st.session_state[cache_key])


def _navigate(stage: int) -> None:
    if st.session_state.get("_guided_step") == 3:
        st.session_state["_guided_edit_stage"] = stage
        answers = st.session_state.get("_guided_answers", {})
        if answers.get(_ANSWER_KEYS[stage]) == "custom":
            values = ({"guided_custom_distance_km": answers["distance_km"]} if stage == 0 else
                      {"guided_custom_weekend_km": answers["weekend_km"],
                       "guided_custom_trips_per_month": answers["trips_per_month"]})
            for widget_key, value in values.items():
                st.session_state[_CUSTOM_WIDGETS[widget_key]] = float(value)
                st.session_state[widget_key] = float(value)
    elif st.session_state.get("_guided_edit_stage") is not None:
        st.session_state["_guided_edit_stage"] = stage
    st.session_state["_guided_step"] = stage
    st.session_state.pop("_guided_custom_open", None)
    st.session_state.pop("_guided_error", None)


def _open_custom(stage: int) -> None:
    st.session_state["_guided_custom_open"] = stage
    st.session_state.pop("_guided_error", None)


def _pending_for(answers: dict, profile: Profile) -> list[str]:
    pending = []
    if answers.get("distance") == "unknown":
        pending.append(f"平日實際往返里程尚未確認；暫用每天 {profile.weekday_km:g} 公里呈現情境。")
    if answers.get("trips") == "unknown":
        pending.append("週末出遊次數與里程尚未確認；" + (
            "本次未計入額外週末行程，不能據此判定長途也適合。" if profile.trips_per_month == 0 else
            f"暫用每月 {profile.trips_per_month:g} 趟、每趟 {profile.weekend_km:g} 公里呈現情境。"))
    if profile.home_charging == "unknown":
        pending.append("家充能否安裝及使用尚未確認；有車位不等於可以家充。")
        pending.append("公共充電可用性也尚未確認；" + (
            "本次只是暫設有公共充電可用的情境，需核對站點、時段與費率。" if profile.public_available else
            "本次未設為可用，不會自動加入公共充電機會。"))
    return pending


def _commit() -> None:
    saved = st.session_state.get("_saved_profile")
    try:
        built = build_guided_profile(st.session_state["_guided_answers"], base=saved)
        candidate = dict(built["profile"])
        edit_stage = st.session_state.get("_guided_edit_stage")
        if saved and edit_stage in (0, 1, 2):
            committed = dict(saved)
            for field in _GROUPS[edit_stage]:
                committed[field] = candidate[field]
        else:
            committed = candidate
        Profile(**committed)
    except (TypeError, ValueError, KeyError) as exc:
        st.session_state["_guided_error"] = f"條件尚未完整，請確認後再試：{exc}"
        return
    st.session_state["_saved_profile"] = committed
    for field, value in committed.items():
        st.session_state["p_" + field] = value
    st.session_state["_guided_pending"] = _pending_for(st.session_state["_guided_answers"], Profile(**committed))
    # The results view renders assumptions from the committed Profile itself.
    st.session_state["_guided_assumptions"] = summarize(Profile(**committed))["assumptions"]
    st.session_state["_guided_step"] = 3
    st.session_state["scenario_name"] = "三步生活情境"
    st.session_state.pop("_guided_edit_stage", None)
    st.session_state.pop("_guided_custom_open", None)
    st.session_state.pop("_guided_error", None)


def _choose(stage: int, option_id: str) -> None:
    answers = dict(st.session_state["_guided_answers"])
    answers[_ANSWER_KEYS[stage]] = option_id
    if stage == 0 and option_id in DISTANCE_OPTIONS:
        value = float(DISTANCE_OPTIONS[option_id]["km"])
        st.session_state["_guided_custom_distance_km"] = value
        st.session_state["guided_custom_distance_km"] = value
    if stage == 2 and option_id in TRIP_OPTIONS:
        for field in ("weekend_km", "trips_per_month"):
            widget_key = "guided_custom_" + field
            value = float(TRIP_OPTIONS[option_id][field])
            st.session_state[_CUSTOM_WIDGETS[widget_key]] = value
            st.session_state[widget_key] = value
    if option_id == "custom" and stage == 0:
        value = st.session_state.get("guided_custom_distance_km", st.session_state.get("_guided_custom_distance_km", 40))
        answers["distance_km"] = float(value)
        st.session_state["_guided_custom_distance_km"] = float(value)
    if option_id == "custom" and stage == 2:
        for field, fallback in (("weekend_km", 200), ("trips_per_month", 1)):
            widget_key = "guided_custom_" + field
            cache_key = "_" + widget_key
            value = st.session_state.get(widget_key, st.session_state.get(cache_key, fallback))
            answers[field] = float(value)
            st.session_state[cache_key] = float(value)
    st.session_state["_guided_answers"] = answers
    st.session_state.pop("_guided_custom_open", None)
    if stage == 2 or st.session_state.get("_guided_edit_stage") is not None:
        _commit()
    else:
        st.session_state["_guided_step"] = stage + 1


def _reuse_saved() -> None:
    """Hydrate editable answers without replacing an existing precise profile."""
    saved = st.session_state.get("_saved_profile", {})
    try:
        p = Profile(**saved)
    except (TypeError, ValueError) as exc:
        st.session_state["_guided_error"] = f"上次條件需要在進階設定確認：{exc}"
        return
    charging = "home" if p.home_charging == "yes" else (
        "unknown" if p.home_charging == "unknown" else (
            "public" if p.public_available else "unavailable"
        )
    )
    answers = {"distance": "custom", "distance_km": p.weekday_km,
               "charging": charging, "trips": "custom", "weekend_km": p.weekend_km,
               "trips_per_month": p.trips_per_month}
    st.session_state["_guided_answers"] = answers
    st.session_state["_guided_custom_distance_km"] = float(p.weekday_km)
    st.session_state["_guided_custom_weekend_km"] = float(p.weekend_km)
    st.session_state["_guided_custom_trips_per_month"] = float(p.trips_per_month)
    st.session_state["_guided_pending"] = _pending_for(answers, p)
    st.session_state["_guided_assumptions"] = summarize(p)["assumptions"]
    st.session_state["_guided_step"] = 3
    st.session_state.pop("_guided_edit_stage", None)
    st.session_state.pop("_guided_error", None)


def _render_custom(stage: int) -> None:
    answers = st.session_state["_guided_answers"]
    if stage == 0:
        key = "guided_custom_distance_km"
        _custom_value(key, answers.get("distance_km", 40))
        st.slider("平日每天往返里程（km）", 0.0, 500.0, step=1.0, key=key,
                  on_change=_cache_custom, args=(key,))
        st.button("使用這個里程", key="guided_distance_apply", type="primary",
                  on_click=_choose, args=(0, "custom"), width="stretch")
    else:
        km_key, count_key = "guided_custom_weekend_km", "guided_custom_trips_per_month"
        _custom_value(km_key, answers.get("weekend_km", 200))
        _custom_value(count_key, answers.get("trips_per_month", 1))
        st.slider("一趟週末往返里程（km）", 0.0, 1500.0, step=1.0, key=km_key,
                  on_change=_cache_custom, args=(km_key,))
        st.slider("每月出遊次數（趟）", 0.0, 4.33, step=0.01, key=count_key,
                  on_change=_cache_custom, args=(count_key,))
        st.caption("每週最多一趟；填 0 代表這次先不計週末出遊。")
        st.button("確認這個出遊安排", key="guided_trips_apply", type="primary",
                  on_click=_choose, args=(2, "custom"), width="stretch")


def _render_question(stage: int) -> None:
    titles = ("平日每天往返，約幾公里？", "平常可以在哪裡充電？", "週末出遊，要先算多少？")
    descriptions = (
        "點選常見里程，或直接拖曳下方滑桿。先以每週 5 個平日、一年 52 週試算。",
        "有固定車位，也要確認供電與安裝。公共充電需確認接頭、時段與使用條件。",
        "每個出遊選項都以一趟往返 200 km 示範；選「先看日常」就不計額外週末行程。",
    )
    options = (DISTANCE_OPTIONS, CHARGING_OPTIONS, TRIP_OPTIONS)[stage]
    prefix = ("distance", "charging", "trips")[stage]
    order = (("short", "regular", "long", "far", "unknown"),
             ("home", "public", "unknown", "unavailable"),
             ("routine", "monthly", "twice", "frequent", "unknown"))[stage]
    with st.container(key="guided_question"):
        st.caption(f"第 {stage + 1} 步，共 3 步")
        st.subheader(titles[stage])
        st.write(descriptions[stage])
        if stage == 0:
            _render_custom(0)
            st.caption("也可以直接選一個常見里程，立即前進。")
        columns = st.columns(2, gap="small")
        selected = st.session_state["_guided_answers"].get(prefix)
        for index, option_id in enumerate(order):
            option = options[option_id]
            with columns[index % 2]:
                st.button(option["label"], key=f"guided_{prefix}_{option_id}",
                          type="primary" if selected == option_id else "secondary",
                          help=option["description"], width="stretch", on_click=_choose,
                          args=(stage, option_id))
                st.caption(option["description"])
        if stage == 2:
            with columns[1]:
                st.button("自訂出遊安排",
                          key=f"guided_{prefix}_custom", on_click=_open_custom,
                          args=(stage,), width="stretch")
                st.caption("用滑桿調整，確認後再繼續。")
            if st.session_state.get("_guided_custom_open") == stage or selected == "custom":
                _render_custom(stage)
    if stage > 0:
        st.button("上一步", key="guided_back", on_click=_navigate, args=(stage - 1,))


def _money(value: float | None) -> str:
    return "暫不估算" if value is None else f"NT$ {value:,.0f}"


def _render_results() -> None:
    try:
        p = Profile(**st.session_state["_saved_profile"])
        result = summarize(p)
    except (KeyError, TypeError, ValueError) as exc:
        st.error(f"請到進階設定確認上次的條件：{exc}")
        return
    pending = list(st.session_state.get("_guided_pending", []))
    if p.home_charging == "unknown" and not any("家充" in str(item) for item in pending):
        pending.extend(_pending_for({}, p))
    pending = list(dict.fromkeys(pending))
    week = result["week"]
    if pending:
        status, badge, title = "pending", "待確認條件", "先把不確定的地方確認清楚"
        copy = "以下是條件式情境估算；數字可供比較，尚不能確認實際可行。"
    elif not result["feasible"]:
        status, badge, title = "difficult", "需要調整", "目前補電安排還接不上行程"
        copy = "先增加可用的充電機會或調整里程，再比較能源支出。"
    else:
        status, badge = "", "情境結果"
        title = result["decision"]["title"]
        copy = "依目前假設計算，實際站點與道路耗能仍需確認。"
    st.markdown(f'<div class="guided-status {status}"><span>{html.escape(badge)}</span>'
                f'<strong>{html.escape(title)}</strong><p>{html.escape(copy)}</p></div>',
                unsafe_allow_html=True)
    for item in pending:
        st.caption("待確認 · " + str(item))

    charging = ("已確認可家充" if p.home_charging == "yes" else
                "家充待確認" if p.home_charging == "unknown" else "無家充")
    public = "公共充電已列入情境" if p.public_available else "無可用公共充電"
    trip = ("先看日常，未計額外週末出遊" if p.trips_per_month == 0 else
            f"週末一趟 {p.weekend_km:g} km，每月 {p.trips_per_month:g} 趟")
    st.caption(f"本次條件：平日每天往返 {p.weekday_km:g} km · {charging} · {public} · {trip}。")
    st.caption("可點上方任一步驟修改；選好就直接回到結果。")
    if not result["feasible"]:
        st.warning("本情境尚未完成全部里程、守住備援電量，或補回週初電量，因此不估算全年電費與節省金額。")
    if not p.public_available and p.home_charging != "yes":
        st.warning("目前沒有可持續使用的充電來源。請先確認家充或公共充電，再作換車判斷。")

    cols = st.columns(3)
    cols[0].metric("每月電費（情境）", _money(result["monthly_ev_energy"]))
    cols[1].metric("每月油費（參考基準）", _money(result["monthly_ice_energy"]))
    cols[2].metric("出遊代表週公共充電" if p.trips_per_month else "日常代表週公共充電",
                   f'{week["public_sessions"]} 次')
    st.caption("每月費用為全年平均；年里程以 260 個平日與每月出遊次數計算，並非單一出遊週直接乘上 52。")
    saving = result["monthly_energy_saving"]
    if saving is not None:
        direction = "減少" if saving >= 0 else "增加"
        st.write(f"依此情境，每月能源費比油車參考基準約{direction} **{_money(abs(saving))}**。")
    else:
        st.write("每月能源費差額：**暫不估算**。")
    st.caption(f"油車參考基準：油耗 {p.fuel_km_l:g} km/L、油價 NT$ {p.fuel_price:g}/L；"
               "均依目前參數，不從品牌或車齡推定。能源差額不是總持有成本差額。")

    st.subheader("這一週，電量如何變化？")
    days = week["days"]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[d["day"] for d in days], y=[d["end_soc"] for d in days],
                            name="日末電量", mode="lines+markers", line={"color": "#527a50", "width": 3},
                            hovertemplate="%{x} %{y:.1f}%<extra>日末電量</extra>"))
    fig.add_trace(go.Scatter(x=[d["day"] for d in days], y=[d["min_soc"] for d in days],
                            name="當日最低", mode="markers", marker={"color": "#b78940", "size": 7},
                            hovertemplate="%{x} %{y:.1f}%<extra>當日最低</extra>"))
    fig.add_hline(y=p.reserve_soc, line_dash="dot", line_color="#b78940")
    fig.update_layout(height=235, margin={"l": 8, "r": 8, "t": 12, "b": 0},
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font={"family": "Segoe UI, Microsoft JhengHei", "color": "#687761"},
                      legend={"orientation": "h", "y": 1.2},
                      yaxis={"range": [0, 105], "ticksuffix": "%", "gridcolor": "#e4e9df"},
                      xaxis={"showgrid": False})
    st.plotly_chart(fig, width="stretch", key="guided_soc_chart", config={"displayModeBar": False})
    st.caption(f"虛線是 {p.reserve_soc:g}% 備援門檻。" + (
        "圖中為含一趟出遊的代表週，月費另依出遊次數加權。" if p.trips_per_month else
        "本次只看日常平日行程，尚未評估長途出遊。"))

    with st.expander("查看費率、補電時間與其他假設"):
        st.write(f"家充 NT$ {p.home_price:g}/kWh，公共充電 NT$ {p.public_price:g}/kWh；"
                 f"每次公共充電另有 NT$ {p.public_parking_fee:g} 停車／服務費。這些費率是情境參數。")
        st.write(f"可用電池 {p.battery_kwh:g} kWh、電池端耗能 {p.consumption_kwh_100km:g} kWh/100km、"
                 f"充電效率 {p.charging_efficiency:.0%}，均可在進階設定調整。")
        st.write(f"家充有效功率 {p.home_power_kw:g} kW、每天最多 {p.home_hours:g} 小時；"
                 f"公共有效功率 {p.public_power_kw:g} kW、每天最多 {p.public_hours:g} 小時，"
                 f"每次另計 {p.detour_minutes:g} 分鐘繞路／等待。未啟用的充電來源不計入補電。")
        st.write(f"起始電量 {p.initial_soc:g}%；代表週總里程 {week['total_km']:g} km；"
                 f"年里程 {result['annual_km']:,.0f} km。")
        for assumption in result["assumptions"]:
            st.markdown("- " + assumption)
        for warning in week["warnings"]:
            st.warning(warning)


def render_guided_simulator(on_advanced: Callable[[], None]) -> None:
    """Render the simple flow; advanced editor and persistence remain caller-owned."""
    st.session_state.setdefault("_guided_answers", {})
    st.session_state.setdefault("_guided_step", 0)
    st.session_state.setdefault("_guided_pending", [])
    stage = st.session_state["_guided_step"]
    if stage not in (0, 1, 2, 3):
        stage = 0
        st.session_state["_guided_step"] = stage
    st.markdown(_STYLE, unsafe_allow_html=True)
    with st.sidebar:
        st.markdown('<div class="brand">轉電之前<small>EV FIT</small></div>', unsafe_allow_html=True)
        st.caption("先讓電動車，試著過你的一週。")
        st.divider()
        st.write("三步生活模擬")
        st.caption("選生活條件，就能看情境結果。" if stage < 3 else "結果已就緒，可回到任一步調整。")
        st.progress(min(stage, 3) / 3)
    st.markdown('<div class="eyebrow">YOUR WEEK, ELECTRIFIED.</div>', unsafe_allow_html=True)
    st.title("選條件，看看油轉電後的一週")
    st.caption("先用常見假設開始；有確切數字時，再到進階設定精算。")
    st.progress(min(stage, 3) / 3, text="已完成三步" if stage == 3 else f"第 {stage + 1} 步，共 3 步")
    answers = st.session_state["_guided_answers"]
    with st.container(key="guided_steps"):
        nav = st.columns(3)
        for index, label in enumerate(_STEP_NAMES):
            allowed = stage == 3 or all(answers.get(key) is not None for key in _ANSWER_KEYS[:index])
            nav[index].button(f"{index + 1}　{label}", key=f"guided_step_{index}",
                              disabled=not allowed, width="stretch", on_click=_navigate, args=(index,))
    if st.session_state.get("_guided_error"):
        st.error(st.session_state["_guided_error"])
    if stage == 0 and st.session_state.get("_saved_profile") and not any(answers.get(key) is not None for key in _ANSWER_KEYS):
        st.button("沿用上次條件看結果", key="guided_reuse_previous", on_click=_reuse_saved,
                  width="stretch")
    if stage == 3:
        _render_results()
    else:
        _render_question(stage)
    st.button("進階設定與完整報告" if stage == 3 else "開啟進階設定", key="guided_advanced",
              on_click=on_advanced, width="stretch")
