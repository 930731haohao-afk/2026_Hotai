"""Conservative, deterministic extraction for a user-confirmed intake form."""

import re


_NUMBER = r"(\d+(?:\.\d+)?)"
_PATTERNS = {
    "weekday_km": [
        rf"(?:平日|工作日)(?:\s*(?:每天|每日|一天))?\s*(?:開車|開|行駛|通勤|往返|來回|約|大約|共|總共|是|為|[:：]){{0,4}}\s*{_NUMBER}\s*(?:公里|km)",
    ],
    "weekend_km": [
        rf"(?:週末|周末|假日)(?:\s*(?:每趟|一趟|出遊|往返|來回|約|大約|共|總共|是|為|[:：])){{0,5}}\s*{_NUMBER}\s*(?:公里|km)",
    ],
    "trips_per_month": [
        rf"(?:每月|一個月|每個月)\s*(?:約|大約|出遊|出門|跑|有)?\s*{_NUMBER}\s*(?:趟|次)",
    ],
    "fuel_km_l": [
        rf"油耗\s*(?:約|大約|是|為|[:：])?\s*{_NUMBER}\s*(?:公里\s*[/／]\s*(?:公升|升)|km\s*[/／]\s*l)",
        rf"(?:每公升|每升)(?:油)?\s*(?:可跑|可開|可行駛|跑|開)\s*{_NUMBER}\s*(?:公里|km)",
    ],
    "home_hours": [
        rf"(?:每天|每日|每晚)?\s*(?:在家充電|家充|在家可充電)(?:\s*(?:時間|可用|可充|能充|可以充|約|大約|是|為|[:：])){{0,3}}\s*{_NUMBER}\s*(?:小時|hr|h)",
    ],
}
_LABELS = {
    "weekday_km": "平日每天里程",
    "weekend_km": "週末單趟往返里程",
    "trips_per_month": "每月週末出遊次數",
    "fuel_km_l": "燃油效率",
    "home_hours": "每天家充時數",
    "home_charging": "家充可用性",
}
_RANGES = {
    "weekday_km": (0, 500), "weekend_km": (0, 1500), "trips_per_month": (0, 4.33),
    "fuel_km_l": (1, 50), "home_hours": (0, 24),
}


def parse_description(text: str) -> dict:
    """Extract only explicit values; conflicting/unsupported facts remain unfilled.

    This is a regex helper, not an LLM. Its output must be reviewed in the UI
    before applying it to a simulation. In particular, parking is not charging.
    """
    if not isinstance(text, str):
        raise TypeError("description must be text")
    text = text[:10000]
    fields, notes = {}, []
    for field, patterns in _PATTERNS.items():
        values = {
            float(match.group(1))
            for pattern in patterns
            for match in re.finditer(pattern, text, flags=re.IGNORECASE)
        }
        if len(values) > 1:
            notes.append(f"{_LABELS[field]}出現不同數值，請自行確認；未自動填入。")
        elif values:
            value = values.pop()
            lower, upper = _RANGES[field]
            if not lower <= value <= upper:
                notes.append(f"{_LABELS[field]}須介於 {lower:g} 至 {upper:g}，此數值未填入，請自行確認。")
            else:
                fields[field] = int(value) if value.is_integer() else value

    # Work clause by clause so a negation cannot accidentally become a 'yes'.
    home_states = set()
    for clause in re.split(r"[，,。；;！!？?\n]", text):
        if not re.search(r"家充|在家充電|家用充電|家用充電樁", clause):
            continue
        uncertain = re.search(
            r"不確定|尚未確認|未確認|待確認|還不確定|不知道|能不能|可不可以|是否|可能|也許|如果|假如|打算|計畫|考慮", clause
        )
        if uncertain:
            home_states.add("unknown")
            continue
        no = re.search(
            r"(?:無法|不能|不可|不可以|沒辦法|不會|未能)\s*(?:安裝|裝|使用|用)?\s*(?:家充|家用充電樁|家用充電)|"
            r"(?:沒有|未裝|沒裝|無)\s*(?:家充|家用充電樁|家用充電)|"
            r"(?:無法|不能|不可|不可以|沒辦法)\s*在家充電", clause
        )
        yes = re.search(
            r"(?<!不)(?<!否)(?:可|可以|能|能夠)\s*(?:安裝|裝)\s*(?:家充|家用充電樁)|"
            r"(?:已裝|已安裝|已經裝|已經安裝)\s*(?:家充|家用充電樁)|"
            r"(?<!不)(?<!否)(?:可|可以|能|能夠)\s*在家充電", clause
        )
        if no:
            home_states.add("no")
        if yes:
            home_states.add("yes")
    if len(home_states) == 1:
        fields["home_charging"] = home_states.pop()
    elif len(home_states) > 1:
        notes.append("家充描述相互矛盾，請自行確認；未自動填入。")
    if "有車位" in text and "home_charging" not in fields:
        notes.append("有車位不代表能安裝或使用家充，請另行確認。")
    if re.search(r"(?:週末|周末|假日)\s*(?:每天|每日|一天)", text):
        fields.pop("weekend_km", None)
        notes.append("週末每天里程無法直接當成單趟往返里程，請自行填寫。")
    if "weekend_km" in fields:
        notes.append("週末里程會用作單趟往返總公里，請確認是否包含回程。")
    missing = [_LABELS[key] for key in _LABELS if key not in fields]
    if missing:
        notes.append("未辨識欄位保留表單原值，請確認：" + "、".join(missing) + "。")
    notes.append("以上由固定文字規則擷取，尚未套用；請確認數值及單位後再套用。")
    return {"fields": fields, "notes": notes}
