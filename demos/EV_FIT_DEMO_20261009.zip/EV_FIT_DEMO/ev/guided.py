"""Map three explicit wizard choices into a deterministic simulation profile.

Unknown answers remain disclosed scenario assumptions. This module never
queries a model, looks up a vehicle, or silently completes an unchosen step.
"""
from dataclasses import asdict
import math

from ev.engine import Profile


DEFAULT_ANSWERS = {"distance": None, "charging": None, "trips": None}

DISTANCE_OPTIONS = {
    "short": {"label": "短程移動", "description": "平日一天往返約 20 公里", "km": 20, "confirmed": True},
    "regular": {"label": "一般通勤", "description": "平日一天往返約 40 公里", "km": 40, "confirmed": True},
    "long": {"label": "較長通勤", "description": "平日一天往返約 80 公里", "km": 80, "confirmed": True},
    "far": {"label": "長距離用車", "description": "平日一天往返約 120 公里", "km": 120, "confirmed": True},
    "unknown": {"label": "還不確定", "description": "暫用每天 40 公里看情境，之後再確認", "km": 40, "confirmed": False},
}

CHARGING_OPTIONS = {
    "home": {"label": "已確認可以家充", "description": "有可使用的家充；這次不另外假設有公共充電"},
    "public": {"label": "使用公共充電", "description": "無家充，已確認有可用的公共充電選項"},
    "unknown": {"label": "充電條件還不確定", "description": "暫看有公共充電可用的情境，仍需確認"},
    "unavailable": {"label": "目前沒有充電管道", "description": "目前無法家充，也沒有可用的公共充電"},
}

TRIP_OPTIONS = {
    "routine": {"label": "以日常移動為主", "description": "不另外計入週末出遊", "weekend_km": 0, "trips_per_month": 0, "confirmed": True},
    "monthly": {"label": "每月約一趟", "description": "每趟往返先用 200 公里", "weekend_km": 200, "trips_per_month": 1, "confirmed": True},
    "twice": {"label": "每月約兩趟", "description": "每趟往返先用 200 公里", "weekend_km": 200, "trips_per_month": 2, "confirmed": True},
    "frequent": {"label": "幾乎每週出遊", "description": "每月 4 趟，每趟往返先用 200 公里", "weekend_km": 200, "trips_per_month": 4, "confirmed": True},
    "unknown": {"label": "出遊安排還不確定", "description": "先只看平日，長途需求尚未納入", "weekend_km": 0, "trips_per_month": 0, "confirmed": False},
}


def _number(name, value, maximum):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} 必須是有限數字。")
    if not 0 <= value <= maximum:
        raise ValueError(f"{name} 必須介於 0 至 {maximum:g}。")
    return value


def _choice(answers, stage, options, *, allow_custom=False):
    value = answers.get(stage)
    if value is None:
        raise ValueError(f"請先完成 {stage} 選擇；不確定時請明確選擇『還不確定』。")
    if not isinstance(value, str) or (value not in options and not (allow_custom and value == "custom")):
        raise ValueError(f"{stage} 不是有效選項。")
    return value


def build_guided_profile(answers: dict, base: dict | None = None) -> dict:
    """Return a validated Profile dict, pending items, assumptions and labels.

    Only five wizard-owned Profile fields change. Existing prices, fuel
    efficiency, charging windows, battery assumptions and ownership years are
    retained. A custom choice requires explicit numbers, including zero.
    """
    if not isinstance(answers, dict):
        raise ValueError("answers 必須是三個步驟的選擇資料。")
    distance = _choice(answers, "distance", DISTANCE_OPTIONS, allow_custom=True)
    charging = _choice(answers, "charging", CHARGING_OPTIONS)
    trips = _choice(answers, "trips", TRIP_OPTIONS, allow_custom=True)
    if base is not None and not isinstance(base, dict):
        raise ValueError("base 必須是試算設定物件。")
    try:
        values = asdict(Profile(**(base or {})))
    except TypeError as error:
        raise ValueError("既有試算設定包含不支援的欄位或格式。") from error

    pending = []
    labels = {"charging": CHARGING_OPTIONS[charging]["label"]}
    if distance == "custom":
        weekday_km = _number("平日每天往返里程", answers.get("distance_km"), 500)
        labels["distance"] = f"每天往返 {weekday_km:g} 公里"
    else:
        option = DISTANCE_OPTIONS[distance]
        weekday_km = option["km"]
        labels["distance"] = option["label"]
        if not option["confirmed"]:
            pending.append("平日實際往返里程尚未確認；暫用每天 40 公里呈現情境。")

    if trips == "custom":
        weekend_km = _number("週末每趟往返里程", answers.get("weekend_km"), 1500)
        trips_per_month = _number("每月週末出遊次數", answers.get("trips_per_month"), 4.33)
        labels["trips"] = f"每月 {trips_per_month:g} 趟，每趟往返 {weekend_km:g} 公里"
    else:
        option = TRIP_OPTIONS[trips]
        weekend_km = option["weekend_km"]
        trips_per_month = option["trips_per_month"]
        labels["trips"] = option["label"]
        if not option["confirmed"]:
            pending.append("週末出遊次數與里程尚未確認；本次未計入長途，不能據此判定長途也適合。")

    home_charging, public_available = {
        "home": ("yes", False),
        "public": ("no", True),
        "unknown": ("unknown", True),
        "unavailable": ("no", False),
    }[charging]
    if charging == "unknown":
        pending.extend([
            "家充能否安裝及使用尚未確認；有車位不等於可以家充。",
            "公共充電可用性也尚未確認；本次只是暫設有公共充電可用的情境，需核對站點、時段與費率。",
        ])
    values.update(weekday_km=weekday_km, home_charging=home_charging,
                  public_available=public_available, weekend_km=weekend_km,
                  trips_per_month=trips_per_month)
    profile = Profile(**values)

    assumptions = [
        "每週固定 5 個平日，每天使用所選往返總里程；這是模型安排，不表示已確認實際到班天數。",
        f"平日每天 {weekday_km:g} 公里；週末每趟往返 {weekend_km:g} 公里、每月 {trips_per_month:g} 趟。選項中的代表里程是情境值，可再修改。",
        "年化使用 52 週；每週最多安排一趟週末出遊，成本按每月出遊頻率加權，沒有查詢實際路線。",
        "車款固定使用本原型的台灣 TOYOTA bZ4X 情境，沒有依選項查找或推薦新車款。",
        f"可用電池 {profile.battery_kwh:g} kWh、電池端耗能 {profile.consumption_kwh_100km:g} kWh/100 km、充電效率 {profile.charging_efficiency:g}，均為目前試算假設，不是道路表現保證。",
        f"沿用油耗 {profile.fuel_km_l:g} km/L、汽油 {profile.fuel_price:g} 元/L、家充 {profile.home_price:g} 元/kWh、公共充電 {profile.public_price:g} 元/kWh；沒有取得即時報價。",
        f"沿用家充每天 {profile.home_hours:g} 小時／{profile.home_power_kw:g} kW，公共充電每天最多一次、每次 {profile.public_hours:g} 小時／{profile.public_power_kw:g} kW，繞行及等待 {profile.detour_minutes:g} 分鐘；可用性依本次選項，時段與功率尚未逐項確認。",
        f"週初電量 {profile.initial_soc:g}%、備援 {profile.reserve_soc:g}%，週末需補回週初電量；公共充電每次附加費 {profile.public_parking_fee:g} 元，持有期間沿用 {profile.years:g} 年。",
        "其餘參數沿用既有試算設定；未提供設定時採展示預設值。能源費差額不等於完整持有成本節省。",
    ]
    if charging == "home":
        assumptions.append("已選擇可家充；不額外假設可使用公共充電，因此這次公共充電設為不可用。")
    elif charging == "public":
        assumptions.append("已選擇有可用公共充電；家充設為不可用，仍需自行核對所選站點與可用時段，沒有即時站點連線。")
    elif charging == "unknown":
        assumptions.append("充電條件未確認：保守不計家充，但為了展示情境而暫設公共充電可用；這不是已確認可行的結論。")
    else:
        assumptions.append("已選擇目前沒有充電管道；家充與公共充電均設為不可用，不會自動補入充電機會。")
    if trips == "unknown":
        assumptions.append("週末安排未知，因此本次出遊里程與頻率設為 0；這是暫時排除長途，不代表使用者沒有長途需求。")

    return {"profile": asdict(profile), "pending": pending, "assumptions": assumptions, "labels": labels}
