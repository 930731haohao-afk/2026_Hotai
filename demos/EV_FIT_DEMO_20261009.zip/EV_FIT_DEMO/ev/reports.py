"""Standalone exports of an estimate, including uncertainty and provenance."""

from datetime import datetime, timezone
from html import escape
import math
from urllib.parse import urlsplit


_LABELS = {
    "weekday_km": "平日每天里程（km）", "weekend_km": "週末單趟往返里程（km）",
    "trips_per_month": "每月週末出遊次數", "home_charging": "家充可用性",
    "fuel_km_l": "燃油效率（km/L）", "home_hours": "每天家充時數",
    "vehicle_id": "電動車款", "vehicle": "電動車款", "battery_kwh": "電池容量（kWh）",
    "usable_kwh": "可用電池容量（kWh）", "usable_battery_kwh": "可用電池容量（kWh）",
    "ev_kwh_100km": "電耗（kWh/100 km）", "consumption_kwh_100km": "電耗（kWh/100 km）",
    "fuel_price": "油價（元/L）", "gas_price": "油價（元/L）",
    "home_price": "家充電價（元/kWh）", "public_price": "公共充電價（元/kWh）",
    "home_kw": "家充平均功率（kW）", "public_kw": "公共充電平均功率（kW）",
    "initial_soc": "期初電量（%）", "start_soc": "期初電量（%）",
    "min_soc": "最低保留電量（%）", "reserve_soc": "最低保留電量（%）",
    "target_soc": "充電目標電量（%）", "charge_efficiency": "充電效率",
    "ownership": "持有成本參數", "years": "持有年數", "scenario": "燃油車比較情境",
    "ev_price": "電動車購入價（元）", "ice_price": "燃油車購入價（元）",
    "charger_cost": "家充安裝費（元）", "ev_resale": "電動車期末殘值（元）",
    "ice_resale": "燃油車期末殘值（元）", "checked_at": "查核日期",
    "retrieved_at": "擷取日期", "verified_at": "查核日期", "updated_at": "資料更新日期",
    "as_of": "資料日期", "name": "名稱", "model": "車型", "title": "項目",
    "status": "資料狀態", "note": "說明", "notes": "說明", "url": "來源",
    "source_url": "來源", "price_twd": "售價（元）", "battery_total_kwh": "總電池容量（kWh）",
    "battery_usable_kwh": "可用電池容量（kWh）", "ac_max_kw": "AC 最高功率（kW）",
    "dc_max_kw": "DC 最高功率（kW）",
    "public_available": "已確認公共充電可用", "public_hours": "每次公共充電時窗（小時）",
    "detour_minutes": "每次充電繞行時間（分鐘）", "charging_efficiency": "充電效率",
    "home_power_kw": "家充平均功率（kW）", "public_power_kw": "公共充電平均功率（kW）",
    "public_parking_fee": "每次公共充電停車／服務費（元）", "baseline": "燃油車比較情境",
    "ice_value": "燃油車現售價或新購價（元）", "ice_maintenance_year": "燃油車每年保養（元）",
    "ev_maintenance_year": "電動車每年保養（元）", "ice_insurance_year": "燃油車每年保險（元）",
    "ev_insurance_year": "電動車每年保險（元）", "home_install": "家充設備與安裝（元）",
    "ice_tax_year": "燃油車每年稅費（元）", "ev_tax_year": "電動車每年稅費（元）",
    "extra_ev_parking_year": "電動車每年額外停車費（元）", "feasible_charging_plan": "可行的充電安排",
}
_VALUES = {"yes": "已確認可用", "no": "不可用", "unknown": "尚未確認（按不可用估算）",
           "keep": "繼續持有現有燃油車", "new": "購買新燃油車"}
_PRIVATE = {"description", "raw_description", "raw_text", "text", "prompt", "name", "email", "phone", "address", "home_address", "work_address", "user_id"}
_CAUTION = "本報告為人工輸入條件的情境試算，未連接即時充電站、交通、排隊或車輛資料，也未經真實使用者行程驗證。結果不是購車保證。"


def _display(value):
    if value is None:
        return "尚未提供"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            return "無有效估計"
        return f"{value:,.2f}".rstrip("0").rstrip(".") if isinstance(value, float) else f"{value:,}"
    if isinstance(value, dict):
        return "；".join(f"{_LABELS.get(str(k), str(k))}：{_display(v)}" for k, v in value.items())
    if isinstance(value, (list, tuple)):
        return "；".join(_display(item) for item in value)
    return _VALUES.get(str(value), str(value))


def _as_list(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _source_rows(sources, profile):
    """Accept evolving source JSON without hiding provenance or conflict notes."""
    rows = []
    selected = str(profile.get("vehicle_id", ""))

    def visit(node, prefix=""):
        if isinstance(node, dict):
            for key, value in node.items():
                label = _LABELS.get(str(key), str(key))
                path = f"{prefix}／{label}" if prefix else label
                if key == "vehicles" and isinstance(value, list) and selected:
                    matches = [v for v in value if isinstance(v, dict) and str(v.get("id", "")) == selected]
                    visit(matches or value, path)
                elif isinstance(value, (dict, list)):
                    visit(value, path)
                else:
                    rows.append((path, _display(value)))
        elif isinstance(node, list):
            for index, value in enumerate(node):
                visit(value, f"{prefix} {index + 1}")
        else:
            rows.append((prefix or "來源", _display(node)))

    visit(sources)
    return rows


def _input_rows(profile):
    rows = []
    for key, value in profile.items():
        if str(key).lower() in _PRIVATE:
            continue
        if isinstance(value, dict):
            for child_key, child_value in value.items():
                if str(child_key).lower() not in _PRIVATE:
                    rows.append((f"{_LABELS.get(key, key)}／{_LABELS.get(child_key, child_key)}", _display(child_value)))
        else:
            rows.append((_LABELS.get(key, key), _display(value)))
    return rows


def _report_parts(profile, result, sources):
    decision = result.get("decision") or {}
    if not isinstance(decision, dict):
        decision = {"title": _display(decision)}
    title = _display(decision.get("title", "油轉電情境試算"))
    metrics = [(label, "暫不估算" if result.get(key) is None else _display(result[key])) for label, key in [
        ("年行駛里程（km）", "annual_km"), ("每月燃油能源費（元）", "monthly_ice_energy"),
        ("每月電動能源費（元）", "monthly_ev_energy"), ("每月能源費差額／省下（元）", "monthly_energy_saving"),
        ("每週額外充電時間（分鐘）", "weekly_extra_minutes"),
    ]]
    notes = [_CAUTION]
    if profile.get("home_charging") == "unknown":
        notes.append("家充條件尚未確認，本次保守地按家充不可用計算；有固定車位並不等於可安裝充電設備。")
    if result.get("monthly_energy_saving") is None:
        notes.append("尚無可比較的完整能源費估計；若行程未完成，不推估月省金額。")
    tco = result.get("tco") or {}
    if not isinstance(tco, dict):
        tco = {}
    if tco.get("complete"):
        cost_title = "完整持有成本試算（依所填成本項目）"
        costs = [
            ("燃油車總成本（元）", _display(tco.get("ice"))),
            ("電動車總成本（元）", _display(tco.get("ev"))),
            ("持有成本差額／電車少花（元）", _display(tco.get("difference"))),
        ]
    else:
        cost_title = "能源費比較，尚非完整持有成本（TCO）"
        missing = _as_list(tco.get("missing"))
        costs = [("待補成本項目", "、".join(_LABELS.get(str(item), _display(item)) for item in missing) or "尚未提供完整購車、殘值與持有費用")]
        notes.append("能源費差額未包含所有購車、殘值、保險、保養、稅費與設備成本，不能等同買車後的總節省。")
    cost_breakdown = [
        (_display(row.get("label", row.get("key", "成本項目"))), _display(row.get("ice")), _display(row.get("ev")))
        for row in _as_list(tco.get("rows")) if isinstance(row, dict)
    ]
    days = result.get("days", result.get("week", []))
    if isinstance(days, dict):
        days = days.get("days", [])
    if not isinstance(days, list):
        days = []
    day_rows = []
    for day in days:
        if not isinstance(day, dict):
            continue
        day_rows.append(tuple(_display(day.get(key)) for key in ["day", "km", "start_soc", "end_soc", "public_kwh", "extra_minutes", "unserved_km"]))
    return {
        "title": title,
        "created": datetime.now(timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M %Z"),
        "metrics": metrics, "reasons": _as_list(decision.get("reasons")),
        "next_steps": _as_list(decision.get("next_steps")), "cost_title": cost_title,
        "costs": costs, "cost_breakdown": cost_breakdown, "days": day_rows,
        "assumptions": _as_list(result.get("assumptions")), "notes": notes,
        "inputs": _input_rows(profile), "sources": _source_rows(sources, profile),
    }


def _md(value):
    text = escape(_display(value), quote=False).replace("\\", "\\\\")
    for character in "|`*_[]":
        text = text.replace(character, "\\" + character)
    return text.replace("\r", " ").replace("\n", " ")


def _md_table(headers, rows):
    return ["| " + " | ".join(_md(item) for item in headers) + " |",
            "| " + " | ".join("---" for _ in headers) + " |"] + [
                "| " + " | ".join(_md(item) for item in row) + " |" for row in rows]


def build_markdown(profile: dict, result: dict, sources: dict) -> str:
    parts = _report_parts(profile, result, sources)
    lines = ["# 油轉電試算報告", "", f"**{_md(parts['title'])}**", "", f"產生時間：{parts['created']}", ""]
    lines += [f"- {_md(item)}" for item in parts["reasons"]]
    lines += [""] + _md_table(["項目", "試算值"], parts["metrics"])
    lines += ["", f"## {parts['cost_title']}", ""] + _md_table(["項目", "試算值"], parts["costs"])
    if parts["days"]:
        lines += ["", "## 一週行程", ""] + _md_table(["日期", "里程 km", "起始 %", "結束 %", "公共充電 kWh", "額外分鐘", "未完成 km"], parts["days"])
    for title, items in [("下一步", parts["next_steps"]), ("使用限制", parts["notes"]), ("計算假設", parts["assumptions"])]:
        if items:
            lines += ["", f"## {title}", ""] + [f"- {_md(item)}" for item in items]
    if parts["cost_breakdown"]:
        lines += ["", "## 持有期間成本明細（元）", ""] + _md_table(["項目", "燃油車", "電動車"], parts["cost_breakdown"])
    for title, rows in [("輸入條件", parts["inputs"]), ("車款資料與來源", parts["sources"])]:
        if rows:
            lines += ["", f"## {title}", ""] + _md_table(["項目", "內容"], rows)
    return "\n".join(lines) + "\n"


def _html_value(value):
    value = _display(value)
    safe = escape(value, quote=True)
    try:
        parsed = urlsplit(value)
    except ValueError:
        return safe
    if parsed.scheme in {"http", "https"} and parsed.netloc and not any(c in value for c in "\r\n\t"):
        return f'<a href="{safe}" rel="noreferrer noopener">{safe}</a>'
    return safe


def _html_table(headers, rows):
    return "<table><thead><tr>" + "".join(f"<th>{escape(item)}</th>" for item in headers) + "</tr></thead><tbody>" + "".join(
        "<tr>" + "".join(f"<td>{_html_value(item)}</td>" for item in row) + "</tr>" for row in rows
    ) + "</tbody></table>"


def _source_footnote(sources):
    if not isinstance(sources, dict):
        return ""
    vehicle = sources.get("vehicle", {})
    vehicle = vehicle if isinstance(vehicle, dict) else {}
    specs = []
    for key, label in [("name", "車款"), ("specification_version", "規配版本")]:
        if vehicle.get(key):
            specs.append(f"{label}：{_display(vehicle[key])}")
    if sources.get("verified_at"):
        specs.append("資料查核：" + _display(sources["verified_at"]))
    if vehicle.get("battery_published_kwh") is not None:
        specs.append("官方標示電池 " + _display(vehicle["battery_published_kwh"]) + " kWh；可用容量未確認，模擬另採假設")
    if vehicle.get("ac_max_kw") is not None and vehicle.get("dc_max_kw") is not None:
        specs.append(f"官方峰值 AC {_display(vehicle['ac_max_kw'])}／DC {_display(vehicle['dc_max_kw'])} kW，非固定充電速度")
    links = []
    for source in _as_list(sources.get("sources")):
        if not isinstance(source, dict) or not source.get("url"):
            continue
        url, title = str(source["url"]), _display(source.get("title", "來源"))
        try:
            parsed = urlsplit(url)
        except ValueError:
            continue
        if parsed.scheme in {"https", "http"} and parsed.netloc and not any(c in url for c in "\r\n\t"):
            links.append(f'<a href="{escape(url, quote=True)}" rel="noreferrer noopener">{escape(title)}</a>')
    return '<footer class="sources"><p>' + escape("｜".join(specs)) + "</p><p>" + " · ".join(links) + "</p></footer>" if specs or links else ""


def build_html(profile: dict, result: dict, sources: dict) -> str:
    parts = _report_parts(profile, result, sources)
    body = ["<article class=summary><header><p class=eyebrow>EV FIT · 轉電之前</p><h1>油轉電試算報告</h1>",
            f"<p class=decision>{escape(parts['title'])}</p><p class=muted>產生時間：{escape(parts['created'])} · 可使用瀏覽器列印為 PDF</p></header>"]
    if parts["reasons"]:
        body += ["<ul>" + "".join(f"<li>{escape(_display(item))}</li>" for item in parts["reasons"]) + "</ul>"]
    body += ["<div class=metrics>" + "".join(f"<div><span>{escape(label)}</span><strong>{escape(value)}</strong></div>" for label, value in parts["metrics"]) + "</div>", f"<h2>{escape(parts['cost_title'])}</h2>", "<p class=cost>" + "；".join(f"{escape(label)}：{escape(value)}" for label, value in parts["costs"]) + "</p>"]
    if parts["days"]:
        body += ["<h2>一週行程</h2>", _html_table(["日期", "里程 km", "起始 %", "結束 %", "公共充電 kWh", "額外分鐘", "未完成 km"], parts["days"])]
    for title, items in [("下一步", parts["next_steps"]), ("使用限制", parts["notes"])]:
        if items:
            body += [f"<h2>{title}</h2><ul>" + "".join(f"<li>{escape(_display(item))}</li>" for item in items) + "</ul>"]
    core_keys = ["weekday_km", "weekend_km", "trips_per_month", "home_charging", "battery_kwh", "consumption_kwh_100km", "initial_soc", "reserve_soc", "home_price", "public_price"]
    body += ["<p class=core><b>核心條件：</b>" + "；".join(escape(_LABELS.get(key, key)) + " " + escape(_display(profile[key])) for key in core_keys if key in profile) + "。</p>", _source_footnote(sources), "</article>", "<details class=appendix><summary>完整輸入、計算假設與來源（不列印）</summary>"]
    if parts["assumptions"]:
        body += ["<h2>計算假設</h2><ul>" + "".join(f"<li>{escape(_display(item))}</li>" for item in parts["assumptions"]) + "</ul>"]
    if parts["cost_breakdown"]:
        body += ["<h2>持有期間成本明細（元）</h2>", _html_table(["項目", "燃油車", "電動車"], parts["cost_breakdown"])]
    for title, rows in [("輸入條件", parts["inputs"]), ("車款資料與來源", parts["sources"])]:
        if rows:
            body += [f"<h2>{title}</h2>", _html_table(["項目", "內容"], rows)]
    body += ["</details>"]
    return """<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>油轉電試算報告</title><style>
:root{color-scheme:light}*{box-sizing:border-box}body{font-family:"Microsoft JhengHei",sans-serif;color:#182b28;background:#f2f4ee;line-height:1.5;margin:0;padding:24px}main{max-width:960px;margin:auto;background:white;padding:28px 36px;border-radius:14px}h1{font-size:28px;margin:0}h2{font-size:15px;margin:14px 0 5px}.eyebrow{letter-spacing:.12em;color:#467162;font-size:11px;margin:0 0 5px}.decision{font-size:20px;font-weight:bold;margin:6px 0}.muted{color:#60726c;font-size:11px;margin:4px 0}table{border-collapse:collapse;width:100%;font-size:12px;margin:8px 0;table-layout:fixed}th,td{border-bottom:1px solid #d9e2dd;padding:6px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#eaf2e9}ul{padding-left:20px;font-size:12px;margin:6px 0}li{margin:3px 0}a{color:#226d50;overflow-wrap:anywhere}.metrics{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:14px 0}.metrics>div{background:#eaf2e9;padding:10px;border-radius:6px}.metrics span{font-size:10px;display:block}.metrics strong{font-size:22px;display:block;margin-top:5px}.cost,.core{font-size:11px;margin:6px 0}.core{border-top:1px solid #d9e2dd;padding-top:8px;margin-top:12px}.sources{color:#60726c;font-size:9px;line-height:1.5}.sources p{margin:4px 0}.appendix{margin-top:24px;border-top:1px solid #d9e2dd;padding-top:12px}.appendix summary{cursor:pointer;font-size:13px}header{border-bottom:2px solid #426b53;padding-bottom:8px}@page{size:A4;margin:12mm}@media print{body{background:#fff;padding:0}main{padding:0;max-width:none;border-radius:0}h1{font-size:20pt}h2{font-size:10pt;margin:9px 0 4px;break-after:avoid}.decision{font-size:14pt}.eyebrow,.muted{font-size:8pt}table{font-size:8pt}th,td{padding:4px}ul{font-size:8pt;line-height:1.4;margin:4px 0}li{margin:2px 0}.metrics{gap:6px;margin:10px 0}.metrics>div{padding:8px}.metrics span{font-size:7pt}.metrics strong{font-size:15pt}.cost,.core{font-size:8pt;line-height:1.4}.sources{font-size:6.8pt;line-height:1.35}tr{break-inside:avoid}header{break-inside:avoid}.appendix{display:none!important}a{text-decoration:none;color:inherit}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}
</style></head><body><main>""" + "".join(body) + "</main></body></html>"
