"""Deterministic calculations for small interactive answer cards.

Only reviewed knowledge-entry IDs select card types. Model prose never becomes
UI markup, a calculation, or a routing instruction. All amounts are examples.
"""
from dataclasses import asdict
import math

from ev.engine import Profile, summarize


_CARD_IDS = {
    "K01": "vehicles",
    **{key: "battery" for key in ("K02", "K03", "K04", "K08", "K09", "K10")},
    **{key: "charging" for key in ("K05", "K06", "K07", "K11")},
    **{key: "energy" for key in ("K12", "K13", "K14", "K15", "K20", "K21", "K22")},
    "K18": "loan",
    "K19": "loan",
}


def _bounded(name, value, lower, upper, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} 必須是有限數字。")
    if value < lower or value > upper or (positive and value <= 0):
        raise ValueError(f"{name} 超出允許範圍。")


def card_kind(result: dict) -> str:
    """Select the first mapped entry from service-vetted ``entries``.

    ``source_ids``, ``answer`` and model-supplied display fields are ignored.
    A result without usable evidence always gets a next-step card.
    """
    if not isinstance(result, dict) or result.get("mode") == "no_evidence":
        return "next_steps"
    entries = result.get("entries")
    if not isinstance(entries, list):
        return "next_steps"
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        entry_id = entry.get("id")
        if isinstance(entry_id, str) and entry_id in _CARD_IDS:
            return _CARD_IDS[entry_id]
    return "next_steps"


def micro_energy(monthly_km, home_share_pct, fuel_price=32, fuel_km_l=14,
                 consumption=17, efficiency=0.9, home_price=3, public_price=10) -> dict:
    """Monthly energy-only example, using battery consumption and grid prices.

    Charging efficiency is applied once. A percentage of billed charging kWh,
    rather than a percentage of stops or driving days, is assigned to home.
    """
    values = {
        "monthly_km": (monthly_km, 0, 10000, False),
        "home_share_pct": (home_share_pct, 0, 100, False),
        "fuel_price": (fuel_price, 0, 500, True),
        "fuel_km_l": (fuel_km_l, 0, 100, True),
        "consumption": (consumption, 0, 100, True),
        "efficiency": (efficiency, 0, 1, True),
        "home_price": (home_price, 0, 100, False),
        "public_price": (public_price, 0, 100, False),
    }
    for name, (value, lower, upper, positive) in values.items():
        _bounded(name, value, lower, upper, positive=positive)
    grid_kwh = (monthly_km * consumption / 100) / efficiency
    home_fraction = home_share_pct / 100
    home_cost = grid_kwh * home_fraction * home_price
    public_cost = grid_kwh * (1 - home_fraction) * public_price
    ice_cost = monthly_km / fuel_km_l * fuel_price
    ev_cost = home_cost + public_cost
    result = {"ice_cost": ice_cost, "ev_cost": ev_cost, "saving": ice_cost - ev_cost,
              "home_cost": home_cost, "public_cost": public_cost, "grid_kwh": grid_kwh}
    if not all(math.isfinite(value) for value in result.values()):
        raise ValueError("輸入過於接近零或計算超出數值範圍，請使用合理的耗能與效率假設。")
    result["assumptions"] = [
        "這是可修改的每月能源費示例，費率、耗能與油耗是假設，不是即時報價或個人支出預測。",
        f"電池端耗能 {consumption:g} kWh/100 km；計費電量除以 {efficiency:g} 充電效率，僅計一次損耗。",
        f"家充占計費充電量 {home_share_pct:g}%，其餘使用公共電價；此比例不代表已確認家充或公共站點可用。",
        "僅比較汽油與電費，不含購車、折舊、保險、保養、停車、利息或充電設備，不等於總持有成本節省。",
    ]
    return result


def loan_example(principal=600000, annual_interest_pct=3, months=60) -> dict:
    """Equal monthly principal-and-interest payments at a fixed nominal rate.

    Assumes monthly payment in arrears, a monthly rate of annual_rate / 12,
    no fees, no balloon payment and no changes of rate. This is not APR,
    an actual loan quote, or a recommendation to borrow. Do not round here.
    """
    _bounded("principal", principal, 0, 100000000)
    _bounded("annual_interest_pct", annual_interest_pct, 0, 50)
    if isinstance(months, bool) or not isinstance(months, int) or not 12 <= months <= 120:
        raise ValueError("months 必須是 12 至 120 的整數。")
    monthly_rate = annual_interest_pct / 1200
    if monthly_rate == 0 or principal == 0:
        payment = principal / months
    else:
        # log1p/expm1 preserve accuracy when the interest rate is near zero.
        denominator = -math.expm1(-months * math.log1p(monthly_rate))
        payment = principal * (monthly_rate / denominator)
    interest = max(0.0, payment * months - principal)
    return {"monthly_payment": payment, "total_interest": interest,
            "total_payment": principal + interest}


def charging_preview(weekday_km, home_charging) -> dict:
    """A five-workday scenario with no weekend outing, plus all input values."""
    _bounded("weekday_km", weekday_km, 0, 500)
    profile = Profile(weekday_km=weekday_km, weekend_km=0, trips_per_month=0,
                      home_charging=home_charging, home_power_kw=7)
    return {**summarize(profile), "inputs": asdict(profile)}
