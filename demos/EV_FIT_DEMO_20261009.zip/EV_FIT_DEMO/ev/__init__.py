"""Deterministic, assumption-led EV lifestyle simulation."""

from .engine import Ownership, Profile, compare_scenarios, simulate_week, summarize

__all__ = ["Ownership", "Profile", "compare_scenarios", "simulate_week", "summarize"]
