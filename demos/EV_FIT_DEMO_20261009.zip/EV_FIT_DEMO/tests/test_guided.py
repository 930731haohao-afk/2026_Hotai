"""Wizard choices must not silently confirm missing facts or replace settings."""
from dataclasses import asdict
import math
import unittest

from ev.engine import Profile
from ev.guided import CHARGING_OPTIONS, DEFAULT_ANSWERS, DISTANCE_OPTIONS, TRIP_OPTIONS, build_guided_profile


class GuidedProfileTests(unittest.TestCase):
    def answers(self, **changes):
        return {"distance": "regular", "charging": "public", "trips": "monthly", **changes}

    def test_option_values_and_unselected_defaults_are_explicit(self):
        self.assertEqual(DEFAULT_ANSWERS, {"distance": None, "charging": None, "trips": None})
        self.assertEqual([DISTANCE_OPTIONS[key]["km"] for key in ("short", "regular", "long", "far", "unknown")], [20, 40, 80, 120, 40])
        self.assertFalse(DISTANCE_OPTIONS["unknown"]["confirmed"])
        self.assertFalse(TRIP_OPTIONS["unknown"]["confirmed"])
        self.assertEqual(set(CHARGING_OPTIONS), {"home", "public", "unknown", "unavailable"})
        self.assertEqual([TRIP_OPTIONS[key]["trips_per_month"] for key in ("routine", "monthly", "twice", "frequent", "unknown")], [0, 1, 2, 4, 0])

    def test_complete_choice_builds_the_expected_profile_and_labels(self):
        result = build_guided_profile(self.answers(distance="long", trips="twice"))
        self.assertEqual(set(result), {"profile", "pending", "assumptions", "labels"})
        self.assertEqual(set(result["labels"]), {"distance", "charging", "trips"})
        self.assertEqual(result["profile"]["weekday_km"], 80)
        self.assertEqual(result["profile"]["weekend_km"], 200)
        self.assertEqual(result["profile"]["trips_per_month"], 2)
        self.assertEqual(result["pending"], [])
        self.assertEqual(result["profile"]["fuel_km_l"], 14)
        self.assertTrue(any("5 個平日" in note for note in result["assumptions"]))
        self.assertTrue(any("bZ4X" in note for note in result["assumptions"]))

    def test_nonwizard_fields_preserved_and_base_not_mutated(self):
        base = asdict(Profile(fuel_km_l=18, years=7, home_price=4.5,
                              public_price=12, fuel_price=35, home_hours=6,
                              battery_kwh=60, public_parking_fee=30))
        before = dict(base)
        result = build_guided_profile(self.answers(distance="far", charging="home", trips="routine"), base)
        wizard_fields = {"weekday_km", "home_charging", "public_available", "weekend_km", "trips_per_month"}
        for key in set(base) - wizard_fields:
            with self.subTest(key=key):
                self.assertEqual(result["profile"][key], base[key])
        self.assertEqual(base, before)

    def test_routine_clears_existing_weekend_trip_instead_of_retaining_default(self):
        result = build_guided_profile(self.answers(trips="routine"), {"weekend_km": 400, "trips_per_month": 4})
        self.assertEqual(result["profile"]["weekend_km"], 0)
        self.assertEqual(result["profile"]["trips_per_month"], 0)

    def test_home_does_not_infer_public_charging(self):
        result = build_guided_profile(self.answers(charging="home"), {"public_available": True})
        self.assertEqual(result["profile"]["home_charging"], "yes")
        self.assertIs(result["profile"]["public_available"], False)

    def test_charging_choices_are_distinct_and_unavailable_stays_unavailable(self):
        for choice, home, public in (("public", "no", True), ("unknown", "unknown", True), ("unavailable", "no", False)):
            with self.subTest(choice=choice):
                result = build_guided_profile(self.answers(charging=choice))
                self.assertEqual(result["profile"]["home_charging"], home)
                self.assertIs(result["profile"]["public_available"], public)

    def test_unknown_choices_create_pending_facts_and_disclosed_scenarios(self):
        result = build_guided_profile(self.answers(distance="unknown", charging="unknown", trips="unknown"))
        self.assertEqual(result["profile"]["weekday_km"], 40)
        self.assertEqual(result["profile"]["weekend_km"], 0)
        self.assertEqual(result["profile"]["trips_per_month"], 0)
        self.assertEqual(len(result["pending"]), 4)
        self.assertTrue(any("公共充電可用性" in note for note in result["pending"]))
        self.assertTrue(any("未計入長途" in note for note in result["pending"]))
        self.assertTrue(any("暫設公共充電可用" in note for note in result["assumptions"]))

    def test_custom_values_accept_explicit_zero_and_upper_bounds(self):
        for distance, weekend, frequency in ((0, 0, 0), (500, 1500, 4.33), (37.5, 225.5, 2.5)):
            with self.subTest(distance=distance, weekend=weekend, frequency=frequency):
                result = build_guided_profile(self.answers(distance="custom", distance_km=distance,
                                                           trips="custom", weekend_km=weekend, trips_per_month=frequency))
                self.assertEqual(result["profile"]["weekday_km"], distance)
                self.assertEqual(result["profile"]["weekend_km"], weekend)
                self.assertEqual(result["profile"]["trips_per_month"], frequency)

    def test_missing_partial_invalid_or_unhashable_choices_are_rejected(self):
        cases = [None, {}, dict(DEFAULT_ANSWERS), {"distance": "short"},
                 self.answers(distance=None), self.answers(charging="yes"),
                 self.answers(trips="daily"), self.answers(distance=[]),
                 self.answers(distance="custom"), self.answers(trips="custom", weekend_km=200)]
        for answers in cases:
            with self.subTest(answers=answers), self.assertRaises(ValueError):
                build_guided_profile(answers)

    def test_custom_values_reject_nonfinite_bool_negative_and_out_of_range(self):
        for field, values in {
            "distance_km": [math.nan, math.inf, True, "40", -1, 501],
            "weekend_km": [math.nan, math.inf, False, "200", -1, 1501],
            "trips_per_month": [math.nan, math.inf, True, "2", -1, 4.34],
        }.items():
            for value in values:
                answers = self.answers(distance="custom", distance_km=40, trips="custom", weekend_km=200, trips_per_month=2)
                answers[field] = value
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    build_guided_profile(answers)

    def test_base_is_validated_and_unrelated_answer_keys_cannot_replace_settings(self):
        for base in ({"fuel_km_l": 0}, {"years": 1.5}, {"fuel_price": math.inf}, {"unexpected": 1}, []):
            with self.subTest(base=base), self.assertRaises(ValueError):
                build_guided_profile(self.answers(), base)
        result = build_guided_profile(self.answers(fuel_price=0, years=100), {"fuel_price": 35, "years": 7})
        self.assertEqual(result["profile"]["fuel_price"], 35)
        self.assertEqual(result["profile"]["years"], 7)


if __name__ == "__main__":
    unittest.main()
