"""Choice-first simulator workflows, with no network calls or automatic saves."""
from copy import deepcopy
from dataclasses import asdict
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from ev.engine import Ownership, Profile


APP = Path(__file__).resolve().parents[1] / "app.py"


class GuidedSimulatorTests(unittest.TestCase):
    def setUp(self):
        self.runtime = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"EV_FIT_RUNTIME_DIR": self.runtime.name,
                                          "OPENAI_API_KEY": "", "GEMINI_API_KEY": "", "GOOGLE_API_KEY": ""})
        self.env.start()
        self.provider = patch("ev.assistant.generate", side_effect=AssertionError("Guided UI must not call a model"))
        self.generate = self.provider.start()
        self.fresh_app()

    def tearDown(self):
        try:
            self.generate.assert_not_called()
            self.assertFalse(list(Path(self.runtime.name).rglob("*.sqlite*")))
        finally:
            self.provider.stop()
            self.env.stop()
            self.runtime.cleanup()

    def fresh_app(self):
        self.app = AppTest.from_file(str(APP), default_timeout=30).run()
        self.app.session_state["product_page"] = "生活適配試算"
        self.app.run()
        self.assertFalse(self.app.exception)

    def click(self, key):
        self.app.button(key=key).click().run()
        self.assertFalse(self.app.exception)

    def page(self, name):
        self.app.session_state["product_page"] = name
        self.app.run()
        self.assertFalse(self.app.exception)

    def finish(self, charging="home", trips="routine", distance="regular"):
        self.click(f"guided_distance_{distance}")
        self.click(f"guided_charging_{charging}")
        self.click(f"guided_trips_{trips}")
        self.assertEqual(self.app.session_state["_guided_step"], 3)
        return self.app.session_state["_saved_profile"]

    def text_content(self):
        return "\n".join(str(node.value) for kind in ("markdown", "caption", "info", "warning", "error", "text")
                         for node in getattr(self.app, kind))

    def test_initial_page_is_small_and_regular_mileage_is_an_explicit_value(self):
        self.assertEqual(self.app.session_state["_sim_mode"], "guided")
        self.assertEqual(len(self.app.number_input), 0)
        self.assertEqual(len(self.app.sidebar.number_input), 0)
        self.assertEqual(len(self.app.sidebar.slider), 0)
        self.assertEqual(len(self.app.slider), 1)
        self.assertEqual(self.app.slider[0].key, "guided_custom_distance_km")
        self.assertEqual(self.app.slider[0].value, 40)
        self.assertTrue(self.app.button(key="guided_step_1").disabled)
        self.assertTrue(self.app.button(key="guided_step_2").disabled)
        text = self.text_content()
        self.assertIn("40 公里", text)
        self.assertIn("5 個平日", text)
        self.assertFalse(self.app.metric)

    def test_three_choices_produce_home_routine_results_without_hidden_long_trips(self):
        profile = self.finish()
        self.assertEqual(profile["weekday_km"], 40)
        self.assertEqual(profile["weekend_km"], 0)
        self.assertEqual(profile["trips_per_month"], 0)
        self.assertEqual(profile["home_charging"], "yes")
        self.assertIs(profile["public_available"], False)
        self.assertEqual(profile["fuel_km_l"], 14)
        self.assertGreaterEqual(len(self.app.metric), 3)
        text = self.text_content()
        self.assertIn("油耗 14", text)
        self.assertIn("假設", text)
        self.assertIn("不從品牌或車齡推定", text)
        self.assertIn("尚未評估長途", text)
        self.assertEqual(self.app.session_state["llm_request_count"], 0)

    def test_public_unknown_and_unavailable_are_distinct_outcomes(self):
        for choice in ("public", "unknown", "unavailable"):
            with self.subTest(choice=choice):
                self.fresh_app()
                profile = self.finish(charging=choice)
                text = self.text_content()
                if choice == "public":
                    self.assertEqual(profile["home_charging"], "no")
                    self.assertIs(profile["public_available"], True)
                elif choice == "unknown":
                    self.assertEqual(profile["home_charging"], "unknown")
                    self.assertTrue(self.app.session_state["_guided_pending"])
                    self.assertIn("待確認", text)
                    self.assertIn("尚不能確認實際可行", text)
                    self.assertNotIn("此假設行程具備油轉電可行性", text)
                else:
                    self.assertEqual(profile["home_charging"], "no")
                    self.assertIs(profile["public_available"], False)
                    self.assertIn("需要調整", text)
                    self.assertEqual(self.app.metric[0].value, "暫不估算")

    def test_editing_third_step_updates_frequency_and_explicitly_clears_old_trip(self):
        profile = self.finish(trips="frequent")
        self.assertEqual((profile["weekend_km"], profile["trips_per_month"]), (200, 4))
        for choice, expected in (("monthly", 1), ("twice", 2), ("routine", 0), ("unknown", 0)):
            with self.subTest(choice=choice):
                self.click("guided_step_2")
                self.click(f"guided_trips_{choice}")
                self.assertEqual(self.app.session_state["_guided_step"], 3)
                current = self.app.session_state["_saved_profile"]
                self.assertEqual(current["trips_per_month"], expected)
                self.assertEqual(current["weekend_km"], 200 if expected else 0)
        self.assertTrue(any("週末" in item for item in self.app.session_state["_guided_pending"]))
        self.assertIn("尚不能確認實際可行", self.text_content())

    def test_back_and_cross_page_navigation_keep_choices_until_explicit_commit(self):
        self.click("guided_distance_far")
        self.click("guided_back")
        self.assertEqual(self.app.session_state["_guided_answers"]["distance"], "far")
        self.assertEqual(self.app.session_state["_guided_step"], 0)
        self.assertEqual(self.app.slider(key="guided_custom_distance_km").value, 120)
        self.click("guided_distance_far")
        self.click("guided_charging_public")
        before = deepcopy(self.app.session_state["_guided_answers"])
        self.page("問答助理")
        self.page("生活適配試算")
        self.assertEqual(self.app.session_state["_guided_step"], 2)
        self.assertEqual(self.app.session_state["_guided_answers"], before)
        self.click("guided_trips_routine")
        self.assertEqual(self.app.session_state["_saved_profile"]["weekday_km"], 120)
        self.assertEqual(self.app.session_state["_saved_profile"]["weekend_km"], 0)

    def test_fresh_choices_keep_existing_prices_fuel_years_and_ownership(self):
        base = asdict(Profile(fuel_km_l=18, years=7, home_price=4.5, public_price=13,
                              fuel_price=35, home_power_kw=8, public_hours=0.75))
        ownership = asdict(Ownership(ice_value=350000, ev_price=1280000, ice_insurance_year=16000))
        self.app.session_state["_saved_profile"] = base
        self.app.session_state["_saved_ownership"] = ownership
        self.app.run()
        current = self.finish()
        for field in ("fuel_km_l", "years", "home_price", "public_price", "fuel_price", "home_power_kw", "public_hours"):
            self.assertEqual(current[field], base[field])
        self.assertEqual(self.app.session_state["_saved_ownership"], ownership)
        self.assertIn("油耗 18", self.text_content())

    def test_advanced_exact_values_refresh_custom_sliders_and_single_stage_edits(self):
        self.app.slider(key="guided_custom_distance_km").set_value(67.0)
        self.click("guided_distance_apply")
        self.click("guided_charging_home")
        self.click("guided_trips_routine")
        self.click("guided_advanced")
        self.assertEqual(self.app.session_state["_sim_mode"], "advanced")
        self.app.slider(key="p_weekday_km").set_value(75.0)
        self.app.slider(key="p_fuel_km_l").set_value(12.0)
        self.app.slider(key="p_years").set_value(7)
        self.app.checkbox(key="cost_known_ice_value").check().run()
        self.assertFalse(self.app.exception)
        self.app.slider(key="o_ice_value").set_value(350000.0)
        self.app.checkbox(key="p_public_available").check().run()
        self.click("sim_back_to_quick")
        profile = self.app.session_state["_saved_profile"]
        self.assertEqual((profile["weekday_km"], profile["fuel_km_l"]), (75, 12))
        self.assertIs(profile["public_available"], True)
        self.assertEqual(self.app.session_state["_sim_mode"], "guided")
        self.click("guided_step_0")
        self.assertEqual(self.app.slider(key="guided_custom_distance_km").value, 75)
        self.click("guided_distance_regular")
        profile = self.app.session_state["_saved_profile"]
        self.assertEqual(profile["weekday_km"], 40)
        self.assertEqual(profile["fuel_km_l"], 12)
        self.assertEqual(profile["years"], 7)
        self.assertIs(profile["public_available"], True)
        self.assertEqual(self.app.session_state["_saved_ownership"]["ice_value"], 350000)
        self.assertEqual(self.app.session_state["_guided_step"], 3)

    def test_chat_handoff_remains_pending_in_advanced_and_keeps_precise_values(self):
        self.page("問答助理")
        self.app.chat_input[0].set_value("平日每天75公里，油耗12公里/公升，可以在家充電。").run()
        self.click("chat_to_sim")
        self.assertEqual(self.app.session_state["product_page"], "生活適配試算")
        self.assertEqual(self.app.session_state["_sim_mode"], "advanced")
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 40)
        self.assertEqual(self.app.session_state["intake_result"]["fields"]["weekday_km"], 75)
        next(button for button in self.app.button if button.label == "確認這些欄位並套用").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 75)
        self.assertEqual(self.app.slider(key="p_fuel_km_l").value, 12)
        self.click("sim_back_to_quick")
        self.assertEqual(self.app.session_state["_saved_profile"]["weekday_km"], 75)
        self.assertEqual(self.app.session_state["_saved_profile"]["fuel_km_l"], 12)

    def test_custom_trip_uses_latest_values_and_keeps_unconfirmed_edits_across_pages(self):
        self.app.slider(key="guided_custom_distance_km").set_value(75.0)
        self.click("guided_distance_apply")
        self.click("guided_charging_home")
        self.click("guided_trips_custom")
        self.app.slider(key="guided_custom_weekend_km").set_value(275.0)
        self.app.slider(key="guided_custom_trips_per_month").set_value(2.25)
        self.click("guided_trips_apply")
        profile = self.app.session_state["_saved_profile"]
        self.assertEqual((profile["weekday_km"], profile["weekend_km"], profile["trips_per_month"]), (75, 275, 2.25))
        self.click("guided_step_2")
        self.assertEqual(self.app.slider(key="guided_custom_weekend_km").value, 275)
        self.app.slider(key="guided_custom_weekend_km").set_value(399.0)
        self.page("問答助理")
        self.page("生活適配試算")
        self.assertEqual(self.app.slider(key="guided_custom_weekend_km").value, 399)
        self.assertEqual(self.app.session_state["_saved_profile"]["weekend_km"], 275)
        self.click("guided_trips_apply")
        self.assertEqual(self.app.session_state["_saved_profile"]["weekend_km"], 399)
        self.assertEqual(self.app.session_state["_saved_profile"]["trips_per_month"], 2.25)


if __name__ == "__main__":
    unittest.main()
