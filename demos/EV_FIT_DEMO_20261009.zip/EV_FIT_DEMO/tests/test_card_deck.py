"""Single-reply deck navigation must preserve data and never spend API calls."""
from copy import deepcopy
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from ev.llm import LLMConfig, ProviderError


APP = Path(__file__).resolve().parents[1] / "app.py"


class CardDeckTests(unittest.TestCase):
    def setUp(self):
        self.runtime = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"EV_FIT_RUNTIME_DIR": self.runtime.name, "OPENAI_API_KEY": "", "GEMINI_API_KEY": "", "GOOGLE_API_KEY": ""})
        self.env.start()
        self.network = patch("ev.assistant.generate", side_effect=AssertionError("Unexpected provider call during deck test"))
        self.generate = self.network.start()
        self.app = AppTest.from_file(str(APP), default_timeout=30).run()
        self.assertFalse(self.app.exception)

    def tearDown(self):
        self.network.stop()
        self.env.stop()
        self.runtime.cleanup()

    def ask(self, starter=0):
        self.app.button(key=f"starter_{starter}").click().run()
        self.assertFalse(self.app.exception)
        return self.app.session_state["chat_messages"][-1]["turn_id"]

    def move(self, direction):
        self.app.button(key=f"reply_{direction}").click().run()
        self.assertFalse(self.app.exception)

    def assert_position(self, position, total):
        self.assertTrue(any(f"第 {position} / {total} 張" in node.value for node in self.app.markdown))

    def assert_only_active_reply(self, turn_id):
        self.assertEqual(self.app.session_state["_active_reply_id"], turn_id)
        self.assertEqual(len(self.app.chat_message), 1)
        self.assertEqual(self.app.chat_message[0].name, "assistant")
        for kind in ("slider", "radio", "multiselect"):
            for widget in getattr(self.app, kind):
                if widget.key and widget.key.startswith("explore_"):
                    self.assertTrue(widget.key.startswith(f"explore_{turn_id}_"), widget.key)

    def test_three_replies_show_latest_then_previous_with_only_one_card(self):
        first, second, third = self.ask(0), self.ask(1), self.ask(2)
        self.assert_position(3, 3)
        self.assert_only_active_reply(third)
        self.assertTrue(self.app.button(key="reply_next").disabled)
        self.assertFalse(self.app.button(key="reply_previous").disabled)
        self.move("previous")
        self.assert_position(2, 3)
        self.assert_only_active_reply(second)
        self.assertEqual([node.value for node in self.app.text], [self.app.session_state["chat_messages"][2]["content"]])
        self.move("previous")
        self.assert_only_active_reply(first)
        self.assertTrue(self.app.button(key="reply_previous").disabled)
        self.move("next")
        self.move("next")
        self.assert_only_active_reply(third)
        self.generate.assert_not_called()

    def test_pagination_preserves_full_context_and_api_budget(self):
        self.ask(0)
        self.ask(1)
        self.ask(3)
        history = deepcopy(self.app.session_state["chat_messages"])
        self.app.session_state["answer_mode"] = "llm"
        self.app.session_state["_active_llm"] = LLMConfig(api_key="unit-test-placeholder")
        self.app.session_state["llm_request_count"] = 8
        self.app.session_state["llm_total_estimated_usd"] = 0.04
        self.app.run()
        self.move("previous")
        self.move("previous")
        self.move("next")
        self.assertEqual(self.app.session_state["chat_messages"], history)
        self.assertEqual(self.app.session_state["llm_request_count"], 8)
        self.assertEqual(self.app.session_state["llm_total_estimated_usd"], 0.04)
        self.generate.assert_not_called()

    def test_same_type_card_values_survive_widget_cleanup_and_page_switch(self):
        first = self.ask(1)
        self.app.slider(key=f"explore_{first}_monthly_km").set_value(2500).run()
        second = self.ask(1)
        self.app.slider(key=f"explore_{second}_monthly_km").set_value(900).run()
        self.move("previous")
        self.assertEqual(self.app.slider(key=f"explore_{first}_monthly_km").value, 2500)
        self.app.session_state["product_page"] = "生活適配試算"
        self.app.run()
        self.app.session_state["product_page"] = "問答助理"
        self.app.run()
        self.assert_only_active_reply(first)
        self.assertEqual(self.app.slider(key=f"explore_{first}_monthly_km").value, 2500)
        self.move("next")
        self.assertEqual(self.app.slider(key=f"explore_{second}_monthly_km").value, 900)
        self.generate.assert_not_called()

    def test_truncation_keeps_ten_replies_and_their_stable_ids(self):
        first = self.ask(0)
        second = self.ask(0)
        self.app.slider(key=f"explore_{second}_weekday_km").set_value(85).run()
        for _ in range(9):
            latest = self.ask(0)
        messages = self.app.session_state["chat_messages"]
        ids = [message["turn_id"] for message in messages if message["role"] == "assistant"]
        self.assertEqual(len(messages), 20)
        self.assertEqual(len(set(ids)), 10)
        self.assertNotIn(first, ids)
        self.assertEqual(ids[0], second)
        self.assert_only_active_reply(latest)
        self.assert_position(10, 10)
        for _ in range(9):
            self.move("previous")
        self.assert_only_active_reply(second)
        self.assert_position(1, 10)
        self.assertEqual(self.app.slider(key=f"explore_{second}_weekday_km").value, 85)
        self.assertNotIn(first, self.app.session_state["_explore_state"])

    def test_new_success_jumps_to_latest_and_provider_failure_keeps_selection(self):
        first = self.ask(0)
        self.ask(1)
        self.move("previous")
        self.assert_only_active_reply(first)
        latest = self.ask(2)
        self.assert_only_active_reply(latest)
        self.assert_position(3, 3)
        self.move("previous")
        selected = self.app.session_state["_active_reply_id"]
        history = deepcopy(self.app.session_state["chat_messages"])
        self.app.session_state["answer_mode"] = "llm"
        self.app.session_state["_active_llm"] = LLMConfig(api_key="unit-test-placeholder")
        self.app.run()
        with patch("ev.assistant.generate", side_effect=ProviderError("測試用模型逾時")) as provider:
            self.app.button(key="starter_0").click().run()
        self.assertFalse(self.app.exception)
        provider.assert_called_once()
        self.assert_only_active_reply(selected)
        self.assertEqual(self.app.session_state["chat_messages"], history)
        self.assert_position(2, 3)
        self.assertEqual(self.app.session_state["llm_request_count"], 1)

    def test_clear_resets_deck_but_not_model_budget(self):
        self.ask(0)
        self.ask(1)
        self.move("previous")
        self.app.session_state["llm_request_count"] = 12
        self.app.button(key="clear_chat").click().run()
        self.assertFalse(self.app.exception)
        self.assertIsNone(self.app.session_state["_active_reply_id"])
        self.assertEqual(self.app.session_state["chat_messages"], [])
        self.assertEqual(len(self.app.chat_message), 0)
        self.assertFalse(any(button.key in {"reply_previous", "reply_next"} for button in self.app.button))
        self.assertEqual(self.app.session_state["llm_request_count"], 12)
        latest = self.ask(1)
        self.assert_only_active_reply(latest)
        self.assert_position(1, 1)
        self.assertTrue(self.app.button(key="reply_previous").disabled)
        self.assertTrue(self.app.button(key="reply_next").disabled)


if __name__ == "__main__":
    unittest.main()
