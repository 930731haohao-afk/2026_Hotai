"""Provider protocol tests with bounded fake HTTP responses; never call real APIs."""

import io
import json
import socket
import unittest
from unittest.mock import Mock, patch
from urllib.error import HTTPError, URLError

from ev.llm import DEFAULT_MODELS, LLMConfig, MAX_ANSWER_CHARS, MAX_RESPONSE_BYTES, ProviderError, _NoRedirect, generate


MESSAGES = [{"role": "system", "content": "依 TW-SPEC 回答。"}, {"role": "user", "content": "我能用家充嗎？"}]
ANSWER = {"answer": "請先確認供電與安裝條件。", "source_ids": ["TW-SPEC"], "follow_up": "已向管委會確認了嗎？"}
# Deliberately invalid fixture; never sent to a real service.
SECRET = "not-a-key"


def response_for(provider, answer=None):
    text = json.dumps(ANSWER if answer is None else answer, ensure_ascii=False)
    if provider == "openai":
        return {"status": "completed", "output": [{"type": "message", "role": "assistant", "status": "completed", "content": [{"type": "output_text", "text": text}]}], "usage": {"input_tokens": 1000, "output_tokens": 200}}
    if provider == "gemini":
        return {"candidates": [{"finishReason": "STOP", "content": {"role": "model", "parts": [{"text": text}]}}], "usageMetadata": {"promptTokenCount": 1000, "candidatesTokenCount": 180, "thoughtsTokenCount": 20}}
    return {"done": True, "done_reason": "stop", "message": {"role": "assistant", "content": text}, "prompt_eval_count": 1000, "eval_count": 200}


class FakeResponse:
    def __init__(self, data, status=200, url=None, headers=None):
        self.body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.status, self.url = status, url
        self.headers = headers or {}
        self.read_limits = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def getcode(self):
        return self.status

    def geturl(self):
        return self.url

    def read(self, limit):
        self.read_limits.append(limit)
        return self.body[:limit]


class ProviderTests(unittest.TestCase):
    def call(self, provider="openai", data=None, config=None, status=200, headers=None, response_url=None):
        self.response = FakeResponse(response_for(provider) if data is None else data, status, response_url, headers)
        self.opener = Mock()

        def open_response(request, timeout):
            self.request, self.timeout = request, timeout
            if self.response.url is None:
                self.response.url = request.full_url
            return self.response

        self.opener.open.side_effect = open_response
        with patch("ev.llm.build_opener", return_value=self.opener) as factory:
            result = generate(MESSAGES, config or LLMConfig(provider=provider, api_key=SECRET))
            self.handlers = factory.call_args.args
        self.payload = json.loads(self.request.data)
        return result

    def test_openai_protocol_schema_and_price(self):
        result = self.call()
        self.assertEqual(result["answer"], ANSWER["answer"])
        self.assertEqual(result["usage"], {"input_tokens": 1000, "output_tokens": 200})
        self.assertAlmostEqual(result["estimated_cost_usd"], 0.00165)
        self.assertEqual(self.request.full_url, "https://api.openai.com/v1/responses")
        self.assertEqual(self.request.get_method(), "POST")
        self.assertEqual(self.request.get_header("Authorization"), "Bearer " + SECRET)
        self.assertNotIn(SECRET, self.request.data.decode("utf-8"))
        self.assertFalse(self.payload["store"])
        self.assertEqual(self.payload["reasoning"], {"effort": "none"})
        self.assertEqual(self.payload["max_output_tokens"], 1000)
        schema = self.payload["text"]["format"]
        self.assertTrue(schema["strict"])
        self.assertEqual(schema["type"], "json_schema")
        self.assertFalse(schema["schema"]["additionalProperties"])
        self.assertEqual(set(schema["schema"]["required"]), set(ANSWER))
        self.assertEqual(self.timeout, 25)
        self.opener.open.assert_called_once()
        self.assertEqual(self.response.read_limits, [MAX_RESPONSE_BYTES + 1])

    def test_gemini_protocol_converts_roles_and_hides_key_from_url(self):
        messages = [{"role": "system", "content": "系統規則"}, {"role": "user", "content": "上一題"}, {"role": "assistant", "content": "上一答"}, {"role": "user", "content": "下一題"}]
        response = FakeResponse(response_for("gemini"))
        opener = Mock()

        def open_response(request, timeout):
            self.request = request
            response.url = request.full_url
            return response

        opener.open.side_effect = open_response
        with patch("ev.llm.build_opener", return_value=opener):
            result = generate(messages, LLMConfig(provider="gemini", api_key=SECRET))
        payload = json.loads(self.request.data)
        self.assertEqual([item["role"] for item in payload["contents"]], ["user", "model", "user"])
        self.assertIn("系統規則", payload["systemInstruction"]["parts"][0]["text"])
        self.assertEqual(payload["generationConfig"]["responseFormat"]["text"]["mimeType"], "APPLICATION_JSON")
        self.assertEqual(payload["generationConfig"]["maxOutputTokens"], 1000)
        self.assertEqual(self.request.get_header("X-goog-api-key"), SECRET)
        self.assertNotIn(SECRET, self.request.full_url)
        self.assertTrue(self.request.full_url.endswith("/gemini-3.5-flash-lite:generateContent"))
        self.assertEqual(result["usage"]["output_tokens"], 200)
        self.assertIsNone(result["estimated_cost_usd"])

    def test_ollama_is_local_nonstreaming_and_bounded(self):
        result = self.call("ollama", config=LLMConfig(provider="ollama"))
        self.assertEqual(self.request.full_url, "http://127.0.0.1:11434/api/chat")
        self.assertIsNone(self.request.get_header("Authorization"))
        self.assertFalse(self.payload["stream"])
        self.assertFalse(self.payload["think"])
        self.assertEqual(self.payload["options"]["num_predict"], 1000)
        self.assertEqual(self.payload["options"]["num_ctx"], 8192)
        self.assertEqual(self.payload["format"]["type"], "object")
        self.assertEqual(result["source_ids"], ["TW-SPEC"])
        self.assertIsNone(result["estimated_cost_usd"])

    def test_unknown_model_has_no_price_or_unsupported_reasoning_setting(self):
        result = self.call(config=LLMConfig(model="custom-model", api_key=SECRET))
        self.assertIsNone(result["estimated_cost_usd"])
        self.assertNotIn("reasoning", self.payload)

    def test_missing_usage_is_unknown_not_zero(self):
        response = response_for("openai")
        del response["usage"]
        result = self.call(data=response)
        self.assertEqual(result["usage"], {"input_tokens": None, "output_tokens": None})
        self.assertIsNone(result["estimated_cost_usd"])

    def test_http_errors_are_safe_and_never_retried(self):
        for status in (400, 401, 403, 404, 429, 500, 302):
            with self.subTest(status=status):
                opener = Mock()
                opener.open.side_effect = HTTPError("https://provider.invalid/" + SECRET, status, SECRET, {}, io.BytesIO(SECRET.encode()))
                with patch("ev.llm.build_opener", return_value=opener):
                    with self.assertRaises(ProviderError) as raised:
                        generate(MESSAGES, LLMConfig(api_key=SECRET))
                self.assertNotIn(SECRET, str(raised.exception))
                self.assertIsNone(raised.exception.__cause__)
                self.assertTrue(raised.exception.__suppress_context__)
                opener.open.assert_called_once()

    def test_timeout_connection_failure_and_disconnect_are_sanitized(self):
        for error in (socket.timeout(SECRET), TimeoutError(SECRET), URLError(socket.timeout(SECRET)), URLError(SECRET), ConnectionError(SECRET)):
            with self.subTest(error=type(error).__name__):
                opener = Mock()
                opener.open.side_effect = error
                with patch("ev.llm.build_opener", return_value=opener):
                    with self.assertRaises(ProviderError) as raised:
                        generate(MESSAGES, LLMConfig(api_key=SECRET))
                self.assertNotIn(SECRET, str(raised.exception))
                opener.open.assert_called_once()

    def test_non_200_status_cannot_look_like_success(self):
        for status in (201, 204, 302, 401, 429):
            with self.subTest(status=status), self.assertRaises(ProviderError):
                self.call(status=status)

    def test_no_redirect_handler_or_environment_proxy(self):
        self.call()
        self.assertTrue(any(isinstance(handler, _NoRedirect) for handler in self.handlers))
        self.assertEqual(self.handlers[0].proxies, {})
        self.assertIsNone(_NoRedirect().redirect_request(self.request, None, 302, SECRET, {}, "https://example.com/"))
        with self.assertRaises(ProviderError):
            self.call(response_url="https://example.com/")

    def test_malformed_empty_oversized_duplicate_and_nonfinite_json(self):
        for raw in (b"", b"not json", b"[]", b"\xff", b'{"status":"completed","status":"incomplete"}', b'{"error":NaN}', b" " * (MAX_RESPONSE_BYTES + 1)):
            with self.subTest(length=len(raw)), self.assertRaises(ProviderError):
                self.call(data=raw)
        for length in (str(MAX_RESPONSE_BYTES + 1), "-1", "bad-length"):
            with self.subTest(length=length), self.assertRaises(ProviderError):
                self.call(headers={"Content-Length": length})

    def test_openai_incomplete_refusal_and_empty_response_are_rejected(self):
        response = response_for("openai")
        for status in ("incomplete", "failed", "queued", None):
            response["status"] = status
            with self.subTest(status=status), self.assertRaises(ProviderError):
                self.call(data=response)
        response = response_for("openai")
        response["output"][0]["content"] = [{"type": "refusal", "refusal": SECRET}]
        with self.assertRaises(ProviderError) as raised:
            self.call(data=response)
        self.assertNotIn(SECRET, str(raised.exception))
        response["output"] = []
        with self.assertRaises(ProviderError):
            self.call(data=response)

    def test_gemini_max_tokens_blocked_and_bad_parts_are_rejected(self):
        for finish in ("MAX_TOKENS", "SAFETY", "OTHER", None):
            response = response_for("gemini")
            response["candidates"][0]["finishReason"] = finish
            with self.subTest(finish=finish), self.assertRaises(ProviderError):
                self.call("gemini", response)
        with self.assertRaises(ProviderError):
            self.call("gemini", {"promptFeedback": {"blockReason": SECRET}})
        response = response_for("gemini")
        response["candidates"][0]["content"]["parts"] = [{"functionCall": {"name": "fake"}}]
        with self.assertRaises(ProviderError):
            self.call("gemini", response)

    def test_ollama_incomplete_and_tools_are_rejected(self):
        for done, reason in ((False, "stop"), (True, "length"), (True, None)):
            response = response_for("ollama")
            response.update(done=done, done_reason=reason)
            with self.subTest(done=done, reason=reason), self.assertRaises(ProviderError):
                self.call("ollama", response)
        response = response_for("ollama")
        response["message"]["tool_calls"] = [{"function": {"name": "fake"}}]
        with self.assertRaises(ProviderError):
            self.call("ollama", response)

    def test_structured_output_must_match_schema_exactly(self):
        invalid = [None, [], {**ANSWER, "extra": SECRET}, {"answer": "答覆", "source_ids": []},
                   {**ANSWER, "answer": " "}, {**ANSWER, "answer": 1}, {**ANSWER, "answer": "x" * (MAX_ANSWER_CHARS + 1)},
                   {**ANSWER, "follow_up": None}, {**ANSWER, "follow_up": "x" * 1001},
                   {**ANSWER, "source_ids": "TW-SPEC"}, {**ANSWER, "source_ids": [123]},
                   {**ANSWER, "source_ids": ["https://evil.invalid"]}, {**ANSWER, "source_ids": ["<script>"]},
                   {**ANSWER, "source_ids": ["ID"] * 21}]
        for answer in invalid:
            response = response_for("openai")
            response["output"][0]["content"][0]["text"] = json.dumps(answer)
            with self.subTest(type=type(answer).__name__), self.assertRaises(ProviderError) as raised:
                self.call(data=response)
            self.assertNotIn(SECRET, str(raised.exception))

    def test_invalid_usage_types_are_rejected(self):
        for usage in ([], "invalid", {"input_tokens": True}, {"input_tokens": -1}, {"output_tokens": 2.3}):
            response = response_for("openai")
            response["usage"] = usage
            with self.subTest(usage=usage), self.assertRaises(ProviderError):
                self.call(data=response)

    def test_config_repr_never_contains_key_and_unsafe_config_is_rejected(self):
        self.assertNotIn(SECRET, repr(LLMConfig(api_key=SECRET)))
        self.assertEqual(LLMConfig(provider="gemini").model, DEFAULT_MODELS["gemini"])
        for kwargs in ({"provider": "other"}, {"model": "https://evil.invalid"}, {"model": "../../evil"},
                       {"provider": "gemini", "model": "model:generateContent?key=bad"},
                       {"api_key": "bad\nkey"}, {"api_key": None}, {"timeout": 0}, {"timeout": float("nan")},
                       {"max_output_tokens": True}, {"max_output_tokens": 999999},
                       {"provider": "ollama", "model": "gpt-oss:120b-cloud"}, {"provider": "ollama", "model": "model:cloud"}):
            with self.subTest(keys=list(kwargs)), self.assertRaises(ProviderError):
                LLMConfig(**kwargs)

    def test_missing_key_and_invalid_messages_do_not_open_network(self):
        with patch("ev.llm.build_opener") as factory:
            with self.assertRaises(ProviderError):
                generate(MESSAGES, LLMConfig())
            invalid = [[], [{"role": "tool", "content": "x"}], [{"role": "user", "content": ""}],
                       [{"role": "user", "content": "x", "extra": "y"}], [{"role": "user", "content": "x" * 30001}],
                       [{"role": "assistant", "content": "x"}], [{"role": "user", "content": "x"}, {"role": "system", "content": "x"}]]
            for messages in invalid:
                with self.subTest(messages=len(messages)), self.assertRaises(ProviderError):
                    generate(messages, LLMConfig(api_key=SECRET))
            factory.assert_not_called()


if __name__ == "__main__":
    unittest.main()
