"""Verify meaningful interactive-card flows without contacting a model."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

APP = Path(__file__).resolve().parents[1] / "app.py"


class InteractiveFlowTests(unittest.TestCase):
    def setUp(self):
        self.runtime = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"EV_FIT_RUNTIME_DIR": self.runtime.name})
        self.env.start()
        self.app = AppTest.from_file(str(APP), default_timeout=30).run()
        self.assertFalse(self.app.exception)

    def tearDown(self):
        self.env.stop()
        self.runtime.cleanup()

    def ask_starter(self, index):
        self.app.button(key=f"starter_{index}").click().run()
        self.assertFalse(self.app.exception)
        return self.app.session_state["chat_messages"][-1]["turn_id"]

    def test_energy_slider_changes_cost_without_question_or_llm(self):
        turn = self.ask_starter(1)
        first = next(m.value for m in self.app.metric if m.label == "每月電費")
        with patch("ev.assistant.generate") as generate:
            self.app.slider(key=f"explore_{turn}_monthly_km").set_value(3000).run()
        self.assertFalse(self.app.exception)
        generate.assert_not_called()
        second = next(m.value for m in self.app.metric if m.label == "每月電費")
        self.assertNotEqual(first, second)
        self.assertEqual(len(self.app.session_state["chat_messages"]), 2)
        self.assertEqual(self.app.session_state["llm_request_count"], 0)

    def test_charging_handoff_is_pending_until_explicit_confirmation(self):
        turn = self.ask_starter(0)
        self.app.slider(key=f"explore_{turn}_weekday_km").set_value(75)
        self.app.radio(key=f"explore_{turn}_home_choice").set_value("yes").run()
        self.assertEqual(next(m.value for m in self.app.metric if m.label == "公共充電"), "0 次")
        self.app.button(key=f"explore_{turn}_handoff").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 40)
        self.assertEqual(self.app.session_state["intake_result"]["fields"]["weekday_km"], 75)
        next(b for b in self.app.button if b.label == "確認這些欄位並套用").click().run()
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 75)
        self.assertEqual(self.app.slider(key="p_weekend_km").value, 0)

    def test_independent_turn_values_survive_switching_pages(self):
        first = self.ask_starter(1)
        self.app.slider(key=f"explore_{first}_monthly_km").set_value(2500).run()
        second = self.ask_starter(1)
        self.assertNotEqual(first, second)
        self.assertEqual(self.app.slider(key=f"explore_{second}_monthly_km").value, 1500)
        self.app.session_state["product_page"] = "生活適配試算"
        self.app.run()
        self.app.session_state["product_page"] = "問答助理"
        self.app.run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key=f"explore_{second}_monthly_km").value, 1500)
        self.app.button(key="reply_previous").click().run()
        self.assertEqual(self.app.slider(key=f"explore_{first}_monthly_km").value, 2500)
        self.assertFalse(any(s.key == f"explore_{second}_monthly_km" for s in self.app.slider))

    def test_fast_slider_then_handoff_uses_latest_event_value(self):
        turn = self.ask_starter(0)
        self.app.slider(key=f"explore_{turn}_weekday_km").set_value(165)
        self.app.radio(key=f"explore_{turn}_home_choice").set_value("no")
        self.app.button(key=f"explore_{turn}_handoff").click().run()
        self.assertFalse(self.app.exception)
        pending = self.app.session_state["intake_result"]["fields"]
        self.assertEqual(pending["weekday_km"], 165)
        self.assertEqual(pending["home_charging"], "no")
        self.app.session_state["product_page"] = "問答助理"
        self.app.run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key=f"explore_{turn}_weekday_km").value, 165)

    def test_sourced_topic_without_special_card_does_not_claim_no_evidence(self):
        self.app.chat_input[0].set_value("電池壽命和保固差在哪？").run()
        self.assertFalse(self.app.exception)
        self.assertTrue(self.app.session_state["chat_messages"][-1]["result"]["sources"])
        self.assertFalse(any("缺少足夠證據" in x.value for x in self.app.info))

    def test_followup_button_adds_exactly_one_user_turn(self):
        turn = self.ask_starter(0)
        self.app.button(key=f"explore_{turn}_ask_0").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(len(self.app.session_state["chat_messages"]), 4)
        self.app.run()
        self.assertEqual(len(self.app.session_state["chat_messages"]), 4)

    def test_vehicle_selection_and_zero_interest_loan(self):
        turn = self.ask_starter(2)
        self.app.multiselect(key=f"explore_{turn}_vehicle_types").set_value(["HEV", "PHEV"]).run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.session_state["_explore_state"][turn]["vehicle_types"], ["HEV", "PHEV"])
        loan = self.ask_starter(3)
        self.app.slider(key=f"explore_{loan}_interest").set_value(0.0).run()
        self.assertFalse(self.app.exception)
        self.assertEqual(next(m.value for m in self.app.metric if m.label == "目前 60 個月 · 每月還款"), "NT$ 10,000")

    def test_clearing_conversation_clears_cards_not_call_budget(self):
        self.ask_starter(1)
        self.app.session_state["llm_request_count"] = 9
        self.app.button(key="clear_chat").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.session_state["_explore_state"], {})
        self.assertEqual(self.app.session_state["llm_request_count"], 9)


if __name__ == "__main__":
    unittest.main()
