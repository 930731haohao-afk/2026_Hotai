"""User-visible cross-page flows. All provider work uses explicit test doubles."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

from ev.llm import LLMConfig, ProviderError

APP = Path(__file__).resolve().parents[1] / "app.py"


class ChatFlowTests(unittest.TestCase):
    def setUp(self):
        self.runtime = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"EV_FIT_RUNTIME_DIR": self.runtime.name, "OPENAI_API_KEY": "", "GEMINI_API_KEY": "", "GOOGLE_API_KEY": ""})
        self.env.start()
        self.app = AppTest.from_file(str(APP), default_timeout=30).run()
        self.assertFalse(self.app.exception)

    def tearDown(self):
        self.env.stop()
        self.runtime.cleanup()

    def page(self, name):
        self.app.session_state["product_page"] = name
        if name == "生活適配試算":
            self.app.session_state["_sim_mode"] = "advanced"
        self.app.run()
        self.assertFalse(self.app.exception)

    def test_default_chat_has_no_long_form_and_starter_retrieves_sources(self):
        self.assertEqual(len(self.app.number_input), 0)
        with patch("ev.assistant.generate") as generate:
            self.app.button(key="starter_0").click().run()
        self.assertFalse(self.app.exception)
        generate.assert_not_called()
        messages = self.app.session_state["chat_messages"]
        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[-1]["result"]["mode"], "preview")
        self.assertTrue(messages[-1]["result"]["sources"])
        self.assertFalse(list(Path(self.runtime.name).glob("*.sqlite3")))

    def test_chat_and_actual_profile_survive_round_trip(self):
        self.app.button(key="starter_1").click().run()
        self.page("生活適配試算")
        self.app.slider(key="p_weekday_km").set_value(75)
        self.app.checkbox(key="cost_known_ice_value").check().run()
        self.app.slider(key="o_ice_value").set_value(300000).run()
        self.page("問答助理")
        self.assertEqual(len(self.app.session_state["chat_messages"]), 2)
        self.page("生活適配試算")
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 75)
        self.assertEqual(self.app.slider(key="o_ice_value").value, 300000)

    def test_handoff_requires_confirmation_and_can_apply_chat_details(self):
        self.app.chat_input[0].set_value("平日每天60公里，週末300公里，每月2趟，油耗12公里/公升，可以在家充電。").run()
        self.app.button(key="chat_to_sim").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.session_state["product_page"], "生活適配試算")
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 40)
        confirm = next(b for b in self.app.button if b.label == "確認這些欄位並套用")
        confirm.click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 60)
        self.assertEqual(self.app.selectbox(key="p_home_charging").value, "yes")

    def test_missing_key_and_invalid_model_stay_in_preview(self):
        self.app.button(key="enable_llm").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.session_state["answer_mode"], "preview")
        self.assertTrue(any("尚未提供" in e.value for e in self.app.error))
        self.app.text_input(key="llm_api_key").set_value("unit-test-placeholder")
        self.app.text_input(key="llm_model_openai").set_value("https://example.com/")
        self.app.button(key="enable_llm").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.session_state["answer_mode"], "preview")

    def test_configuring_model_does_not_call_it_and_failure_is_not_preview(self):
        self.app.text_input(key="llm_api_key").set_value("unit-test-placeholder")
        with patch("ev.assistant.generate") as generate:
            self.app.button(key="enable_llm").click().run()
        generate.assert_not_called()
        self.assertEqual(self.app.session_state["answer_mode"], "llm")
        self.assertEqual(self.app.text_input(key="llm_api_key").value, "")
        with patch("ev.assistant.generate", side_effect=ProviderError("模型服務回覆逾時")):
            self.app.button(key="starter_0").click().run()
        self.assertFalse(self.app.exception)
        self.assertTrue(any("逾時" in e.value for e in self.app.error))
        self.assertEqual(len(self.app.session_state["chat_messages"]), 0)
        self.assertEqual(self.app.session_state["answer_mode"], "llm")
        self.assertEqual(self.app.session_state["llm_request_count"], 1)

    def test_clear_chat_does_not_bypass_call_cap(self):
        self.app.session_state["_active_llm"] = LLMConfig(api_key="unit-test-placeholder")
        self.app.session_state["answer_mode"] = "llm"
        self.app.session_state["llm_request_count"] = 30
        self.app.run()
        self.app.button(key="clear_chat").click().run()
        with patch("ev.assistant.generate") as generate:
            self.app.button(key="starter_0").click().run()
        generate.assert_not_called()
        self.assertEqual(self.app.session_state["llm_request_count"], 30)
        self.assertTrue(any("上限" in e.value for e in self.app.error))


if __name__ == "__main__":
    unittest.main()
