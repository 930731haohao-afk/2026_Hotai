"""Integration tests exercise real Streamlit callbacks and rendered results."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from streamlit.testing.v1 import AppTest

APP = Path(__file__).resolve().parents[1] / "app.py"


class AppFlowTests(unittest.TestCase):
    def setUp(self):
        self.runtime = tempfile.TemporaryDirectory()
        self.env = patch.dict(os.environ, {"EV_FIT_RUNTIME_DIR": self.runtime.name})
        self.env.start()
        self.app = AppTest.from_file(str(APP), default_timeout=30).run()
        self.assertFalse(self.app.exception)
        self.app.session_state["product_page"] = "生活適配試算"
        self.app.session_state["_sim_mode"] = "advanced"
        self.app.run()
        self.assertFalse(self.app.exception)

    def tearDown(self):
        self.env.stop()
        self.runtime.cleanup()

    def button(self, label):
        return next(x for x in self.app.button if x.label == label)

    def test_default_scenarios_and_no_false_savings(self):
        self.assertEqual(self.app.metric[0].value, "NT$ 661")
        self.assertFalse(list(Path(self.runtime.name).glob("*.sqlite3")))
        self.app.button(key="demo_home").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.selectbox(key="p_home_charging").value, "yes")
        self.assertEqual(self.app.metric[1].value, "0 分鐘")
        self.app.button(key="demo_challenge").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.metric[0].value, "暫不估算")

    def test_intake_requires_confirmation_and_applies_fields(self):
        self.app.text_area[0].set_value("平日每天60公里，週末300公里，每月2趟，油耗12公里/公升，可以在家充電。")
        self.button("擷取可辨識欄位").click().run()
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 40)
        self.button("確認這些欄位並套用").click().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="p_weekday_km").value, 60)
        self.assertEqual(self.app.selectbox(key="p_home_charging").value, "yes")
        self.assertEqual(self.app.metric[3].value, "22,800 km")

    def test_zero_mileage_and_infeasible_public_access(self):
        self.app.slider(key="p_weekday_km").set_value(0)
        self.app.slider(key="p_trips_per_month").set_value(0).run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.metric[0].value, "NT$ 0")
        self.app.slider(key="p_weekday_km").set_value(100)
        self.app.checkbox(key="p_public_available").uncheck().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.metric[0].value, "暫不估算")

    def test_ownership_zero_inputs_count_and_save_is_explicit(self):
        for widget in self.app.checkbox:
            if widget.key and widget.key.startswith("cost_known_"):
                widget.check()
        self.app.run()
        for widget in self.app.slider:
            if widget.key and widget.key.startswith("o_"):
                widget.set_value(0)
        self.app.run()
        self.assertFalse(self.app.exception)
        self.assertTrue(any(x.label == "油車持有成本" for x in self.app.metric))
        self.button("儲存這次試算").click().run()
        self.assertFalse(self.app.exception)
        self.assertTrue(Path(self.runtime.name, "reports.sqlite3").exists())
        self.assertTrue(any("已儲存" in x.value for x in self.app.success))

    def test_optional_cost_can_return_to_unknown_and_restore_last_amount(self):
        self.assertIsNone(self.app.session_state["o_ice_value"])
        self.app.checkbox(key="cost_known_ice_value").check().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="o_ice_value").value, 0)
        self.app.slider(key="o_ice_value").set_value(300000).run()
        self.app.checkbox(key="cost_known_ice_value").uncheck().run()
        self.assertFalse(self.app.exception)
        self.assertIsNone(self.app.session_state["o_ice_value"])
        self.assertFalse(any(widget.key == "o_ice_value" for widget in self.app.slider))
        self.assertFalse(any(metric.label == "油車持有成本" for metric in self.app.metric))
        self.app.checkbox(key="cost_known_ice_value").check().run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="o_ice_value").value, 300000)

    def test_saved_large_amount_and_years_are_not_truncated_by_slider_ranges(self):
        self.app.session_state["product_page"] = "問答助理"
        self.app.run()
        self.app.session_state["_saved_ownership"] = {"ev_price": 6250000.0}
        self.app.session_state["_saved_profile"] = {"years": 20}
        self.app.session_state["product_page"] = "生活適配試算"
        self.app.run()
        self.assertFalse(self.app.exception)
        self.assertEqual(self.app.slider(key="o_ev_price").value, 6250000)
        self.assertEqual(self.app.slider(key="p_years").value, 20)


if __name__ == "__main__":
    unittest.main()
