import json
from pathlib import Path
import tempfile
import unittest

from ev.intake import parse_description
from ev.reports import build_html, build_markdown
from ev.storage import Store


class IntakeTests(unittest.TestCase):
    def test_supported_sample_preserves_unknown_charging(self):
        parsed = parse_description("平日每天40公里，週末200公里，每月4趟，油耗14公里/公升，有車位但不確定能不能裝家充")
        self.assertEqual(parsed["fields"], {"weekday_km": 40, "weekend_km": 200, "trips_per_month": 4, "fuel_km_l": 14, "home_charging": "unknown"})
        self.assertTrue(any("尚未套用" in note for note in parsed["notes"]))

    def test_parking_does_not_prove_charging(self):
        self.assertNotIn("home_charging", parse_description("有車位")['fields'])

    def test_negated_and_hypothetical_availability(self):
        for text in ["不能裝家充", "不可裝家充", "不可以裝家充", "沒有家充", "無法在家充電"]:
            with self.subTest(text=text):
                self.assertEqual(parse_description(text)["fields"].get("home_charging"), "no")
        for text in ["如果可以裝家充", "可能可以裝家充", "家充尚未確認", "不確定能不能裝家充"]:
            with self.subTest(text=text):
                self.assertEqual(parse_description(text)["fields"].get("home_charging"), "unknown")
        for text in ["已裝家充", "可裝家充", "可以在家充電", "已安裝家用充電樁"]:
            with self.subTest(text=text):
                self.assertEqual(parse_description(text)["fields"].get("home_charging"), "yes")

    def test_conflicts_remain_unfilled(self):
        parsed = parse_description("平日每天40公里，但工作日每天60公里；可以裝家充，不能裝家充")
        self.assertNotIn("weekday_km", parsed["fields"])
        self.assertNotIn("home_charging", parsed["fields"])
        self.assertTrue(any("不同數值" in note for note in parsed["notes"]))

    def test_units_are_not_converted_by_guessing(self):
        self.assertNotIn("fuel_km_l", parse_description("油耗7公升/100公里")["fields"])
        self.assertNotIn("weekend_km", parse_description("週末每天200公里")["fields"])
        self.assertEqual(parse_description("家充可用6.5小時")["fields"]["home_hours"], 6.5)

    def test_values_outside_form_limits_are_not_applied(self):
        parsed = parse_description("平日5000公里，週末1600公里，每月6趟，油耗0公里/公升，家充100小時")
        self.assertEqual(parsed["fields"], {})
        self.assertEqual(sum("須介於" in note for note in parsed["notes"]), 5)
        boundary = parse_description("平日500公里，週末1500公里，每月4.33趟，油耗50公里/公升，家充24小時")
        self.assertEqual(len(boundary["fields"]), 5)


class ReportTests(unittest.TestCase):
    def setUp(self):
        self.profile = {"weekday_km": 40, "home_charging": "unknown", "ownership": {"years": 5}}
        self.result = {
            "annual_km": 20000, "monthly_ice_energy": 3500,
            "monthly_ev_energy": 2000, "monthly_energy_saving": 1500,
            "weekly_extra_minutes": 45, "tco": {"complete": False, "missing": ["保險"]},
            "decision": {"title": "先確認家充", "reasons": ["家充尚未確認"], "next_steps": ["詢問管委會"]},
            "assumptions": ["電價為手動估計"],
            "days": [{"day": "週一", "km": 40, "start_soc": 80, "end_soc": 65, "public_kwh": 0, "extra_minutes": 0, "unserved_km": 0}],
        }

    def test_export_explains_limits_and_uncertainty(self):
        for report in [build_html(self.profile, self.result, {}), build_markdown(self.profile, self.result, {})]:
            self.assertIn("尚非完整持有成本", report)
            self.assertIn("家充不可用", report)
            self.assertIn("未連接即時充電站", report)
            self.assertIn("保險", report)
            self.assertIn("週一", report)

    def test_html_escapes_all_untrusted_content_and_unsafe_links(self):
        attack = '<img src=x onerror="alert(1)">'
        self.result["decision"]["title"] = attack
        self.result["assumptions"] = [attack]
        self.profile["vehicle_id"] = attack
        sources = {"url": "javascript:alert(1)", "notes": attack, "official": "https://example.com/spec?a=1&b=2"}
        document = build_html(self.profile, self.result, sources)
        self.assertNotIn("<img", document)
        self.assertNotIn("<script", document)
        self.assertNotIn('href="javascript:', document)
        self.assertIn("&lt;img", document)
        self.assertIn('href="https://example.com/spec?a=1&amp;b=2"', document)

    def test_markdown_escapes_raw_html(self):
        self.result["decision"]["title"] = "<script>alert(1)</script> | [attack](bad)"
        document = build_markdown(self.profile, self.result, {})
        self.assertNotIn("<script>", document)
        self.assertIn("&lt;script&gt;", document)
        self.assertIn("\\|", document)

    def test_missing_energy_does_not_become_zero_savings(self):
        self.result["monthly_energy_saving"] = None
        report = build_markdown(self.profile, self.result, {})
        self.assertIn("不推估月省金額", report)
        self.assertIn("暫不估算", report)

    def test_print_summary_hides_appendix_and_uses_current_brand(self):
        report = build_html(self.profile, self.result, {})
        self.assertIn("EV FIT · 轉電之前", report)
        self.assertIn("<details class=appendix>", report)
        self.assertIn(".appendix{display:none!important}", report)

    def test_dynamic_source_schema_keeps_metadata(self):
        sources = {"verified_at": "2026-09-22", "vehicles": [{"id": "test", "battery": {"total": 74.7, "usable": None}, "notes": ["可用容量未知"], "references": [{"title": "官方型錄", "url": "https://example.com/car.pdf"}]}]}
        report = build_markdown(self.profile, self.result, sources)
        for text in ["2026-09-22", "74.7", "可用容量未知", "官方型錄", "https://example.com/car.pdf"]:
            self.assertIn(text, report)


class StoreTests(unittest.TestCase):
    def test_roundtrip_persists_structured_inputs_without_personal_text(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "records.sqlite"
            store = Store(path)
            report_id = store.save_report(
                {"weekday_km": 40, "description": "我住在私人地址", "email": "private@example.com", "custom_note": "私人資料", "ownership": {"ev_price": 1280000, "description": "private"}},
                {"monthly_energy_saving": 1500, "description": "private text"},
            )
            store.close()
            reopened = Store(path)
            report = reopened.list_reports()[0]
            self.assertEqual(report["id"], report_id)
            self.assertEqual(report["profile"], {"weekday_km": 40, "ownership": {"ev_price": 1280000}})
            self.assertEqual(report["result"], {"monthly_energy_saving": 1500})
            self.assertTrue(report["created_at"].endswith("+00:00"))
            reopened.close()

    def test_newest_first_and_finite_json_only(self):
        store = Store(":memory:")
        store.save_report({"weekday_km": 10}, {})
        latest = store.save_report({"weekday_km": 20}, {})
        self.assertEqual(store.list_reports(1)[0]["id"], latest)
        with self.assertRaises(ValueError):
            store.save_report({"weekday_km": float("nan")}, {})
        with self.assertRaises(ValueError):
            store.list_reports(0)
        self.assertEqual(len(store.list_reports()), 2)
        store.close()


if __name__ == "__main__":
    unittest.main()
