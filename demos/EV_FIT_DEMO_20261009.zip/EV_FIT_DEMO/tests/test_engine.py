"""Independent hand-calculated checks for physical and cost invariants."""

from dataclasses import fields, replace
import math
import unittest

from ev.engine import Ownership, Profile, compare_scenarios, simulate_week, summarize


class SimulationTests(unittest.TestCase):
    def simple(self, **changes):
        values = dict(weekday_km=10, weekend_km=0, trips_per_month=0,
                      home_charging="yes", battery_kwh=100, initial_soc=80,
                      reserve_soc=20, consumption_kwh_100km=20,
                      charging_efficiency=0.8, home_power_kw=10,
                      home_hours=8, public_available=False,
                      home_price=3, fuel_km_l=10, fuel_price=30)
        values.update(changes)
        return Profile(**values)

    def test_home_charge_loss_applied_once_and_time_from_grid_power(self):
        # 50 km * .2 = 10 battery kWh; / .8 = 12.5 billed kWh.
        # At 10 grid kW this needs 1.25 h, not 1 h or 1.5625 h.
        week = simulate_week(self.simple())
        self.assertAlmostEqual(week["battery_kwh_used"], 10)
        self.assertAlmostEqual(week["home_grid_kwh"], 12.5)
        self.assertAlmostEqual(week["charge_minutes"], 75)
        self.assertAlmostEqual(week["electricity_cost"], 37.5)
        self.assertAlmostEqual(week["min_soc"], 78)
        self.assertAlmostEqual(week["ending_soc"], 80)
        self.assertTrue(week["feasible"])

    def test_zero_mileage_zero_charge_and_zero_cost(self):
        result = summarize(self.simple(weekday_km=0, weekend_km=300))
        self.assertEqual(result["week"]["total_km"], 0)
        self.assertEqual(result["week"]["grid_kwh"], 0)
        self.assertEqual(result["week"]["public_sessions"], 0)
        self.assertEqual(result["annual_ice_energy"], 0)
        self.assertEqual(result["annual_ev_energy"], 0)
        self.assertEqual(result["annual_energy_saving"], 0)

    def test_annual_cost_matches_independent_hand_calculation(self):
        # 260 days * 10 km = 2600 km; fuel 260 L * $30 = $7800.
        # Electricity 2600 *.2/.8 * $3 = $1950.
        result = summarize(self.simple())
        self.assertAlmostEqual(result["annual_km"], 2600)
        self.assertAlmostEqual(result["annual_ice_energy"], 7800)
        self.assertAlmostEqual(result["annual_ev_energy"], 1950)
        self.assertAlmostEqual(result["annual_energy_saving"], 5850)
        self.assertAlmostEqual(result["monthly_energy_saving"], 487.5)

    def test_energy_conservation_with_home_public_and_no_charging(self):
        cases = [Profile(), Profile(home_charging="yes"), Profile(home_charging="no", public_available=False),
                 Profile(initial_soc=95, public_hours=0.1), Profile(weekday_km=300, weekend_km=900)]
        for p in cases:
            with self.subTest(profile=p):
                week = simulate_week(p)
                initial = p.battery_kwh * p.initial_soc / 100
                final = p.battery_kwh * week["ending_soc"] / 100
                self.assertAlmostEqual(initial + week["grid_kwh"] * p.charging_efficiency - week["battery_kwh_used"], final)
                self.assertAlmostEqual(week["battery_kwh_used"], week["served_km"] * p.consumption_kwh_100km / 100)
                self.assertAlmostEqual(week["served_km"] + week["unserved_km"], week["total_km"])
                self.assertTrue(all(0 <= day["min_soc"] <= 100 for day in week["days"]))
                self.assertTrue(all(0 <= day["end_soc"] <= 100 for day in week["days"]))

    def test_unavailable_public_never_produces_charge_or_false_savings(self):
        # 5 kWh initially can serve 25 km at .2 kWh/km; remaining 475 cannot run.
        p = self.simple(weekday_km=100, battery_kwh=10, initial_soc=50, home_charging="no")
        result = summarize(p)
        week = result["week"]
        self.assertAlmostEqual(week["served_km"], 25)
        self.assertAlmostEqual(week["unserved_km"], 475)
        self.assertEqual(week["public_sessions"], 0)
        self.assertEqual(week["public_grid_kwh"], 0)
        self.assertFalse(week["feasible"])
        self.assertIsNone(result["annual_ev_energy"])
        self.assertIsNone(result["annual_energy_saving"])
        self.assertEqual(result["decision"]["status"], "difficult")

    def test_reserve_violation_is_infeasible_even_if_trip_completes(self):
        week = simulate_week(self.simple(weekday_km=350, home_hours=10))
        self.assertAlmostEqual(week["unserved_km"], 0)
        self.assertAlmostEqual(week["min_soc"], 10)
        self.assertFalse(week["feasible"])
        self.assertTrue(any("備援" in warning for warning in week["warnings"]))

    def test_short_public_window_is_not_bypassed_with_infinite_sessions(self):
        p = self.simple(weekday_km=100, home_charging="no", public_available=True,
                        public_hours=0.1, public_power_kw=50, charging_efficiency=0.9)
        week = simulate_week(p)
        self.assertFalse(week["feasible"])
        self.assertGreater(week["unserved_km"], 0)
        for day in week["days"]:
            public = [e for e in day["events"] if e["type"] == "public"]
            self.assertLessEqual(len(public), 1)
            self.assertLessEqual(sum(e["minutes"] for e in public), 6 + 1e-8)

    def test_public_charge_tapers_at_80_percent(self):
        # End Sunday restore from 40 to 90 kWh: 40/100 h + 10/20 h = .9 h.
        p = self.simple(weekday_km=50, home_charging="no", public_available=True,
                        public_power_kw=100, public_hours=8, charging_efficiency=1,
                        initial_soc=90, detour_minutes=15)
        week = simulate_week(p)
        self.assertAlmostEqual(week["public_grid_kwh"], 50)
        self.assertAlmostEqual(week["charge_minutes"], 54)
        self.assertAlmostEqual(week["extra_minutes"], 69)
        self.assertEqual(week["public_sessions"], 1)
        self.assertEqual(week["days"][-1]["events"][0]["reason"], "週末補回起始電量")
        self.assertAlmostEqual(week["ending_soc"], 90)

    def test_unknown_home_is_conservative_and_warns(self):
        unknown = simulate_week(Profile(home_charging="unknown"))
        no = simulate_week(Profile(home_charging="no"))
        self.assertEqual(unknown["home_grid_kwh"], 0)
        self.assertEqual(unknown["public_grid_kwh"], no["public_grid_kwh"])
        self.assertTrue(any("尚未確認" in warning for warning in unknown["warnings"]))
        self.assertEqual(summarize(Profile())["decision"]["status"], "confirm")

    def test_trip_frequency_weights_annual_distance_cost_and_extra_time(self):
        # 4 outings/month * 12 * 100 km = 4800 km/year, rather than 5200.
        p = self.simple(weekday_km=0, weekend_km=100, trips_per_month=4,
                        home_charging="no", public_available=True, public_power_kw=50,
                        charging_efficiency=1, public_price=10, detour_minutes=15)
        result = summarize(p)
        self.assertAlmostEqual(result["annual_km"], 4800)
        self.assertAlmostEqual(result["annual_ev_energy"], 9600)
        # One outing consumes 20 kWh: .4 hour public charge + .25 hour detour.
        self.assertAlmostEqual(result["weekly_extra_minutes"], 39 * 48 / 52)
        self.assertAlmostEqual(result["annual_charging_parking"], 0)

    def test_public_parking_is_separate_from_energy(self):
        p = self.simple(weekday_km=0, weekend_km=100, trips_per_month=4,
                        home_charging="no", public_available=True,
                        charging_efficiency=1, public_price=10, public_parking_fee=50)
        result = summarize(p)
        self.assertAlmostEqual(result["annual_ev_energy"], 9600)
        self.assertAlmostEqual(result["annual_charging_parking"], 2400)

    def test_stress_case_uses_more_energy(self):
        result = summarize(self.simple())
        self.assertAlmostEqual(result["stress_test"]["consumption_kwh_100km"], 25)
        self.assertAlmostEqual(result["stress_test"]["annual_ev_energy"], 1950 * 1.25)

    def test_week_must_restore_starting_soc_for_sustainable_costs(self):
        # Travel completes above reserve, but with no recharge the next week
        # cannot repeatedly receive the same free initial energy.
        p = self.simple(home_charging="no")
        result = summarize(p)
        self.assertEqual(result["week"]["unserved_km"], 0)
        self.assertFalse(result["week"]["sustainable"])
        self.assertIsNone(result["annual_energy_saving"])


class OwnershipTests(unittest.TestCase):
    def zero_costs(self, **changes):
        values = {field.name: 0 for field in fields(Ownership) if field.name != "baseline"}
        values.update(changes)
        return Ownership(**values)

    def test_missing_is_distinct_from_explicit_zero(self):
        p = Profile(weekday_km=0, weekend_km=0)
        missing = summarize(p)["tco"]
        complete = summarize(p, self.zero_costs())["tco"]
        self.assertFalse(missing["complete"])
        self.assertIn("ev_price", missing["missing"])
        self.assertIsNone(missing["difference"])
        self.assertTrue(complete["complete"])
        self.assertEqual(complete["missing"], [])
        self.assertEqual(complete["ice"], 0)
        self.assertEqual(complete["ev"], 0)
        self.assertEqual(complete["difference"], 0)

    def test_keep_and_new_use_distinct_basis_with_same_horizon(self):
        p = Profile(weekday_km=0, weekend_km=0, years=5)
        # Retaining current car: 400k sale value - 100k resale, plus 10k/y.
        costs = self.zero_costs(ice_value=400000, ice_resale=100000,
                               ev_price=1500000, ev_resale=700000,
                               ice_maintenance_year=10000, ev_maintenance_year=4000,
                               home_install=40000)
        keep = summarize(p, costs)["tco"]
        new = summarize(p, replace(costs, baseline="new", ice_value=1000000))["tco"]
        self.assertEqual(keep["ice"], 350000)
        self.assertEqual(keep["ev"], 860000)
        self.assertEqual(keep["difference"], -510000)
        self.assertEqual(new["ice"], 950000)
        self.assertEqual(new["ev"], 860000)
        self.assertEqual(new["difference"], 90000)
        self.assertEqual(new["years"], 5)


class ValidationTests(unittest.TestCase):
    def test_non_finite_values_are_rejected_everywhere(self):
        for field in fields(Profile):
            if field.name not in ("home_charging", "public_available"):
                for value in (math.nan, math.inf, -math.inf):
                    with self.subTest(field=field.name, value=value), self.assertRaises(ValueError):
                        Profile(**{field.name: value})
        for field in fields(Ownership):
            if field.name != "baseline":
                with self.subTest(field=field.name), self.assertRaises(ValueError):
                    Ownership(**{field.name: math.nan})

    def test_impossible_bounds_and_wrong_types_are_rejected(self):
        cases = [{"battery_kwh": 0}, {"charging_efficiency": 1.1}, {"fuel_km_l": 0},
                 {"initial_soc": 101}, {"reserve_soc": -1}, {"weekday_km": -1},
                 {"trips_per_month": 5}, {"home_charging": "maybe"},
                 {"home_hours": 25}, {"years": 1.5}, {"weekday_km": True},
                 {"public_available": "false"}, {"home_price": "3"}]
        for changes in cases:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                Profile(**changes)
        with self.assertRaises(ValueError):
            Ownership(baseline="old")
        with self.assertRaises(ValueError):
            Ownership(ev_price=-1)

    def test_scenarios_declare_exactly_one_modified_variable(self):
        p = Profile()
        cases = compare_scenarios(p)
        self.assertEqual(len(cases), 4)
        for case in cases:
            self.assertEqual(len(case["changed"]), 1)
            field, delta = next(iter(case["changed"].items()))
            self.assertEqual(delta["from"], getattr(p, field))
            expected = summarize(replace(p, **{field: delta["to"]}))
            self.assertEqual(case["result"], expected)


if __name__ == "__main__":
    unittest.main()
