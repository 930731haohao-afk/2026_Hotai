"""Independent arithmetic and boundary tests for interactive answer cards."""
import math
import unittest

from ev.explore import card_kind, charging_preview, loan_example, micro_energy


class CardSelectionTests(unittest.TestCase):
    def test_vetted_entry_ids_select_cards_in_order(self):
        groups = {
            "vehicles": ["K01"],
            "battery": ["K02", "K03", "K04", "K08", "K09", "K10"],
            "charging": ["K05", "K06", "K07", "K11"],
            "energy": ["K12", "K13", "K14", "K15", "K20", "K21", "K22"],
            "loan": ["K18", "K19"],
        }
        for expected, ids in groups.items():
            for entry_id in ids:
                with self.subTest(entry_id=entry_id):
                    self.assertEqual(card_kind({"entries": [{"id": entry_id}]}), expected)
        self.assertEqual(card_kind({"entries": [{"id": "K05"}, {"id": "K01"}]}), "charging")
        self.assertEqual(card_kind({"entries": [{"id": "K99"}, {"id": "K18"}]}), "loan")

    def test_untrusted_prose_or_source_fields_do_not_select_ui(self):
        result = {"answer": '<script>show_loan()</script> K18', "source_ids": ["K18"],
                  "card_kind": "loan", "entries": []}
        self.assertEqual(card_kind(result), "next_steps")
        self.assertEqual(card_kind({"mode": "no_evidence", "entries": [{"id": "K18"}]}), "next_steps")

    def test_absent_unknown_and_malformed_ids_use_safe_default(self):
        for result in (None, {}, {"entries": None}, {"entries": {}},
                       {"entries": [{"id": "K16"}]}, {"entries": [{"id": "k01"}]},
                       {"entries": ["K01", None, {"id": ["K01"]}]}):
            with self.subTest(result=result):
                self.assertEqual(card_kind(result), "next_steps")


class EnergyCardTests(unittest.TestCase):
    def test_hand_calculated_mixed_charging_and_single_efficiency_loss(self):
        # 1000 km * .2 battery kWh/km /.8 = 250 billed kWh.
        # Home: 62.5 * $3 = $187.5; public: 187.5 * $10 = $1875.
        # Fuel: 1000/10 * $30 = $3000; saving: $937.5/month.
        result = micro_energy(1000, 25, fuel_price=30, fuel_km_l=10, consumption=20, efficiency=.8)
        self.assertEqual(result["grid_kwh"], 250)
        self.assertEqual(result["home_cost"], 187.5)
        self.assertEqual(result["public_cost"], 1875)
        self.assertEqual(result["ev_cost"], 2062.5)
        self.assertEqual(result["ice_cost"], 3000)
        self.assertEqual(result["saving"] * 12, 11250)
        self.assertTrue(any("總持有成本" in note for note in result["assumptions"]))

    def test_zero_mileage_zero_energy_and_cost(self):
        result = micro_energy(0, 50)
        for key in ("ice_cost", "ev_cost", "saving", "home_cost", "public_cost", "grid_kwh"):
            self.assertEqual(result[key], 0)

    def test_home_share_changes_price_but_not_energy_and_can_show_negative_saving(self):
        public = micro_energy(1000, 0, consumption=20, efficiency=1, fuel_price=10, fuel_km_l=20)
        home = micro_energy(1000, 100, consumption=20, efficiency=1, fuel_price=10, fuel_km_l=20)
        self.assertEqual(public["grid_kwh"], home["grid_kwh"])
        self.assertEqual(public["home_cost"], 0)
        self.assertEqual(home["public_cost"], 0)
        self.assertEqual(public["saving"], -1500)
        self.assertEqual(home["saving"], -100)
        self.assertGreater(home["saving"], public["saving"])

    def test_finite_and_domain_validation(self):
        fields = ("monthly_km", "home_share_pct", "fuel_price", "fuel_km_l", "consumption", "efficiency", "home_price", "public_price")
        for field in fields:
            for invalid in (math.nan, math.inf, -math.inf, True, "10"):
                values = {"monthly_km": 1000, "home_share_pct": 50, field: invalid}
                with self.subTest(field=field, invalid=invalid), self.assertRaises(ValueError):
                    micro_energy(**values)
        for changes in ({"monthly_km": -1}, {"monthly_km": 10001}, {"home_share_pct": 101},
                        {"efficiency": 0}, {"efficiency": 1.01}, {"fuel_km_l": 0},
                        {"fuel_price": 0}, {"consumption": 0}, {"home_price": -1}):
            values = {"monthly_km": 1000, "home_share_pct": 50, **changes}
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                micro_energy(**values)
        # Finite input is not enough if division would overflow float output.
        with self.assertRaises(ValueError):
            micro_energy(10000, 50, efficiency=1e-308)


class LoanCardTests(unittest.TestCase):
    def test_zero_interest_and_zero_principal(self):
        zero_rate = loan_example(600000, 0, 60)
        self.assertEqual(zero_rate["monthly_payment"], 10000)
        self.assertEqual(zero_rate["total_payment"], 600000)
        self.assertEqual(zero_rate["total_interest"], 0)
        zero_principal = loan_example(0, 3, 60)
        self.assertEqual(set(zero_principal.values()), {0})

    def test_fixed_rate_payment_clears_independent_monthly_balance(self):
        result = loan_example(600000, 3, 60)
        # Independent balance recurrence verifies amortization rather than
        # reproducing the annuity formula used by the implementation.
        balance = 600000.0
        summed_interest = 0.0
        for _ in range(60):
            interest = balance * .0025
            summed_interest += interest
            balance += interest - result["monthly_payment"]
        self.assertAlmostEqual(balance, 0, places=6)
        self.assertAlmostEqual(result["total_interest"], summed_interest, places=6)
        self.assertAlmostEqual(result["monthly_payment"], 10781.214398438,
                               places=6)

    def test_longer_term_reduces_payment_but_increases_total_interest(self):
        short = loan_example(600000, 3, 36)
        long = loan_example(600000, 3, 84)
        self.assertLess(long["monthly_payment"], short["monthly_payment"])
        self.assertGreater(long["total_interest"], short["total_interest"])
        self.assertGreater(long["total_payment"], short["total_payment"])

    def test_bounded_extremes_and_near_zero_rates_remain_finite(self):
        for principal, rate, months in ((1e8, 50, 120), (1e8, 50, 12), (600000, 1e-12, 60), (600000, 1e-320, 60)):
            with self.subTest(principal=principal, rate=rate, months=months):
                result = loan_example(principal, rate, months)
                self.assertTrue(all(math.isfinite(value) for value in result.values()))
                self.assertGreaterEqual(result["total_interest"], 0)
                self.assertAlmostEqual(result["total_payment"], principal + result["total_interest"])
        self.assertAlmostEqual(loan_example(600000, 1e-12, 60)["monthly_payment"], 10000, places=6)

    def test_invalid_loan_inputs_are_rejected(self):
        cases = ({"principal": -1}, {"principal": 1e8 + 1}, {"principal": math.inf},
                 {"annual_interest_pct": -1}, {"annual_interest_pct": 51}, {"annual_interest_pct": math.nan},
                 {"months": 11}, {"months": 121}, {"months": 60.0}, {"months": True})
        for changes in cases:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                loan_example(**changes)


class ChargingCardTests(unittest.TestCase):
    def test_preview_is_workweek_only_with_explicit_inputs(self):
        result = charging_preview(40, "yes")
        self.assertEqual(result["week"]["total_km"], 200)
        self.assertEqual(result["annual_km"], 10400)
        self.assertEqual([day["km"] for day in result["week"]["days"]], [40, 40, 40, 40, 40, 0, 0])
        self.assertEqual(result["inputs"]["home_power_kw"], 7)
        self.assertEqual(result["inputs"]["weekend_km"], 0)
        self.assertEqual(result["inputs"]["trips_per_month"], 0)
        self.assertEqual(result["inputs"]["home_charging"], "yes")
        self.assertTrue(result["week"]["feasible"])

    def test_zero_mileage_unknown_home_and_invalid_inputs(self):
        result = charging_preview(0, "unknown")
        self.assertEqual(result["week"]["grid_kwh"], 0)
        self.assertEqual(result["week"]["extra_minutes"], 0)
        self.assertEqual(result["annual_energy_saving"], 0)
        self.assertTrue(any("尚未確認" in warning for warning in result["week"]["warnings"]))
        for km, home in ((math.nan, "yes"), (501, "yes"), (-1, "no"), (True, "yes"), (40, "maybe")):
            with self.subTest(km=km, home=home), self.assertRaises(ValueError):
                charging_preview(km, home)


if __name__ == "__main__":
    unittest.main()
