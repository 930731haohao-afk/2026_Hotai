# 油轉電與用車財務知識庫來源

版本：`2026-09-23-v1`。本次新增一般知識查核日期：2026-09-23。共22條知識、25個官方來源，內容採繁體中文重述；每條保留來源 ID、生活化關鍵字、追問及相關條目。

## 適用範圍與查核方式

一般知識以官方網頁正文或搜尋工具擷取的官方頁面內容核對，不採論壇、新聞轉述或商業比較網站作為事實依據。所有來源網址列於下表，來源對應也存於 `data/knowledge.json`。

台灣車型資料沿用 `data/vehicle_sources.json` 的 **2026-09-22** 查核結果：bZ4X、202510 A版、2025-10-01起生產。原查核日期保留在 TW-SHOWROOM 與 TW-SPEC，不能因新增一般知識，就宣稱全部車型規格已在2026-09-23重新查核。此知識庫不新增售價、電池可用容量、充電功率或保固承諾。

TW-HOME 在2026-09-23重新核對的是同頁下方「居家安裝流程」，限用於場勘、規劃報價及社區同意流程。該頁上方充電功率仍有版本混用問題，**不使用其功率或充電時間作現行車規**。

## 來源對照

| ID | 官方來源 | 查核日期 | 知識條目 |
| --- | --- | --- | --- |
| TW-SHOWROOM | [TOYOTA TAIWAN bZ4X 車款頁](https://www.toyota.com.tw/showroom/bZ4X/) | 2026-09-22 | K09、K17 |
| TW-SPEC | [TOYOTA TAIWAN bZ4X 完整規配](https://www.toyota.com.tw/showroom/bZ4X/fullsepc.aspx) | 2026-09-22 | K02、K07、K13 |
| DOE-EV | [Electric Vehicles](https://afdc.energy.gov/vehicles/electric) | 2026-09-23 | K01 |
| DOE-HEV | [Hybrid Electric Vehicles](https://afdc.energy.gov/vehicles/electric-basics-hev) | 2026-09-23 | K01 |
| DOE-PHEV | [Plug-In Hybrid Electric Vehicles](https://afdc.energy.gov/vehicles/electric-basics-phev) | 2026-09-23 | K01 |
| AU-BATTERY | [Batteries：電池容量與功率基礎](https://www.energy.gov.au/solar/get-know-solar-technology/batteries) | 2026-09-23 | K02、K03 |
| DOE-STATIONS | [Electric Vehicle Charging Stations](https://afdc.energy.gov/fuels/electricity-stations) | 2026-09-23 | K03、K04、K06、K08 |
| TW-HOME | [TOYOTA bZ4X 居家充電安裝流程](https://www.toyota.com.tw/bZ/bZ4X/charge.aspx) | 2026-09-23 | K05 |
| DOE-HOME | [Charging Electric Vehicles at Home](https://afdc.energy.gov/fuels/electricity-charging-home) | 2026-09-23 | K05、K06 |
| DOE-MULTI | [Electric Vehicle Charging for Multifamily Housing](https://afdc.energy.gov/fuels/electricity-charging-multi) | 2026-09-23 | K05 |
| AU-CHARGE | [How to charge your electric vehicle](https://www.energy.gov.au/electric-vehicles/owning-electric-vehicle/how-charge-your-electric-vehicle) | 2026-09-23 | K07、K08、K11 |
| AU-TRIP | [Planning an electric vehicle trip](https://www.energy.gov.au/electric-vehicles/owning-electric-vehicle/planning-electric-vehicle-trip) | 2026-09-23 | K04、K10 |
| DOE-CONSUMERS | [Electric Vehicles for Consumers](https://afdc.energy.gov/vehicles/electric-consumers) | 2026-09-23 | K10、K11 |
| EPA-TEST | [Fuel Economy and EV Range Testing](https://www.epa.gov/greenvehicles/fuel-economy-and-ev-range-testing) | 2026-09-23 | K09、K13 |
| CA-DEPRECIATION | [Financial risks when buying a car](https://www.canada.ca/en/financial-consumer-agency/services/loans/financing-car/risks.html) | 2026-09-23 | K14 |
| FED-OPPORTUNITY | [Money and Missed Opportunities](https://www.stlouisfed.org/publications/page-one-economics/2019/10/01/money-and-missed-opportunities) | 2026-09-23 | K15、K20 |
| FED-SUNK | [The Endowment Effect](https://www.stlouisfed.org/publications/page-one-economics/2022/04/01/the-endowment-effect) | 2026-09-23 | K15 |
| DOE-MAINTENANCE | [Maintenance and Safety of Electric Vehicles](https://afdc.energy.gov/vehicles/electric-maintenance) | 2026-09-23 | K16、K17 |
| CFPB-APR | [What is the difference between a loan interest rate and the APR?](https://www.consumerfinance.gov/ask-cfpb/what-is-the-difference-between-a-loan-interest-rate-and-the-apr-en-733/) | 2026-09-23 | K18 |
| CFPB-COMPARE | [How do I compare auto loan offers?](https://www.consumerfinance.gov/ask-cfpb/how-do-i-compare-auto-loan-offers-what-should-i-look-at-besides-the-monthly-payment-en-753/) | 2026-09-23 | K12、K18、K19、K22 |
| CFPB-AMORTIZATION | [What is amortization and how could it affect my auto loan?](https://www.consumerfinance.gov/ask-cfpb/what-is-amortization-and-how-could-it-affect-my-auto-loan-en-771/) | 2026-09-23 | K19、K20 |
| CFPB-BUDGET | [How much can I afford to borrow for a car or auto loan?](https://www.consumerfinance.gov/ask-cfpb/how-much-can-i-afford-to-borrow-for-a-car-or-auto-loan-en-751/) | 2026-09-23 | K12、K20、K21 |
| FTC-BUDGET | [Making a Budget](https://consumer.gov/your-money/making-budget) | 2026-09-23 | K21 |
| FTC-BUY | [Buying a Car](https://consumer.gov/cars/buying-car) | 2026-09-23 | K22 |
| AU-MAINTENANCE | [Electric vehicle maintenance and servicing](https://www.energy.gov.au/electric-vehicles/owning-electric-vehicle/electric-vehicle-maintenance-and-servicing) | 2026-09-23 | K16 |

## 來源支持與本工具推導的分界

- K01：DOE來源區分純電、一般油電與插電式油電；不搬用美國常見續航、電價或車款選擇。
- K02–K04：來源支持容量、功率、SOC與行程備案的一般觀念。AU-BATTERY討論家用儲能，只取容量與功率的定義，不把其容量保留比例或損耗比例套用電動車。示例的六十度、百分之二十，以及七千瓦一小時，均是自設的教學換算。
- K05–K11：來源支持家充場勘、集合住宅限制、充電速度變動、接頭核對及備案規劃。不把美國、澳洲住宅電壓、接頭普及程度、法規或站點數套用台灣。模型的公共充電機會與備援門檻是使用者輸入，不是官方建議或即時查詢結果。
- K12–K15：成本項目、折舊、機會成本、沉沒成本與充電計量概念有來源。相同期間／里程、起始價值減殘值，以及缺值不填零，是本工具明示的比較方法；外部機關沒有替此工具的完整算法背書。
- K13：EPA明確支持「其MPGe能效值已計入充電損耗」。這只能證明計量端需要核對，**不能推論台灣bZ4X的6.7 km/kWh採完全相同邊界**。電池端耗電除以效率的算式是單位及能量換算，損耗只計一次。
- K16–K17：只重述一般維護與需核對車款保固的觀念。不轉用海外常見保固年限、里程、容量門檻、保養費或電池更換費。
- K18–K21：CFPB、FTC及聯準銀行內容只作一般借貸、預算與經濟觀念教育。台灣APR／總費用年百分率、契約揭露、費用納入、清償及付款方式仍須依本地規範與實際契約核實，不把美國法律義務寫成台灣條件。
- K19–K20：本息分配有CFPB來源。簡化的固定付款換算、經濟成本與現金流分類，是明示的教學推導；沒有把APR直接當每期利率，也沒有把月付全部當利息。
- K22：來源只支持保險與稅費屬於持有成本。未宣稱目前台灣任何免稅、補助期限、費率或保額，未知值保留待確認。

## 檢查結果

資料結構可解析；知識 ID 與來源 ID 唯一；所有 `source_ids` 及 `related_ids` 都能解析；每條內容含150個以上漢字，總長度介於150至350字元。各條含追問與至少一個相關條目，四個分類均有內容。語意檢索與引用呈現由應用程式另外驗證。

來源仍可能日後更新；若更換車型、規配版或引入即時金融／政策數字，應重新核對，不能只沿用本資料包的查核日期。

