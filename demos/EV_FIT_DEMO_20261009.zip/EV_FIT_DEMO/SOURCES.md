# 車輛資料與計算邊界

查核日期：2026-09-22。適用車型為台灣 bZ4X 前輪傳動版，官方用 **202510 A 版、2025-10-01 起生產**識別；來源未明列 Model Year，JSON 的 `model_year` 因而保留 `null`。

## 已確認的官方值

| 欄位 | 數值／狀態 | 來源 |
| --- | --- | --- |
| 規配版與適用起日 | 202510 A；2025-10-01 起生產 | [TOYOTA 車款頁](https://www.toyota.com.tw/showroom/bZ4X/) |
| 建議售價 | NT$1,280,000 | [完整規配](https://www.toyota.com.tw/showroom/bZ4X/fullsepc.aspx) |
| 電池 | 鋰離子；標示容量 74.7 kWh | [完整規配](https://www.toyota.com.tw/showroom/bZ4X/fullsepc.aspx) |
| 可用容量 | 未查得此台灣規配的官方獨立數值 | 同上；不把標示容量當可用容量 |
| 實驗室續航 | 743 km；NEDC／ECE R101 | [TOYOTA 車款頁](https://www.toyota.com.tw/showroom/bZ4X/) |
| 官方用電效率 | 6.7 km/kWh；年耗電 2,239 kWh 以 15,000 km 換算 | [完整規配](https://www.toyota.com.tw/showroom/bZ4X/fullsepc.aspx) |
| 接頭 | AC SAE J1772；DC CCS1 | [完整規配](https://www.toyota.com.tw/showroom/bZ4X/fullsepc.aspx) |
| 充電功率 | AC 11 kW；DC 最大 160 kW | [現行電子型錄第21頁](https://www.toyota.com.tw/download_pdf.ashx?carsty=bZ4X&preview=)、[和泰上市新聞](https://www.hotaimotor.com.tw/News/Details/254) |
| 充電時間宣稱 | AC 0–100% 約 7 小時；DC 低電量警示亮起至80%約28分鐘 | [現行電子型錄第21頁](https://www.toyota.com.tw/download_pdf.ashx?carsty=bZ4X&preview=) |

型錄的 DC 時間條件為160 kW（400 A），並提醒環境與供電會影響時間；未將低電量燈自行等同10% SOC。電子型錄由官方 PDF 搜尋索引核對；直接抓取時因約25 MB 超出 web 工具上限，未完成逐頁視覺核對。AC 11 kW 為該型錄數值，正式對外版本可再下載原始型錄覆核。

## 來源衝突處理

[較舊的充電介紹頁](https://www.toyota.com.tw/bZ/bZ4X/charge.aspx)仍顯示 AC 6.6 kW、DC 150 kW、約30分鐘，不能和現行74.7 kWh版混用。[2025-10-01 預購新聞](https://www.hotaimotor.com.tw/News/Details/236)的正文為160 kW，時間註腳卻仍寫150 kW。資料採現行車款頁連結的型錄，保留此差異，不抹除衝突。

## MVP 的假設必須分開顯示

SOC計算需要**可用容量**。由於官方值待確認，介面應把模擬容量明確標為可調整的情境假設。所有日常耗能、充電有效功率與效率、電價、油價、排隊時間、安裝費、保險和殘值，也應在介面或報告列出假設。

本版建議採單一計算邊界：

- 電池耗電量（kWh）＝里程（km）×電池端耗能（kWh/100km）÷100。
- 樁端購電量（kWh）＝電池耗電量÷充電效率；充電損耗只算一次。
- 官方6.7 km/kWh僅供規格展示，未另外核實完整計量邊界，不能把其倒數當電池端實測耗能再追加損耗。
- 充電時間使用另外標示的有效功率／分段假設，不能拿160 kW峰值當全程平均。
- 情境範圍不是統計信賴區間；能源支出差額不等於總持有成本差額。
- 未串接即時充電站、路線、價格或動態車況；家充資格與站點可用性須另確認。

機器可讀的欄位、來源 ID、FAQ 與未知值存於 `data/vehicle_sources.json`。規格不應套用至改款前車輛或海外版本。
