"""EV FIT: question-first knowledge assistance plus deterministic simulation."""
import streamlit as st

from ev.ui_styles import STYLES

st.set_page_config(page_title="轉電之前 EV FIT｜問答助理・生活適配試算", page_icon="🌿", layout="wide")
st.markdown(STYLES, unsafe_allow_html=True)
st.markdown("""<style>
.st-key-product_page{margin-bottom:28px;border-bottom:1px solid #dde5d7;padding-bottom:15px;}
.ask-card{background:#e8eedf;border:1px solid #d7e0cc;border-radius:20px;padding:26px;min-height:225px;position:relative;}
.ask-orbit{position:absolute;right:22px;top:28px;border:1px solid #abc196;color:#638353;border-radius:50%;width:55px;height:55px;text-align:center;line-height:53px;font-size:28px;transform:rotate(-12deg);}
.ask-card .hero-name{margin-top:38px;font-size:1.2rem;}
.preview-status{padding:13px 17px;background:#edf1e7;color:#607056;font-size:12px;line-height:1.8;border-radius:9px;margin:22px 0;}
[data-testid="stChatMessage"]{border:1px solid #e1e7dc;background:#fff;border-radius:14px;margin:12px 0;padding:20px;}
.st-key-chat_composer{margin:20px 0;}
.explore-kicker{font-size:10px;font-weight:700;letter-spacing:.13em;color:#628059;margin-bottom:5px;}
.explore-note{padding:13px 16px;border-left:3px solid #98b572;background:#f1f5eb;font-size:13px;line-height:1.8;border-radius:0 8px 8px 0;}
.vehicle-tile{background:#f0f4ea;border:1px solid #dce6d2;border-radius:14px;padding:18px;min-height:290px;margin:8px 0;}
.vehicle-id{font-size:11px;letter-spacing:.15em;color:#628059;font-weight:700;}
.vehicle-tile h4{margin:8px 0 14px;}.vehicle-tile p{font-size:13px;line-height:1.65;margin:12px 0;}
[class*="st-key-explore_"] [data-testid="stMetric"]{padding:12px 13px;}
[class*="st-key-explore_"] [data-testid="stMetricValue"]{font-size:1.4rem;}
.st-key-reply_navigation [data-testid="stHorizontalBlock"]{display:grid!important;grid-template-columns:1fr auto 1fr;gap:8px;align-items:center;}
.st-key-reply_navigation [data-testid="stColumn"]{width:100%!important;min-width:0!important;}
.st-key-reply_navigation [data-testid="stColumn"]:last-child [data-testid="stButton"]{display:flex;justify-content:flex-end;}
.st-key-reply_navigation button{font-size:12px;white-space:nowrap;min-height:34px;}
@media(max-width:650px){.ask-card{display:none;} .st-key-product_page{margin-bottom:16px;} [data-testid="stChatMessage"]{padding:12px;} [class*="st-key-explore_"] h4{font-size:1.05rem!important;line-height:1.5;}}
</style>""", unsafe_allow_html=True)
st.session_state.setdefault("product_page", "問答助理")
page = st.segmented_control("EV FIT 的兩個功能", ["問答助理", "生活適配試算"], key="product_page", required=True, label_visibility="collapsed", width="stretch")
if page == "生活適配試算":
    from ev.simulator_ui import render_simulator
    render_simulator()
else:
    from ev.assistant_ui import render_assistant
    render_assistant()
