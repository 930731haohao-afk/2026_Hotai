const {test}=require('node:test');
const assert=require('node:assert/strict');
const {scenarios,risk,rankPoints,shouldAlert}=require('../core.js');
test('three scenarios produce documented scores',()=>{
 assert.deepEqual(Object.values(scenarios).map(risk).map(r=>r.score),[88,75,64]);
});
test('risk handles boundary, zero and missing values',()=>{
 assert.equal(risk({rain:0,demand:0,concentration:0}).score,0);
 assert.equal(risk({rain:100,demand:100,concentration:100}).score,100);
 assert.equal(risk({rain:45,demand:45,concentration:45}).level,'中等');
 assert.equal(risk({rain:70,demand:70,concentration:70}).level,'偏高');
 for(const bad of [null,undefined,-1,101,NaN,'70'])assert.equal(risk({rain:bad,demand:50,concentration:50}).score,null);
});
test('ranking considers total time, shelter and walking constraints',()=>{
 const p=scenarios.concert.points;
 assert.equal(rankPoints(p,{shelter:false,maxWalk:10})[0].id,'B');
 assert.equal(rankPoints(p,{shelter:true,maxWalk:10})[0].score,15);
 assert.equal(rankPoints(p,{shelter:false,maxWalk:5})[0].id,'A');
 assert.equal(rankPoints(p,{shelter:false,maxWalk:2}).length,0);
 assert.equal(rankPoints([{...p[0],approved:false}],{shelter:false,maxWalk:10}).length,0);
 const c=scenarios.commute.points;
 assert.equal(rankPoints(c,{shelter:false,maxWalk:10})[0].id,'B');
 assert.equal(rankPoints(c,{shelter:true,maxWalk:10})[0].id,'A');
});
test('alert respects missing data, threshold, consent and cooldown',()=>{
 const base={score:60,enabled:true,now:0,lastAlert:null,snoozedUntil:0};
 assert.equal(shouldAlert(base),true);
 for(const patch of [{score:null},{score:59},{enabled:false},{lastAlert:0,now:29},{snoozedUntil:10,now:9}])assert.equal(shouldAlert({...base,...patch}),false);
 assert.equal(shouldAlert({...base,now:30,lastAlert:0}),true);
});
test('explicit snooze fires at ten minutes, then normal cooldown resumes',()=>{
 const base={score:80,enabled:true,lastAlert:5,snoozedUntil:15};
 assert.equal(shouldAlert({...base,now:14}),false);
 assert.equal(shouldAlert({...base,now:15}),true);
 assert.equal(shouldAlert({...base,now:20,lastAlert:15,snoozedUntil:0}),false);
});
