"""Local-only static demo server. Never proxies ride, location or payment APIs."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import json

ROOT = Path(__file__).resolve().parent
PUBLIC = {'/': 'index.html', '/index.html': 'index.html', '/style.css': 'style.css', '/core.js': 'core.js', '/app.js': 'app.js'}

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/health':
            body = json.dumps({'app': 'yoxi-moveahead-demo', 'status': 'ok'}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if path not in PUBLIC:
            self.send_error(404)
            return
        self.path = '/' + PUBLIC[path]
        super().do_GET()

    def do_HEAD(self):
        path = urlparse(self.path).path
        if path not in PUBLIC:
            self.send_error(404)
            return
        self.path = '/' + PUBLIC[path]
        super().do_HEAD()

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        super().end_headers()

if __name__ == '__main__':
    print('yoxi MoveAhead ready: http://127.0.0.1:8766', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8766), Handler).serve_forever()
