'use strict';
const {scenarios,risk,rankPoints,shouldAlert}=MoveAhead;
const $=s=>document.querySelector(s);
const icons={
  rain:'<path d="M5 15a5 5 0 1 1 2-9 6 6 0 0 1 11 3 3.5 3.5 0 0 1 0 7H5"/><path d="m8 19-1 2m6-2-1 2m6-2-1 2"/>',
  music:'<path d="M9 18V5l11-2v13M9 8l11-2"/><ellipse cx="6" cy="18" rx="3" ry="2"/><ellipse cx="17" cy="16" rx="3" ry="2"/>',
  train:'<rect x="5" y="3" width="14" height="15" rx="4"/><path d="M5 10h14M9 3v7m6-7v7M8 18l-2 3m10-3 2 3"/><path d="M9 14h.01M15 14h.01"/>',
  pin:'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  bell:'<path d="M18 8a6 6 0 0 0-12 0c0 8-3 8-3 9h18c0-1-3-1-3-9M10 21h4M12 2V1"/>',
  car:'<path d="m5 8 2-5h10l2 5M3 9h18v9H3zM3 12h4m10 0h4M5 18v3m14-3v3"/><path d="M7 15h10"/>',
  plan:'<rect x="4" y="4" width="16" height="17" rx="3"/><path d="M8 2v5m8-5v5M4 10h16m-12 5h3m3 0h2"/>',
  walk:'<circle cx="14" cy="3" r="2"/><path d="m7 21 4-7 3 2 2 5M11 14l1-7 4 4h4M12 7 7 10l-1 4"/>',
  check:'<circle cx="12" cy="12" r="10"/><path d="m7 12 3 3 7-7"/>'
};
const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.pin}</svg>`;
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const STORE='moveahead-v1';
let storageAvailable=true;
function readLocal(){let raw;try{raw=localStorage.getItem(STORE);}catch{storageAvailable=false;return {};}try{const v=JSON.parse(raw||'{}');if(!v||typeof v!=='object'||Array.isArray(v))return {};const clean={};if(typeof v.enabled==='boolean')clean.enabled=v.enabled;if(v.plan&&typeof v.plan.destination==='string'&&typeof v.plan.time==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(v.plan.time))clean.plan={destination:v.plan.destination.slice(0,40),time:v.plan.time};return clean;}catch{return {};}}
let local=readLocal();
function persist(){try{localStorage.setItem(STORE,JSON.stringify(local));return true;}catch{storageAvailable=false;return false;}}
let state={scenario:'concert',stage:'home',timeOffset:0,values:{},prefs:{shelter:false,maxWalk:10},selected:null,lastAlert:null,snoozedUntil:0,enabled:local.enabled!==false,missing:false,trip:null,destination:'',events:[]};
let toastTimer;
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),4500);}
function record(type){state.events.push({event:type,scenario:state.scenario,minute:state.timeOffset});}
function scene(){return scenarios[state.scenario];}
function currentRisk(){return risk(state.missing?{}:state.values);}
function ranked(){return rankPoints(scene().points,state.prefs);}
function currentPoint(){return scene().points.find(p=>p.id===state.selected);}
function activeTrip(){return !!state.trip&&!['completed','cancelled','unavailable'].includes(state.trip.status);}
function displayClock(){const [h,m]=scene().time.split(':').map(Number);const total=(h*60+m+state.timeOffset)%1440;return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;}
function selectScenario(id){if(!scenarios[id])throw Error('未知情境');if(activeTrip())return toast('請先完成或取消目前的模擬行程。');const s=scenarios[id];state={...state,scenario:id,stage:'home',timeOffset:0,values:{rain:s.rain,demand:s.demand,concentration:s.concentration},selected:null,lastAlert:null,snoozedUntil:0,missing:false,trip:null,destination:s.destination};$('#booking-dialog').close();$('#transit-tip').hidden=true;render();}
function render(){
 const s=scene();$('#headline').textContent=s.title;$('#subtitle').textContent=s.subtitle;$('#clock').textContent=displayClock();
 document.querySelectorAll('[data-scenario]').forEach(b=>{const d=scenarios[b.dataset.scenario];b.innerHTML=icon(d.icon)+d.label;b.setAttribute('aria-pressed',String(d.id===s.id));b.disabled=activeTrip();});
 const phases=['home','alert','pickup','trip'];document.querySelectorAll('[data-step]').forEach(el=>{el.className=phases.indexOf(el.dataset.step)<phases.indexOf(state.stage)?'done':el.dataset.step===state.stage?'active':'';if(el.dataset.step===state.stage)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});
 $('#notifications').checked=state.enabled;$('#rain-input').value=state.values.rain;$('#demand-input').value=state.values.demand;$('#rain-value').textContent=state.values.rain+'%';$('#demand-value').textContent=state.values.demand;$('#missing-data').checked=state.missing;
 ['#rain-input','#demand-input','#missing-data'].forEach(x=>$(x).disabled=activeTrip());
 renderPanel();renderMap();
}
function riskPill(){const r=currentRisk();return `<span class="risk-pill ${r.tone}">${r.level}${r.score!==null?' · '+r.score:''}</span>`;}
function renderPanel(){
 const s=scene(),r=currentRisk();let content='';
 if(state.stage==='home')content=`<div class="panel-title"><h2>今天的城市脈動</h2><span class="module-tag">PULSE</span></div><div class="weather-card"><div class="weather-top"><div><p class="weather-city">${s.location}</p><span class="temperature">${state.missing?'—':s.temperature}°</span></div>${icon('rain')}</div><div class="weather-stats"><span>降雨機率 <strong>${state.missing?'暫無資料':state.values.rain+'%'}</strong></span><span>·</span><span>情境天氣</span></div></div><div class="event-card">${icon(s.icon)}<div><strong>${s.event}</strong><p>${s.label} · 今日移動資訊</p></div></div><div class="risk-line"><span>移動壓力</span>${riskPill()}</div><p class="panel-note">${state.missing?'目前資料不完整，暫停主動提醒。你仍可查看標示為示例的上車點。':s.tip}</p><div class="bottom-actions"><button class="primary" data-action="suggestions">看看我的移動建議 <span aria-hidden="true">→</span></button><p class="small muted">決定要不要搭車，都由你。</p></div>`;
 if(state.stage==='alert'){
 const delayed=state.snoozedUntil>state.timeOffset;
 const title=state.missing?'資料還沒到齊，先不下判斷。':r.score<60?'目前從容，照自己的步調。':state.scenario==='concert'?'人潮快到，先準備好離場。':state.scenario==='commute'?'雨可能正好遇上下班。':'轉乘人多，先選好候車位置。';
 content=`<div class="panel-title"><span class="module-tag">MOVE ALERT</span>${riskPill()}</div><div class="alert-symbol">${icon('bell')}</div><h2>${title}</h2><p class="panel-note">${state.missing?'資訊不足時不主動發出風險提醒。下方 A/B 仍為固定示例。':s.tip}</p><div class="risk-score"><strong>${r.score===null?'—':r.score}</strong><span>/ 100 · 規則示例分數</span></div><div class="factor-list"><div class="factor-row"><span>降雨機率</span><strong>${state.missing?'未知':state.values.rain+'%'}</strong></div><div class="factor-row"><span>需求指數</span><strong>${state.missing?'未知':state.values.demand+' / 100'}</strong></div><div class="factor-row"><span>時段集中指數</span><strong>${state.missing?'未知':state.values.concentration+' / 100'}</strong></div></div><p class="formula">分數 = 降雨 × 35% + 需求 × 40% + 時段 × 25%<br>示例規則，尚未經真實資料訓練或校準。</p><div class="bottom-actions"><button class="primary" data-action="pickup">比較周邊上車點 ${icon('pin')}</button><button class="secondary full" data-action="snooze" ${delayed?'disabled':''}>${delayed?`已延後，${state.snoozedUntil-state.timeOffset} 分鐘後再提醒`:'10 分鐘後再提醒我'}</button></div>`;
 }
 if(state.stage==='pickup'){
  const list=ranked();if(!list.some(p=>p.id===state.selected))state.selected=list[0]?.id||null;
  const choice=currentPoint();const best=list[0];
  content=`<div class="panel-title"><h2>在哪裡上車，更適合你？</h2><span class="module-tag">PICKUP</span></div><p class="small muted">一起看步行與等待，不只看最近的距離。</p><div class="preferences"><label class="check-row"><input id="shelter-pref" type="checkbox" ${state.prefs.shelter?'checked':''}> 優先避雨</label><select id="walk-pref" aria-label="最多可步行時間"><option value="10" ${state.prefs.maxWalk===10?'selected':''}>步行 10 分鐘內</option><option value="5" ${state.prefs.maxWalk===5?'selected':''}>步行 5 分鐘內</option><option value="2" ${state.prefs.maxWalk===2?'selected':''}>步行 2 分鐘內</option></select></div>${scene().points.map(p=>`<button class="pickup-card ${state.selected===p.id?'selected':''}" data-point="${p.id}" aria-pressed="${state.selected===p.id}" ${p.walk>state.prefs.maxWalk?'disabled':''}><div class="pickup-header"><span class="point-letter">${p.id}</span><h3>${p.name}</h3>${best?.id===p.id?'<span class="recommend-tag">建議選擇</span>':''}</div><div class="pickup-metrics"><div><span>步行</span><strong>${p.walk}<small> 分</small></strong></div><div><span>示例等待</span><strong>${p.wait}<small> 分</small></strong></div><div><span>需求</span><strong>${p.demand}</strong></div></div><p>${p.walk>state.prefs.maxWalk?'超過目前可接受的步行時間。':p.note}</p></button>`).join('')}${!list.length?'<div class="empty-state">這個步行範圍內沒有候選點。可放寬步行時間，或改用其他交通方式。</div>':`<p class="formula">${state.prefs.shelter?'避雨偏好：無遮雨點加計 4 分鐘偏好懲罰。':'依「步行＋示例等待」較短者建議。'}<br>候車區僅為情境示意，非經查核的合法上車位置。</p>`}<label class="field-label" for="ride-destination">目的地<select id="ride-destination">${['台北車站','公館商圈','松山車站','信義商圈'].map(d=>`<option ${state.destination===d?'selected':''}>${d}</option>`).join('')}</select></label><div class="bottom-actions"><button class="primary" data-action="book" ${!choice?'disabled':''}>${choice?`從 ${choice.id} 點模擬叫車`:'沒有符合偏好的上車點'} <span aria-hidden="true">→</span></button></div>`;
 }
 if(state.stage==='trip')content=tripPanel();
 $('#decision-panel').innerHTML=`<div class="panel-content">${content}</div>`;
}
function tripPanel(){
 const t=state.trip;if(!t)return '';
 const labels={matching:['正在尋找附近的車輛','此為模擬媒合，沒有真實訂單。'],arriving:['司機正在靠近','示例車輛 · 約 3 分鐘抵達'],onboard:['已上車，旅途順利。','行程狀態由示範按鈕推進。'],completed:['這一程，順利抵達。','感謝一起試用 MoveAhead。'],unavailable:['目前沒有媒合到車輛','可以回到比較畫面，換個上車點。'],cancelled:['模擬行程已取消','沒有建立真實訂單，也沒有費用。']};
 const [title,sub]=labels[t.status];const terminal=['completed','unavailable','cancelled'].includes(t.status);const next={matching:'模擬司機接單',arriving:'模擬已上車',onboard:'模擬抵達目的地'};
 return `<div class="panel-title"><span class="module-tag">LIVE ACTIVITY DEMO</span><span class="risk-pill low">${terminal?'體驗紀錄':'模擬行程'}</span></div><div class="trip-hero">${icon(t.status==='completed'?'check':'car')}<strong>${title}</strong><p>${sub}</p></div><div class="driver-card"><div><strong>${['arriving','onboard','completed'].includes(t.status)?'示例司機 · 陳先生':'yoxi MoveAhead'}</strong><small>${['arriving','onboard','completed'].includes(t.status)?'白色 Toyota Altis · DEMO-001':'頁內行程狀態展示'}</small></div>${icon('car')}</div><div class="trip-progress">${['matching','arriving','onboard','completed'].map((v,i)=>`<div class="${v===t.status?'current':''}">${['媒合中','司機接近','行程中','已抵達'][i]}</div>`).join('')}</div><div class="booking-row"><span>上車點</span><strong>${t.point.id} · ${t.point.name}</strong></div><div class="booking-row"><span>目的地</span><strong>${escapeHTML(t.destination)}</strong></div><div class="booking-row"><span>參考車資</span><strong>NT$ 180–240</strong></div><p class="formula" style="margin-top:10px">車資為固定示例，並非依里程、目的地或時段計價。</p><div class="bottom-actions">${!terminal?`<button class="primary" data-action="next-trip">${next[t.status]} →</button>${t.status==='matching'?'<button class="secondary full" data-action="no-car">模擬無車可派</button>':''}<button class="text-button full" data-action="cancel-trip">取消模擬行程</button>`:`<button class="primary" data-action="${t.status==='completed'?'restart':'pickup'}">${t.status==='completed'?'回到城市脈動':'重新比較上車點'} →</button>${t.status==='completed'?'<div class="feedback-row"><button data-feedback="useful">這次建議有幫助</button><button data-feedback="not-useful">還需要改善</button></div>':''}`}</div>`;
}
function renderMap(){
 const s=scene();
 const mapSvg=`<svg class="street-map" viewBox="0 0 700 500" preserveAspectRatio="xMidYMid slice" aria-label="周邊道路示意"><defs><pattern id="blocks" width="100" height="100" patternUnits="userSpaceOnUse" patternTransform="rotate(-20)"><rect width="100" height="100" fill="#e8edf0"/><rect x="9" y="10" width="80" height="80" rx="5" fill="#dce2e6" stroke="#d4dce1" stroke-width="1"/><path d="M0 0h100M0 0v100" stroke="#fff" stroke-width="13"/></pattern><filter id="soft"><feGaussianBlur stdDeviation="16"/></filter></defs><rect width="700" height="500" fill="url(#blocks)"/><path d="M-30 405 700 139" stroke="#d5dde3" stroke-width="53"/><path d="M-30 405 700 139" stroke="#fff" stroke-width="45"/><path d="M101-50 312 570" stroke="#d5dde3" stroke-width="48"/><path d="M101-50 312 570" stroke="#fafbfc" stroke-width="39"/><path d="M-10 118 720 345" stroke="#fafbfc" stroke-width="23"/><rect x="320" y="151" width="116" height="104" rx="23" fill="#d4e3d9" transform="rotate(-20 378 203)"/><rect x="335" y="170" width="86" height="58" rx="25" fill="#eef3f0" transform="rotate(-20 378 203)"/><circle cx="310" cy="270" r="40" fill="#ee8090" opacity=".28" filter="url(#soft)"/><circle cx="490" cy="160" r="29" fill="#ffbf89" opacity=".22" filter="url(#soft)"/><path d="M325 348 299 277 315 258" stroke="${state.selected==='A'?'#e6002c':'#8d9daa'}" stroke-width="3" stroke-dasharray="5 7" fill="none"/><path d="M325 348 399 307 478 173" stroke="${state.selected==='B'?'#e6002c':'#8d9daa'}" stroke-width="3" stroke-dasharray="5 7" fill="none"/><text x="330" y="105" fill="#8b969d" font-size="12" transform="rotate(-20 330 105)">城市幹道（示意）</text><text x="516" y="395" fill="#91a098" font-size="11">周邊生活街區</text></svg>`;
 $('#map').innerHTML=mapSvg+s.points.map(p=>`<button class="map-pin ${state.selected===p.id?'selected':''}" style="left:${p.x}%;top:${p.y}%" data-map-point="${p.id}" aria-label="比較 ${p.id} 點 ${p.name}" ${activeTrip()?'disabled':''}>${p.id}</button>`).join('')+'<div class="current-location"></div><span class="location-tag">'+s.location+' · 你在這裡</span>';
 const p=state.trip&&activeTrip()?state.trip.point:currentPoint();
 $('#map-summary').innerHTML=p?`<div class="summary-icon">${icon('walk')}</div><div><h3>${p.id} · ${p.name}</h3><p>步行 ${p.walk} 分鐘 ＋ 示例等待 ${p.wait} 分鐘${p.shelter?' · 等候處有遮雨':''}</p></div><div class="summary-time">${p.walk+p.wait} <small>分鐘</small></div>`:`<div class="summary-icon">${icon('pin')}</div><div><h3>先選時間，再選適合的上車點。</h3><p>點選 A、B 比較候車方案；街道與位置為示意。</p></div>`;
}
function openSuggestions(){state.stage='alert';record('advice_opened');render();}
function checkAlert(){const r=currentRisk();if(shouldAlert({score:r.score,enabled:state.enabled,now:state.timeOffset,lastAlert:state.lastAlert,snoozedUntil:state.snoozedUntil})&&!activeTrip()){state.lastAlert=state.timeOffset;state.snoozedUntil=0;state.stage='alert';record('alert_shown');render();toast('Move Alert：出發時段可能較忙，先看一眼移動建議。');return true;}return false;}
function selectPoint(id){if(activeTrip())return;if(!ranked().some(p=>p.id===id)){toast('這個點超過你設定的步行時間。');return;}state.stage='pickup';state.selected=id;record('pickup_selected');render();}
function showBooking(){const p=currentPoint();if(state.stage!=='pickup'||!p||!ranked().some(x=>x.id===p.id))return;$('#booking-summary').innerHTML=`<div class="booking-row"><span>上車點</span><strong>${p.id} · ${p.name}</strong></div><div class="booking-row"><span>目的地</span><strong>${escapeHTML(state.destination)}</strong></div><div class="booking-row"><span>步行＋示例等待</span><strong>${p.walk+p.wait} 分鐘</strong></div><div class="booking-row"><span>參考車資</span><strong>NT$ 180–240</strong></div>`;$('#booking-dialog').showModal();}
document.addEventListener('click',e=>{
 const scenarioButton=e.target.closest('[data-scenario]');if(scenarioButton){selectScenario(scenarioButton.dataset.scenario);return;}
 const point=e.target.closest('[data-point],[data-map-point]');if(point){selectPoint(point.dataset.point||point.dataset.mapPoint);return;}
 const feedback=e.target.closest('[data-feedback]');if(feedback){record('feedback_'+feedback.dataset.feedback);feedback.parentElement.innerHTML='<p class="small muted" role="status">謝謝回饋，已記錄在本次體驗中。</p>';return;}
 const button=e.target.closest('[data-action]');if(!button)return;
 switch(button.dataset.action){
  case 'suggestions':openSuggestions();break;
  case 'pickup':state.stage='pickup';state.trip=null;state.selected=null;record('pickup_opened');render();break;
  case 'snooze':state.snoozedUntil=state.timeOffset+10;record('alert_snoozed');render();toast('已延後 10 分鐘。可用上方「時間 +5 分鐘」體驗後續。');break;
  case 'book':showBooking();break;
  case 'next-trip':if(!activeTrip())return;state.trip.status={matching:'arriving',arriving:'onboard',onboard:'completed'}[state.trip.status];record('trip_'+state.trip.status);render();break;
  case 'no-car':if(state.trip?.status!=='matching')return;state.trip.status='unavailable';record('trip_unavailable');render();break;
  case 'cancel-trip':if(!activeTrip())return;state.trip.status='cancelled';record('trip_cancelled');render();break;
  case 'restart':selectScenario(state.scenario);break;
 }
});
document.addEventListener('change',e=>{
 if(e.target.id==='shelter-pref'){state.prefs.shelter=e.target.checked;state.selected=null;render();}
 if(e.target.id==='walk-pref'){state.prefs.maxWalk=Number(e.target.value);state.selected=null;render();}
 if(e.target.id==='ride-destination')state.destination=e.target.value;
});
$('#confirm-booking').addEventListener('click',()=>{const p=currentPoint();if(state.stage!=='pickup'||!p||!$('#booking-dialog').open)return;state.trip={status:'matching',point:{...p},destination:state.destination};state.stage='trip';record('mock_booking_confirmed');$('#booking-dialog').close();render();});
$('#cancel-dialog').addEventListener('click',()=>$('#booking-dialog').close());
$('#reset').addEventListener('click',()=>{state.trip=null;state.prefs={shelter:false,maxWalk:10};state.events=[];selectScenario('concert');toast('已重設體驗，儲存的計畫與提醒偏好仍保留。');});
$('#advance-time').addEventListener('click',()=>{state.timeOffset+=5;render();if(!checkAlert())toast(activeTrip()?'行程以面板上的模擬按鈕推進。':!state.enabled?'提醒已關閉；你仍可自行查看移動建議。':currentRisk().score===null?'資料不足，暫停主動提醒。':state.snoozedUntil>state.timeOffset?`距離稍後提醒還有 ${state.snoozedUntil-state.timeOffset} 分鐘。`:state.lastAlert!==null&&state.timeOffset-state.lastAlert<30?'為了避免打擾，目前仍在提醒冷卻時間內。':'目前沒有需要主動提醒的變化。');});
$('#notifications').addEventListener('change',e=>{state.enabled=e.target.checked;local.enabled=state.enabled;const saved=persist();toast((state.enabled?'已開啟頁內移動提醒。':'已關閉移動提醒。')+(!saved?' 此設定僅保留於本次頁面。':''));});
for(const id of ['rain','demand'])$('#'+id+'-input').addEventListener('input',e=>{state.values[id]=Number(e.target.value);render();});
$('#missing-data').addEventListener('change',e=>{state.missing=e.target.checked;render();});
$('#plan-icon').innerHTML=icon('plan');
if(local.plan&&typeof local.plan.destination==='string'&&/^\d{2}:\d{2}$/.test(local.plan.time)){ $('#plan-destination').value=local.plan.destination.slice(0,40);$('#plan-time').value=local.plan.time;$('#plan-status').textContent=`上次儲存的計畫：${local.plan.time} 前往 ${local.plan.destination.slice(0,40)}。請確認是否仍適用；不會背景提醒。`; }
if(!storageAvailable)$('#plan-status').textContent='目前無法使用本機儲存，計畫僅保留於本次頁面。';
$('#plan-form').addEventListener('submit',e=>{e.preventDefault();const destination=$('#plan-destination').value.trim(),time=$('#plan-time').value;if(!destination){$('#plan-destination').setCustomValidity('請輸入目的地。');$('#plan-destination').reportValidity();return;}local.plan={destination:destination.slice(0,40),time};const saved=persist();record('daily_plan_saved');$('#plan-status').textContent=`${saved?'已儲存在本機':'僅保留於本次頁面'}：${time} 前往 ${destination}。不會建立叫車或背景提醒。`;toast(saved?'今天的移動計畫已儲存。':'儲存空間不可用；計畫已保留於本次頁面。');});
$('#plan-destination').addEventListener('input',()=>$('#plan-destination').setCustomValidity(''));
$('#no-ride').addEventListener('click',()=>{record('non_ride_advice_opened');$('#transit-tip').hidden=false;$('#transit-tip').innerHTML=`<strong>今天，也可以照自己的方式出發。</strong><p style="margin:8px 0 0">${scene().transit}</p><div><button data-feedback="non_ride_useful">有幫助</button><button data-feedback="non_ride_not_useful">還需改善</button></div>`;});
$('#clear-local').addEventListener('click',()=>{local={};state.enabled=true;state.events=[];try{localStorage.removeItem(STORE);}catch{}$('#plan-form').reset();$('#plan-status').textContent='已清除本機計畫、提醒偏好與本次回饋。';$('#transit-tip').hidden=true;render();toast('本機紀錄已清除。');});
selectScenario('concert');
// Optional WebMCP enhancement; the primary experience never depends on it.
if(document.modelContext?.registerTool){const lifecycle=new AbortController();const register=tool=>{try{Promise.resolve(document.modelContext.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}};register({name:'read_moveahead_demo',description:'Read the current simulated mobility scenario. No real vehicle, weather, or location data.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:false},execute:()=>({scenario:state.scenario,stage:state.stage,risk:currentRisk(),selectedPoint:state.selected,tripStatus:state.trip?.status||null,simulated:true})});register({name:'select_moveahead_scenario',description:'Switch the visible demo scenario. Does not create a booking. Refuses while a simulated trip is active.',inputSchema:{type:'object',properties:{scenario:{type:'string',enum:Object.keys(scenarios)}},required:['scenario'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:input=>{if(!input||Object.keys(input).some(k=>k!=='scenario')||!Object.hasOwn(scenarios,input.scenario))throw Error('Invalid scenario');if(activeTrip())throw Error('Finish or cancel the current demo trip first');selectScenario(input.scenario);return {scenario:state.scenario,stage:state.stage,simulated:true};}});window.addEventListener('pagehide',()=>lifecycle.abort());}
