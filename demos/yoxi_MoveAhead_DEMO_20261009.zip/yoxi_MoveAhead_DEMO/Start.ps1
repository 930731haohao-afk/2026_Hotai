param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) { throw 'Python 3 is required. Alternatively, open index.html directly.' }
$pythonPath = $pythonCommand.Source
$runtimePath = Join-Path $projectRoot 'runtime'
New-Item -ItemType Directory -Path $runtimePath -Force | Out-Null
$appPath = Join-Path $projectRoot 'server.py'
$ready = $false
try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8766/health' -TimeoutSec 2
    if ($health.app -eq 'yoxi-moveahead-demo') { $ready = $true }
    else { throw 'Port 8766 is occupied by another application.' }
} catch { if ($_.Exception.Message -like '*occupied*') { throw } }
if (-not $ready) {
    $server = Start-Process -FilePath $pythonPath -ArgumentList ('"' + $appPath + '"') -WorkingDirectory $projectRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtimePath 'server.out.log') -RedirectStandardError (Join-Path $runtimePath 'server.err.log') -PassThru
    Set-Content -LiteralPath (Join-Path $runtimePath 'server.pid') -Value $server.Id -Encoding ascii
    for ($attempt=0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 250
        try { $health=Invoke-RestMethod -Uri 'http://127.0.0.1:8766/health' -TimeoutSec 1; if($health.app -eq 'yoxi-moveahead-demo') { $ready=$true; break } } catch {}
        $server.Refresh()
        if ($server.HasExited) { break }
    }
}
if (-not $ready) { throw 'Could not start the demo. See runtime/server.err.log.' }
Write-Output 'yoxi MoveAhead ready: http://127.0.0.1:8766'
if (-not $NoBrowser) { Start-Process 'http://127.0.0.1:8766' }
