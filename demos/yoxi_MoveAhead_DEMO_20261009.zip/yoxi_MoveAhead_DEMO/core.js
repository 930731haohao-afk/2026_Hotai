(function (root) {
  'use strict';
  const scenarios = {
    concert: { id:'concert', label:'演唱會散場', icon:'music', time:'21:40', location:'台北小巨蛋', title:'散場前，先想好怎麼回家。', subtitle:'22:00 預計散場 · 示範活動', rain:80, demand:90, concentration:95, temperature:26, destination:'台北車站', event:'預計 22:00 散場', tip:'散場人潮可能集中在主入口。可以先看上車點，再決定何時離開。', transit:'若選擇大眾運輸，可先確認捷運小巨蛋站入口及末班車；此處未接入即時班次。', points:[{id:'A',name:'主入口候車區',walk:3,wait:14,demand:'高',shelter:true,approved:true,x:44,y:50,note:'走得近，但散場人潮較集中。'},{id:'B',name:'周邊替代候車區',walk:6,wait:5,demand:'中',shelter:false,approved:true,x:70,y:30,note:'多走 3 分鐘，示例等待較短；途中無遮雨。'}]},
    commute: { id:'commute', label:'雨天通勤', icon:'rain', time:'18:10', location:'信義辦公區', title:'下班的雨，提早一點準備。', subtitle:'18:30 預計出發 · 平日通勤', rain:70, demand:75, concentration:80, temperature:28, destination:'公館商圈', event:'18:30 後降雨機率升高', tip:'下班時段與降雨重疊，建議先確認有遮雨的等候位置。', transit:'不搭車也能先準備雨具，確認步行段是否有遮雨；大眾運輸班次請另行查詢。', points:[{id:'A',name:'辦公大樓候車區',walk:2,wait:9,demand:'高',shelter:true,approved:true,x:43,y:48,note:'步行較短，可在示意雨棚下等候。'},{id:'B',name:'街口替代候車區',walk:5,wait:4,demand:'中',shelter:false,approved:true,x:72,y:31,note:'示例等待較短，但步行路段無遮雨。'}]},
    station: { id:'station', label:'車站轉乘', icon:'train', time:'17:30', location:'台北車站', title:'出了車站，接著順順走。', subtitle:'17:45 預計出發 · 尖峰轉乘', rain:20, demand:85, concentration:90, temperature:29, destination:'松山車站', event:'尖峰轉乘時段', tip:'出口距離與候車需求不同，先比較步行和等待的總時間。', transit:'不叫車時，可先確認捷運轉乘方向與站內指標；無障礙路線須依現場設施確認。', points:[{id:'A',name:'東側排班區示意點',walk:4,wait:5,demand:'中',shelter:true,approved:true,x:43,y:49,note:'候車需求較分散，步行與等待較均衡。'},{id:'B',name:'南側候車區示意點',walk:2,wait:12,demand:'高',shelter:true,approved:true,x:72,y:31,note:'較靠近出站位置，示例候車時間較長。'}]}
  };
  function risk(values) {
    const fields=['rain','demand','concentration'];
    if(fields.some(k=>typeof values[k]!=='number'||!Number.isFinite(values[k])||values[k]<0||values[k]>100)) return {score:null,level:'資料不足',tone:'unknown'};
    const score=Math.round(.35*values.rain+.4*values.demand+.25*values.concentration);
    return {score,level:score>=70?'偏高':score>=45?'中等':'平穩',tone:score>=70?'high':score>=45?'medium':'low'};
  }
  function rankPoints(points, prefs) {
    return points.filter(p=>p.approved&&p.walk<=prefs.maxWalk).map(p=>({...p,total:p.walk+p.wait,score:p.walk+p.wait+(prefs.shelter&&!p.shelter?4:0)})).sort((a,b)=>a.score-b.score||a.walk-b.walk||a.id.localeCompare(b.id));
  }
  function shouldAlert({score,enabled,now,lastAlert,snoozedUntil}) { return enabled&&score!==null&&score>=60&&now>=snoozedUntil&&(snoozedUntil>0||lastAlert===null||now-lastAlert>=30); }
  const api={scenarios,risk,rankPoints,shouldAlert};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  root.MoveAhead=api;
})(typeof window!=='undefined'?window:globalThis);
