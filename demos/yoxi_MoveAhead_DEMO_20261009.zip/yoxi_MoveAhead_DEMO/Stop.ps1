$ErrorActionPreference = 'Stop'
$pidFile = Join-Path $PSScriptRoot 'runtime\server.pid'
if (Test-Path -LiteralPath $pidFile) {
    $serverProcessId = 0
    if ([int]::TryParse((Get-Content -LiteralPath $pidFile -Raw).Trim(), [ref]$serverProcessId)) {
        $candidate = Get-CimInstance Win32_Process -Filter "ProcessId = $serverProcessId" -ErrorAction SilentlyContinue
        $appPath = Join-Path $PSScriptRoot 'server.py'
        if ($candidate -and $candidate.CommandLine -and $candidate.CommandLine.Contains($appPath)) {
            Stop-Process -Id $serverProcessId
            Remove-Item -LiteralPath $pidFile
            Write-Output 'Stopped yoxi MoveAhead demo.'
        }
    }
}
